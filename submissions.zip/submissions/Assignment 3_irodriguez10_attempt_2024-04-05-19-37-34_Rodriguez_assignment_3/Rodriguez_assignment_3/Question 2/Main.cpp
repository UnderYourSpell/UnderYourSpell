#include <iostream>
#include "ZipCode.h"
using namespace std;

int main() {
    ZipCode zip1(99504);
    cout << "Zipcode: " << zip1.getZip() << endl;
    cout << "Barcode: " << zip1.getBar() << endl;

    ZipCode zip2("110100101000101011000010011");
    cout << "Zipcode: " << zip2.getZip() << endl;
    cout << "Barcode: " << zip2.getBar() << endl;

    return 0;
}