#pragma once
#include <iostream>
#include <string>
using namespace std;

class ZipCode {
private:
    int zipCode;
    string barCode;
public:
    ZipCode(int zip) : zipCode(zip), barCode(encode(zip)) {}
    ZipCode(const string& code) : zipCode(decode(code)), barCode(code) {}
    int decode(const string& barcode);
    string encode(int zipCode);
    int getZip() const;
    string getBar() const;
};
