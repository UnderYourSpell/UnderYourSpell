#include "ZipCode.h"

int ZipCode::decode(const string& barCode) {
    int zipCode = 0;
    for (int i = 1; i < 26; i += 5) {
        int sum = 0;
        for (int j = 0; j < 5; ++j) {
            sum += (barCode[i + j] - '0') * ((j == 0) ? 7 : (j == 1) ? 4 : (j == 2) ? 2 : (j == 3) ? 1 : 0);
        }
        zipCode = (sum == 11) ? zipCode * 10 : zipCode * 10 + sum;
    }
    return zipCode;
}

string ZipCode::encode(int zipCode) {
    string barCode = "1";
    while (zipCode > 0) {
        int digit = zipCode % 10;
        string encoding;
        switch (digit) {
            case 0:
                encoding = "11000";
                break;
            case 1:
                encoding = "00011";
                break;
            case 2:
                encoding = "00101";
                break;
            case 3:
                encoding = "00110";
                break;
            case 4:
                encoding = "01001";
                break;
            case 5:
                encoding = "01010";
                break;
            case 6:
                encoding = "01100";
                break;
            case 7:
                encoding = "10001";
                break;
            case 8:
                encoding = "10010";
                break;
            case 9:
                encoding = "10100";
                break;
        }
        barCode = encoding + barCode;
        zipCode /= 10;
    }
    barCode += "1";
    return barCode;
}

int ZipCode::getZip() const {
    return zipCode;
}

string ZipCode::getBar() const {
    return barCode;
}