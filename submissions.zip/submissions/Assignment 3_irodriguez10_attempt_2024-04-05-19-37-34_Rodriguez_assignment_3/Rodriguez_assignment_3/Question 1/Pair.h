#pragma once
class Pair
{
private:
	int num1, num2;
public:
	Pair();
	Pair(int num1, int num2);
	int get1();
	int get2();
	Pair operator+(const Pair& other);
	Pair operator+(int otherNum);

	friend Pair operator+(int num, const Pair& p) { // Allows for number to be added before pair
		return Pair(p.num1 + num, p.num2 + num);
	}

	friend Pair operator+(const Pair& p, int num) {
		return Pair(p.num1 + num, p.num2 + num);
	}

	friend Pair operator+(const Pair& p1, const Pair& p2) {
		return Pair(p1.num1 + p2.num1, p1.num2 + p2.num2);
	}
};