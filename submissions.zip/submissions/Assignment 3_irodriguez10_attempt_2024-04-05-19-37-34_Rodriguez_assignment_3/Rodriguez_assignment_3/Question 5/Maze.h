#ifndef MAZE_H
#define MAZE_H

#include <iostream>
#include <ctime>
#include <cstdlib>

class Maze {
    private:
        static const int WIDTH = 20;
        static const int HEIGHT = 20;
        char maze[HEIGHT][WIDTH];
        bool visited[HEIGHT][WIDTH];

    public:
        Maze();
        void generateRandomWallsAndExit();
        void print() const;
        bool isValidMove(int x, int y) const;
        bool findExit(int x, int y);
};

#endif // MAZE_H
