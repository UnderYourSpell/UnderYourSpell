#include <iostream>
#include <ctime>
#include <cstdlib>
#include "Maze.h"
using namespace std;

int main() {
    srand(time(NULL));

    Maze maze;
    maze.generateRandomWallsAndExit();

    cout << "Original Maze:" << endl;
    maze.print();
    cout << endl;

    int startX = 1, startY = 1;
    if (maze.findExit(startX, startY)) {
        cout << "Exit Found!" << endl << endl;
        cout << "Path to Exit:" << endl;
        maze.print();
    }
    else {
        cout << "Exit not found!" << endl;
    }

    return 0;
}
