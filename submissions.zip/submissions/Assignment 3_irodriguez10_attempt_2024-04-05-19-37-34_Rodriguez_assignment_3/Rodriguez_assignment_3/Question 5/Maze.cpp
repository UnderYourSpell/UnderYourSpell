#include "Maze.h"
using namespace std;

Maze::Maze() {
    for (int i = 0; i < HEIGHT; ++i) {
        for (int j = 0; j < WIDTH; ++j) {
            if (i == 0 || i == HEIGHT - 1 || j == 0 || j == WIDTH - 1)
                maze[i][j] = 'X';
            else
                maze[i][j] = ' ';
        }
    }
}

void Maze::generateRandomWallsAndExit() {
    srand(time(NULL));
    bool setE = false;
    for (int i = 1; i < HEIGHT - 1; ++i) {
        for (int j = 1; j < WIDTH - 1; ++j) {
            int wallChance = (rand() % 4) + 1;
            if (wallChance == 1) {
                maze[i][j] = 'X'; // Set random walls
            }
            else if ((wallChance == 2) && (!setE)) {
                maze[i][j] = 'E'; // Set exit
                setE = true;
            }
        }
    }
}

void Maze::print() const {
    for (int i = 0; i < HEIGHT; ++i) {
        for (int j = 0; j < WIDTH; ++j) {
            cout << maze[i][j];
        }
        cout << endl;
    }
}

bool Maze::isValidMove(int x, int y) const {
    if (x < 0 || x >= WIDTH || y < 0 || y >= HEIGHT)
        return false;
    if (maze[y][x] == 'X' || visited[y][x])
        return false;
    return true;
}

bool Maze::findExit(int x, int y) {
    if (maze[y][x] == 'E')
        return true;

    visited[y][x] = true;

    if (isValidMove(x, y - 1) && findExit(x, y - 1))
        return true;
    if (isValidMove(x, y + 1) && findExit(x, y + 1))
        return true;
    if (isValidMove(x - 1, y) && findExit(x - 1, y))
        return true;
    if (isValidMove(x + 1, y) && findExit(x + 1, y))
        return true;

    return false;
}
