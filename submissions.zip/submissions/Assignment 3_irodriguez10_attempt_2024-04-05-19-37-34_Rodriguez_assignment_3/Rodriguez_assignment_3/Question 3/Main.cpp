#include <iostream>
#include <string>
#include "Movie.h"
using namespace std;

void sortMovies(Movie arr[], int n);

int main() {
    Movie movies[] = {Movie("Black Panther", "PG-13"), Movie("Avengers: Infinity War", "PG-13"), Movie("A Wrinkle In Time", "PG"), Movie("Ready Player One", "PG-13"), Movie("Red Sparrow", "R"), Movie("The Incredibles 2", "G")};

    int n = sizeof(movies) / sizeof(movies[0]);

    sortMovies(movies, n);

    cout << "Sorted movies:\n";
    for (int i = 0; i < n; i++) {
        cout << movies[i].getName() << ", " << movies[i].getRating() << endl;
    }

	return 0;
}

void sortMovies(Movie arr[], int n) {
    for (int i = 0; i < n - 1; ++i) {
        for (int j = i + 1; j < n; ++j) {
            if (arr[i].getName() > arr[j].getName()) {
                swap(arr[i], arr[j]);
            }
        }
    }
}