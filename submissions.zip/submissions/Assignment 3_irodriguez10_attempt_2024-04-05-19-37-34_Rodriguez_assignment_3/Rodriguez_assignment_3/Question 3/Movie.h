#pragma once
#include <string>
using namespace std;
class Movie {
    private:
        string name;
        string rating;

    public:
        Movie(string n, string r) : name(n), rating(r) {}

        string getName() const {
            return name;
        }

        string getRating() const {
            return rating;
        }

        void setName(string n) {
            name = n;
        }

        void setRating(string r) {
            rating = r;
        }

};