//
//  main.cpp
//  A3 Q4
//
//  Created by Amine B  on 4/1/24.
//  Benford Law 

#include <iostream>
#include <fstream>

using namespace std;

int countFirstDigitFrequency(int number) {
    while (number >= 10) {
        number /= 10;
    }
    return number;
}

int main() {
    ifstream inputFile("/Users/absfolder/Desktop/A3 Q4/A3 Q4/enrollments.txt");
    if (!inputFile.is_open()) {
        cerr << "Failed to open the file." << endl;
        return 1;
    }

    const int arraySize = 3295; // Assuming there are 3295 numbers in the file
    int numbers[arraySize];

    // Read numbers from the file
    for (int i = 0; i < arraySize; ++i) {
        if (!(inputFile >> numbers[i])) {
            cerr << "Error reading from file." << endl;
            return 1;
        }
    }
    inputFile.close();

    // Count the frequency of the first digit in each number
    int digitFrequency[10] = {0}; // Array to store the frequency of each digit (0-9)
    for (int i = 0; i < arraySize; ++i) {
        int firstDigit = countFirstDigitFrequency(numbers[i]);
        digitFrequency[firstDigit]++;
    }

    // Display the frequency of the first digit in each number
    cout << "Frequency of the first digit in each number:" << endl;
    for (int i = 1; i <= 9; ++i) {
        cout << "Digit " << i << ": " << digitFrequency[i] << endl;
    }

    return 0;
}
