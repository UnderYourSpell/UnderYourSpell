{\rtf1\ansi\ansicpg1252\cocoartf2709
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww11520\viewh8280\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 1) Class pair, everything is the same as provided initially except for the added friend operator/function\
\
2) uses class zipCode. Has two functions: decodeGroup and encodeGroup that encodes either the integer zip code or decodes the 27 bar zip code\
\
3) uses Movie class. Takes in movies as an array in main(), then has a bubble sort to order them by alphabetical order\
\
4) reads enrollments.txt then output frequency of leading digit \
\
5) exact same code from assignment 2, except everything is put into a Maze class}