//
//  Pair.h
//  A3 Q1
//
//  Created by Amine B  on 3/31/24.
//

#ifndef Pair_h
#define Pair_h


#endif /* Pair_h */
#pragma once
class Pair
{
private:
    int num1, num2;
public:
    Pair();
    Pair(int num1, int num2);
    int get1();
    int get2();
    Pair operator+(const Pair& other);
    Pair operator+(int otherNum);
    friend Pair operator+(int otherNum, const Pair& other);
};
