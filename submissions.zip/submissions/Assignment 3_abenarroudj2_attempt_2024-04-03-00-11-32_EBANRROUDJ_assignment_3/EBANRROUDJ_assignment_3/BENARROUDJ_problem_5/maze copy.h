//
//  maze.h
//  A3 Q5
//
//  Created by Amine B  on 4/2/24.
//

#ifndef maze_h
#define maze_h

const int WIDTH = 10;
const int HEIGHT = 10;

class Maze {
private:
    char maze[HEIGHT][WIDTH];
    bool visited[HEIGHT][WIDTH];

public:
    Maze();
    void printMaze(int curx, int cury);
    bool validMove(int newX, int newY);
    bool search(int x, int y);
};

#endif /* maze_h */
