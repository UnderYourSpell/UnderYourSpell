//
//  maze.cpp
//  A3 Q5
//
//  Created by Amine B  on 4/2/24.
//

#include <stdio.h>
#include "maze.h"
#include <iostream>

using namespace std;

Maze::Maze() {
    // Initialize the maze
    char tempMaze[HEIGHT][WIDTH] = {
        {'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'},
        {'X', ' ', ' ', ' ', ' ', ' ', 'X', ' ', ' ', 'X'},
        {'X', ' ', 'X', ' ', ' ', ' ', 'X', ' ', ' ', 'X'},
        {'X', ' ', 'X', 'X', 'X', ' ', 'X', ' ', ' ', 'X'},
        {'X', ' ', ' ', ' ', 'X', ' ', 'X', ' ', ' ', 'X'},
        {'X', ' ', ' ', ' ', 'X', ' ', ' ', ' ', 'X', 'X'},
        {'X', ' ', 'X', 'X', 'X', ' ', ' ', ' ', ' ', 'X'},
        {'X', ' ', 'X', ' ', ' ', ' ', 'X', ' ', ' ', 'X'},
        {'X', ' ', ' ', ' ', ' ', ' ', 'X', ' ', 'E', 'X'},
        {'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X'}
    };

    // Copy the maze to the member maze array
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            maze[i][j] = tempMaze[i][j];
        }
    }

    // Initialize visited locations to false
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            visited[i][j] = false;
        }
    }
}

void Maze::printMaze(int curx, int cury) {
    for (int y = 0; y < HEIGHT; y++) {
        for (int x = 0; x < WIDTH; x++) {
            if ((x == curx) && (y == cury))
                cout << "@";
            else
                cout << maze[y][x];
        }
        cout << endl;
    }
}

bool Maze::validMove(int newX, int newY) {
    if (newX < 0 || newX >= WIDTH)
        return false;
    if (newY < 0 || newY >= HEIGHT)
        return false;
    if (maze[newY][newX] == 'X')
        return false;
    if (visited[newY][newX])
        return false;
    return true;
}

bool Maze::search(int x, int y) {
    if (maze[y][x] == 'E')
        return true;

    bool foundExit = false;
    visited[y][x] = true;
    if (validMove(x, y - 1))
        foundExit = search(x, y - 1);
    if (!foundExit && validMove(x, y + 1))
        foundExit = search(x, y + 1);
    if (!foundExit && validMove(x - 1, y))
        foundExit = search(x - 1, y);
    if (!foundExit && validMove(x + 1, y))
        foundExit = search(x + 1, y);

    if (foundExit) {
        printMaze(x, y);
        cout << endl;
        return true;
    }
    return false;
}
