//
//  main.cpp
//  A3 Q5
//
//  Created by Amine B  on 4/1/24.
//  Maze Class

#include <iostream>
#include "maze.h"
#include <ctime>
#include <cstdlib>
using namespace std;


int main() {
    Maze maze;

    int x = 1, y = 1;

    maze.search(x, y);

    return 0;
}
