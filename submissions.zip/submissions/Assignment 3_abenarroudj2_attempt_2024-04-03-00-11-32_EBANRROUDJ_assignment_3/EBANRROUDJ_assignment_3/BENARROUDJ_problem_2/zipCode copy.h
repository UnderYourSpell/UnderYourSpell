//
//  zipCode.h
//  A3 Q2
//
//  Created by Amine B  on 4/2/24.
//

#ifndef zipCode_h
#define zipCode_h


#include <string>
using namespace std;

class ZipCode {
private:
    string barcode;
    int zipcode;

    // decode a group of five digits
    int decodeGroup(const string& group);

    // encode a digit into a group of five digits
    string encodeDigit(int digit);

public:
    // Constructor: integer input
    ZipCode(int code);

    // Constructor: barcode input
    ZipCode(const string& code);

    // return the zip code as an integer
    int getZipCode() const;

    // return the zip code in barcode format as a string
    string getBarcode() const;
};

#endif /* zipCode_h */
