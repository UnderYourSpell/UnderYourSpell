//
//  main.cpp
//  A3 Q2
//
//  Created by Amine B  on 4/1/24.
//  Postal Service Bar zip code


#include <iostream>
#include "zipCode.h"
using namespace std;

int main() {
    // Test the ZipCode class
    ZipCode zip1(99517);
    cout << "Encoded barcode: " << zip1.getBarcode() << endl;
    cout << "zip code: " << zip1.getZipCode() << endl;

    ZipCode zip2("110100101000101011000010011");
    cout << "barcode: " << zip2.getBarcode() << endl;
    cout << "Decoded zip code: " << zip2.getZipCode() << endl;

    return 0;
}
