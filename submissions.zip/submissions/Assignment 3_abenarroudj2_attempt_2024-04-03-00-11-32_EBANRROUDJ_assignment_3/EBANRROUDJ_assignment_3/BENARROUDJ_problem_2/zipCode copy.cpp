//
//  zipCode.cpp
//  A3 Q2
//
//  Created by Amine B  on 4/2/24.
//

#include "zipCode.h"

// decode a group of five digits
int ZipCode::decodeGroup(const string& group) {
    int value[] = {7, 4, 2, 1, 0};
    int sum = 0;
    for (int i = 0; i < 5; ++i) {
        sum += (group[i] - '0') * value[i];
    }
    if (sum == 11) // Special case: represents digit 0
        return 0;
    else
        return sum;
}

// encode a digit into a group of five digits
string ZipCode::encodeDigit(int digit) {
    int value[] = {7, 4, 2, 1, 0};
    string group;
    for (int i = 0; i < 5; ++i) {
        if (digit >= value[i]) {
            group += '1';
            digit -= value[i];
        } else {
            group += '0';
        }
    }
    return group;
}

// Constructor: integer input
ZipCode::ZipCode(int code) {
    zipcode = code;
    barcode = "";
    while (code > 0) {
        int digit = code % 10;
        code /= 10;
        barcode = encodeDigit(digit) + barcode;
    }
    // Add leading and trailing 1's
    barcode = "1" + barcode + "1";
}

// Constructor: barcode input
ZipCode::ZipCode(const string& code) {
    barcode = code;
    zipcode = 0;
    // Remove leading and trailing 1's
    string digits = code.substr(1, code.length() - 2);
    for (int i = 0; i < digits.length(); i += 5) {
        string group = digits.substr(i, 5);
        int digit = decodeGroup(group);
        zipcode = zipcode * 10 + digit;
    }
}

// return the zip code as an integer
int ZipCode::getZipCode() const {
    return zipcode;
}

// return the zip code in barcode format as a string
string ZipCode::getBarcode() const {
    return barcode;
}
