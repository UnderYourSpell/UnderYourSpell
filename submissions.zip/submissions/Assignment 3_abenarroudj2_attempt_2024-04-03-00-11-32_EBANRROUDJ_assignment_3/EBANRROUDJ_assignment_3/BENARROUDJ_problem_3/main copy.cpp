//
//  main.cpp
//  A3 Q3
//
//  Created by Amine B  on 3/31/24.
//  Movie and rating class info

#include <iostream>
#include "Movie.h"
#include <string>

using namespace std;

// Sorting function using bubble sort
void sortMovies(Movie movies[], int size) {
    for (int i = 0; i < size - 1; ++i) {
        for (int j = 0; j < size - i - 1; ++j) {
            // Compare movie names and swap if necessary
            if (movies[j].getName() > movies[j + 1].getName()) {
                swap(movies[j], movies[j + 1]);
            }
        }
    }
}

int main()
{
    const int SIZE = 5; // Size of the array
    Movie info[SIZE] = {
        Movie("Black Panther", "PG-13"),
        Movie("Avengers: Infinity War", "PG-13"),
        Movie("A Wrinkle In Time", "G"),
        Movie("Red Sparrow", "R"),
        Movie("Ready Player One", "PG-13")
    };
    
    
    // Sort the movies alphabetically by name
    sortMovies(info, SIZE);
    
    
    for (int i = 0; i < SIZE; ++i) {
        cout << info[i].getName() << ", " << info[i].getRating() << endl;
    }
    
    return 0;
}




