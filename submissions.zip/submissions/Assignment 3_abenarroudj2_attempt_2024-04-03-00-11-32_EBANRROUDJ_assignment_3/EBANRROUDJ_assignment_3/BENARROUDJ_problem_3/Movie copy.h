//
//  Movie.h
//  A3 Q3
//
//  Created by Amine B  on 3/31/24.
//

#ifndef Movie_h
#define Movie_h

#include <string>
using namespace std;

class Movie {
private:
    string name;
    string rating;

public:
    Movie(string n, string r);
    string getName();
    string getRating();
};



#endif /* Movie_h */
