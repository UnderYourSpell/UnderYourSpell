//
//  Movie.cpp
//  A3 Q3
//
//  Created by Amine B  on 3/31/24.
//

#include "Movie.h"


Movie::Movie(string n, string r) : name(n), rating(r)
{
}

string Movie::getName()
{
    return name;
}

string Movie::getRating()
{
    return rating;
}
