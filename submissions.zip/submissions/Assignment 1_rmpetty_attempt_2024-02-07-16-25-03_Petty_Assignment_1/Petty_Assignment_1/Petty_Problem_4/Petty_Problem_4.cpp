#include <iostream>

using namespace std;

void Change(int Change, int &quarter, int &dime, int &nickel, int &penny){
    int remaining = Change;
    if (Change/25 > 0){
        quarter = Change/25;
        remaining = Change-quarter*25;
        cout << "Quarters: " << quarter << endl;
    }
    if (remaining/10 > 0){
        dime = remaining/10;
        remaining -= dime*10;
        cout << "Dimes: " << dime << endl;
    }
    if (remaining/5 > 0){
        nickel = remaining/5;
        remaining -= nickel*5;
        cout << "Nickels: " << nickel << endl;
    }
    if (remaining > 0){
        penny = remaining;
        cout << "Pennies: " << penny << endl;
    }

}

int main()
{
    int totalChange=0, quarter=0, dime=0, nickel=0, penny=0;


    cout << "Total change test: 41" << endl;
    Change(41, quarter, dime, nickel, penny);
    cout << endl;

    cout << "Total change test: 99" << endl;
    Change(99, quarter, dime, nickel, penny);

    /*cout << "Enter a number 1-99: ";
    cin >> totalChange;

    //makes sure # is 1-99
    while (totalChange > 99 || totalChange < 0){
        cout << "Enter a number 1-99: ";
        cin >> totalChange;
    }

    //total change function
    Change(totalChange, quarter, dime, nickel, penny);

    //Quarter amount
    if (quarter > 0){
        cout << "Quarters: " << quarter << endl;
    }

    //Dime amount
    if (dime > 0){
        cout << "Dimes: " << dime << endl;
    }

    //Nickel amount
    if (nickel > 0){
        cout << "Nickels: " << nickel << endl;
    }

    //Penny amount
    if (penny > 0){
        cout << "Pennies: " << penny << endl;
    }*/
    return 0;
}
