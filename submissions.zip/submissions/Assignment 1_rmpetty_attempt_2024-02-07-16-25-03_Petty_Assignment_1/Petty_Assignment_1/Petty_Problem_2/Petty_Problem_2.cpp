#include <iostream>
#include <cstdlib>
#include <time.h>

using namespace std;

int Wager(int &owned, int wager, int numChoice){
    srand(time(0));
    int num1=0, num2=0, num3=0;
    num1 = rand()%6+1;
    cout << "Die 1: " << num1 << endl;
    num2 = rand()%6+1;
    cout << "Die 2: " << num2 << endl;
    num3=rand()%6+1;
    cout << "Die 3: " << num3 << endl;

    if ((num1 == numChoice) && (num2 == numChoice) && (num3 == numChoice)){
        return 3;
    }
    else if (((num1 == numChoice) && (num2 == numChoice)) || ((num1 == numChoice)&&(num3 == numChoice)) || ((num2 == numChoice)&&(num3 == numChoice))){
        return 2;
    }
    else if ((num1 == numChoice)||(num2 == numChoice)||(num3==numChoice)){
        return 1;
    }
    else{
        return 0;
    }
}

int main()
{
    int owned=100, wager=1, numChoice=0;
    char YN = 'y';

    while (YN != 'n' && YN != 'N' && owned >= 1){

    cout << "Your money: $" << owned << endl;
    cout << "How much would you like to wager?(no greater than the amount owned): $";

    cin >> wager;

    while (wager > owned){
        cout << "Please do not wager more money than you own: $";
        cin >> wager;
    }

    cout << "Please choose a number 1-6: ";
    cin >> numChoice;

   while (numChoice < 1 || numChoice > 6){

    cout << "Please choose a number between 1 and 6: ";
    cin >> numChoice;
   }

   switch(Wager(owned, wager, numChoice)){
    case(0):
        owned -= wager;
        cout << "You lost money! Current amount owned: $" << owned << endl;
        break;
    case(1):
        owned = owned;
        cout << "Your owned amount did not change. Current amount owned: $" << owned << endl;
        break;
    case(2):
        owned = owned*2;
        cout << "Your owned amount doubled! Current amount owned: $" << owned << endl;
        break;
    case(3):
        owned = owned*3;
        cout << "Your owned amount tripled! Current amount owned: $" << owned << endl;
        break;
   }

   if (owned > 0){
    cout << "Would you like to continue?(Y/N): ";
    cin >> YN;
    }
    }
    return 0;

}
