Q1: when running the question 1 code, if usng in linux command, use I/O redirection with the enrollments.txt file. (i.e ./a.out < enrollments.txt)
Q3: answer is in word file in Q3 folder
Q4:to have user input, un-comment lines 41-70; comment out lines 10, 15, 20, and 24. Otherwise, it will only run the pre-set tests