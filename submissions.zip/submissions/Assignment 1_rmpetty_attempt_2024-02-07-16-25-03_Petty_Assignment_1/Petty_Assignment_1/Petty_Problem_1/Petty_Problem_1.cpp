#include <iostream>
using namespace std;

int main(){

int arr[3295];
int one=0, two=0, three=0, four=0, five=0, six=0, sev=0, eight=0, nine=0;

for (int i=0; i<3295; ++i){
 cin >> arr[i]; 

 if (arr[i]/10 == 0){
   if (arr[i] == 1){one++;}
   else if (arr[i] == 2){two++;}
   else if (arr[i] == 3){three++;}
   else if (arr[i] == 4){four++;}
   else if (arr[i] == 5){five++;}
   else if (arr[i] == 6){six++;}
   else if (arr[i] == 7){sev++;}
   else if (arr[i] == 8){eight++;}
   else if (arr[i] == 9){nine++;}
 }
 else if (arr[i]/10 == 1){one++;}
 else if (arr[i]/10 == 2){two++;}
 else if (arr[i]/10 == 3){three++;}
 else if (arr[i]/10 == 4){four++;}
 else if (arr[i]/10 == 5){five++;}
 else if (arr[i]/10 == 6){six++;}
 else if (arr[i]/10 == 7){sev++;}
 else if (arr[i]/10 == 8){eight++;}
 else if (arr[i]/10 == 9){nine++;}
 }

cout << "1: " << one << endl;
cout << "2: " << two << endl;
cout << "3: " << three << endl;
cout << "4: " << four << endl;
cout << "5: " << five << endl;
cout << "6: " << six << endl;
cout << "7: " << sev << endl;
cout << "8: " << eight << endl;
cout << "9: " << nine << endl; 

 return 0;
}
