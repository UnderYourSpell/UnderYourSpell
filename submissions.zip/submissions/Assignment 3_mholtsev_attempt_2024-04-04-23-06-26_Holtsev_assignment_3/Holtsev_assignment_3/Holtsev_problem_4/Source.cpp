#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int main() {
	string numbers;
	int leading_digits[10] = { 0 };
	ifstream enrollments;
	enrollments.open("enrollments.txt");
	while (getline(enrollments, numbers)) {
		leading_digits[numbers[0] - '0']++;		// digit characters convert to ASCII values
	}
	for (int i = 1; i < 10; i++) {
		cout << i << ": " << leading_digits[i] << endl;
	}
}