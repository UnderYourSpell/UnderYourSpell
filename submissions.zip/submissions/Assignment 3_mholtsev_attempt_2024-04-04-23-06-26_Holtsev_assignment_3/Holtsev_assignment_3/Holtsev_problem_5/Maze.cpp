#include "Maze.h"
#include <ctime>
#include <cstdlib>

Maze::Maze()
{
	srand(time(NULL));
	generate_maze();
}

char (*Maze::get_maze())[WIDTH]
{
	return maze;
}

bool (*Maze::get_visited())[WIDTH]
{
	return visited;
}

int* Maze::get_solutionX()
{
	return solutionX;
}

int* Maze::get_solutionY()
{
	return solutionY;
}

int& Maze::get_numPoints()
{
	return numPoints;
}

int& Maze::get_x()
{
	return x;
}

int& Maze::get_y()
{
	return y;
}


void Maze::generate_maze()
{
	for (int x = 0; x < WIDTH; x++)
		for (int y = 0; y < HEIGHT; y++)
			maze[y][x] = ' ';
	// Borders with X
	for (int x = 0; x < WIDTH; x++)
	{
		maze[0][x] = 'X';
		maze[HEIGHT - 1][x] = 'X';
	}
	for (int y = 0; y < HEIGHT; y++)
	{
		maze[y][0] = 'X';
		maze[y][WIDTH - 1] = 'X';
	}
	// ***** Randomly fill in 25% of the middle
	int numCells = static_cast<int>((HEIGHT - 2) * (WIDTH - 2) * 0.25);
	int count = 0;
	while (count < numCells)
	{
		int x = (rand() % (WIDTH - 2)) + 1;
		int y = (rand() % (HEIGHT - 2)) + 1;
		if (maze[y][x] == ' ')
		{
			maze[y][x] = 'X';
			count++;
		}
	}

	// ***** Pick a random start and end that is not a wall *****
	x = (rand() % (WIDTH - 2)) + 1;
	y = (rand() % (HEIGHT - 2)) + 1;
	while (maze[y][x] == 'X')
	{
		x = (rand() % (WIDTH - 2)) + 1;
		y = (rand() % (HEIGHT - 2)) + 1;
	}
	// At this point, (x,y) contains our start position
	// ***** Pick a random end position that is not a wall *******
	int exitX = (rand() % (WIDTH - 2)) + 1;
	int exitY = (rand() % (HEIGHT - 2)) + 1;
	while (maze[exitY][exitX] == 'X')
	{
		exitX = (rand() % (WIDTH - 2)) + 1;
		exitY = (rand() % (HEIGHT - 2)) + 1;
	}
	maze[exitY][exitX] = 'E';

	// Initialize visited locations to false
	for (int x = 0; x < WIDTH; x++)
		for (int y = 0; y < HEIGHT; y++)
			visited[y][x] = false;
	visited[y][x] = true;
}



