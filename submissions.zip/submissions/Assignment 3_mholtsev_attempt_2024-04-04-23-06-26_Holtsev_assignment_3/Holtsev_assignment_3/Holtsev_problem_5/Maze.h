#pragma once
class Maze
{
private:
	//************ Width and Height changed to 20x20  ********************
	static const int WIDTH = 20;
	static const int HEIGHT = 20;
	char maze[HEIGHT][WIDTH];
	bool visited[HEIGHT][WIDTH];
	int solutionX[(HEIGHT - 2) * (WIDTH - 2)];
	int solutionY[(HEIGHT - 2) * (WIDTH - 2)];
	int numPoints = 0;
	int x = 0, y = 0;
	void generate_maze();
public:
	Maze();
	char (*get_maze())[WIDTH];
	bool (*get_visited())[WIDTH];
	int* get_solutionX();
	int* get_solutionY();
	int& get_numPoints();
	int& get_x();
	int& get_y();
};