#pragma once
#include <string>
class Movie
{
private:
	std::string name;
	std::string MPAA_rating;
public:
	Movie();
	Movie(std::string name, std::string MPAARating);
	std::string get_name();
	std::string get_rating();
	void set_name(std::string name);
	void set_rating(std::string rating);

};

