#include <iostream>
#include "Movie.h"
using namespace std;

// Sort function for Movies class based on names alphabetical order
void bubble_sort(Movie movies[], int length) {
	while (length > 1) {
		for (int i = 0; i < length - 1; i++) {
			if (movies[i].get_name().compare(movies[i + 1].get_name()) > 0) {
				string temp = movies[i].get_name();
				movies[i].set_name(movies[i + 1].get_name());
				movies[i + 1].set_name(temp);
			}
		}
		length--;
	}
}

int main() {
	Movie movies[] = { Movie("Black Panther", "PG-13"), Movie("Avengers: Infinity War", "PG-13"), Movie("A Wrinkle in time", "PG"), Movie("Ready player one", "PG-13"), Movie("Red Sparrow", "R"), Movie("The Incredibles 2", "G")};
	
	for (int i = 0; i < size(movies); i++) {
		cout << movies[i].get_name() << ", " << movies[i].get_rating() << endl;
	}

	bubble_sort(movies, size(movies));
	cout << "------------------------------------" << endl;

	for (int i = 0; i < size(movies); i++) {
		cout << movies[i].get_name() << ", " << movies[i].get_rating() << endl;
	}
}