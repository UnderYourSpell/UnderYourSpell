#include "Movie.h"

Movie::Movie() {
	name = "Unknown";
	MPAA_rating = "";
}
Movie::Movie(std::string name, std::string MPAA_rating) : name(name), MPAA_rating(MPAA_rating) {

}

std::string Movie::get_name()
{
	return name;
}

std::string Movie::get_rating()
{
	return MPAA_rating;
}

void Movie::set_name(std::string name)
{
	this->name = name;
}

void Movie::set_rating(std::string rating)
{
	this->MPAA_rating = rating;
}
