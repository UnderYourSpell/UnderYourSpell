#pragma once
#include <string>
// A class to decode and encode bar codes of POSTNET
class Zipcode_decoder
{
private:
	int zip_code;
	int bar_to_zip_decoder(std::string bar_code);	// Decode from bar code to zip code
	std::string zip_to_bar_encoder(int zip_code);	// Encode from zip code to bar code
public:
	Zipcode_decoder(int zip_code);	// Constructor with a zip code input (integer)
	Zipcode_decoder(std::string bar_code);	// Constructor with a bar code input (string)
	int get_zip_code();
	std::string get_bar_code();
};

