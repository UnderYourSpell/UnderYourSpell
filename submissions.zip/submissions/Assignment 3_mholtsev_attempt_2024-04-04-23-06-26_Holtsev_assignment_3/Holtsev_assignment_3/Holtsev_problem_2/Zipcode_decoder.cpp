#include "Zipcode_decoder.h"

Zipcode_decoder::Zipcode_decoder(int zip_code) : zip_code(zip_code) {

}

Zipcode_decoder::Zipcode_decoder(std::string bar_code) {
	zip_code = bar_to_zip_decoder(bar_code);
}

int Zipcode_decoder::bar_to_zip_decoder(std::string bar_code) {
	int temp_zip_code = 0;
	std::string bar_code_list[5][5];
	int count = 1;
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			bar_code_list[i][j] = bar_code[count];	// FIXME: wrong i and j inputs. J drops down to zero.
			count++;
		}
	}
	int zip_code_digit = 0;
	for (int i = 0; i < 5; i++) {
		zip_code_digit += std::stoi(bar_code_list[i][0]) * 7;
		zip_code_digit += std::stoi(bar_code_list[i][1]) * 4;
		zip_code_digit += std::stoi(bar_code_list[i][2]) * 2;
		zip_code_digit += std::stoi(bar_code_list[i][3]) * 1;
		zip_code_digit += std::stoi(bar_code_list[i][4]) * 0;
		if (zip_code_digit == 11) temp_zip_code *= 10;
		else temp_zip_code = temp_zip_code * 10 + zip_code_digit;
		zip_code_digit = 0;
	}
	return temp_zip_code;
}

std::string Zipcode_decoder::zip_to_bar_encoder(int zip_code) {
	std::string encoded_bar_code = "1";
	while (zip_code > 0) {
		int digit = zip_code % 10;
		zip_code /= 10;
		std::string digit_code = "00000";
		int code[] = { 7, 4, 2, 1, 0 };
		if (digit == 0) digit_code = "11000";
		else {
			int j = 0;
			for (int i = 0; j < 2; i++) {
				if (digit >= code[i]) {
					digit_code[i] = '1';
					digit -= code[i];
					j++;
				}
			}
		}
		encoded_bar_code = digit_code + encoded_bar_code;
	}
	encoded_bar_code = "1" + encoded_bar_code;
	return encoded_bar_code;
}

int Zipcode_decoder::get_zip_code() {
	return zip_code;
}

std::string Zipcode_decoder::get_bar_code() {
	return zip_to_bar_encoder(zip_code);
}
