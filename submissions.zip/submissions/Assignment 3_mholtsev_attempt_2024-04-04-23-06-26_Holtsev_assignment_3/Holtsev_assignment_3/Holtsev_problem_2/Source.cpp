#include <iostream>
#include "Zipcode_decoder.h"
using namespace std;


int main() {
	Zipcode_decoder z1(99504);
	cout << z1.get_zip_code() << endl;
	cout << z1.get_bar_code() << endl;
	Zipcode_decoder z2("110100101000101011000010011");
	cout << z2.get_zip_code() << endl;
	cout << z2.get_bar_code() << endl;
	
}