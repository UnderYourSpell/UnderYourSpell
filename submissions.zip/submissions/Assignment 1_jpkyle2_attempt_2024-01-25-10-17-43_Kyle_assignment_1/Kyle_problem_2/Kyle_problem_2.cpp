#include <iostream>
#include <random>
using namespace std;

void getWager(int& money, int& wager) //prompts the user to enter their wager and handles errors
{
	cout << "you have $" << money << ". How much would you like to wager?" << endl;
	cin >> wager;
	while (wager > money || wager < 0)
	{
		cout << "invalid wager, try again: ";
		cin >> wager;
	}
	money -= wager;
}

void getGuess(int& guess) //prompts the user to enter their guess and handles errors
{
	cout << "What number would you like to guess?" << endl;
	cin >> guess;

	while (guess < 1 || guess > 6)
	{
		cout << "Invalid guess, try again: ";
		cin >> guess;
	}
}

int getRolls(int guess) //rolls dice and checks if the match the user's guess. It returns the number of dice that matched the guess
{
	int wins = 0;
	int roll;
	cout << "you rolled: ";
	for (int i = 0; i < 3; ++i)
	{
		roll = rand() % 6;
		cout << roll << " ";
		if (roll == guess) wins++;
	}
	cout << endl;
	return wins;
}

int main()
{
	int money = 100;
	int wager;
	int guess;
	char userInput = ' ';

	while (userInput != 'n')
	{
		getWager(money, wager);
		getGuess(guess);
		switch (getRolls(guess))
		{
			case 0:
				cout << "You lose" << endl;
				break;
			case 1:
				cout << "You guessed one correctly! you made your wager back" << endl;
				money += wager;
				break;
			case 2:
				cout << "You guessed two correctly! you doubled your wager" << endl;
				money += wager * 2;
				break;
			case 3:
				cout << "You guessed all three correctly! you tripled your wager" << endl;
				money += wager * 3;
		}

		if (money == 0) break;
		cout << "would you like to play again? (y/n)" << endl;
		cin >> userInput;

		while (userInput != 'y' && userInput != 'n')
		{
			cout << "Invalid input, try again: " << endl;
			cin >> userInput;
		}
		cout << endl;
	}

	if (money > 100)
	{
		cout << "Good job! You started with $100 and left with $" << money << "!" << endl;
	}
	else if(money > 0)
	{
		cout << "Oh no! You started with $100 and left with $" << money << "!" << endl;
	}
	else
	{
		cout << "Bankrupt! You ran out of money" << endl;
	}
}

























