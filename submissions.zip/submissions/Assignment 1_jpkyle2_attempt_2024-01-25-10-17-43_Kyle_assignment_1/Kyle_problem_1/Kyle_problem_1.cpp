#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	int firstDigits[9] = {0};
	int tempNum;

	for (int i = 0; i < 3295; ++i)
	{
		cin >> tempNum;
		if (tempNum == 0) break;

		while (tempNum > 10)
		{
			tempNum /= 10;
		}

		firstDigits[tempNum - 1]++;
	}

	for (int i = 0; i < 9; ++i)
	{
		cout << i + 1 << "s: " << firstDigits[i] << endl;
		cout << "distribution: %" << fixed << setprecision(2) << firstDigits[i] / 32.95 << endl;
	}

}
