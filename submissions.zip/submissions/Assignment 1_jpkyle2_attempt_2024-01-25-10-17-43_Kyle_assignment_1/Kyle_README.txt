for problem 1 run the code with this command in the unix command line:
./a.out < enrollments.txt

for problem 2 run as normal:
./a.out

for problem 3 run as normal:
./a.out