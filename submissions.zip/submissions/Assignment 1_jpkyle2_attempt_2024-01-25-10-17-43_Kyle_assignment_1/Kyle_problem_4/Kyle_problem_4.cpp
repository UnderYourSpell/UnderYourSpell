#include <iostream>
using namespace std;

void getChange(int change, int& quarters, int& dimes, int& nickels, int& pennies)
{
	while (change > 25)
	{
		change -= 25;
		quarters++;
	}

	while (change > 10)
	{
		change -= 10;
		dimes++;
	}

	while (change > 5)
	{
		change -= 5;
		nickels++;
	}

	while (change > 0)
	{
		change--;
		pennies++;
	}
}



int main()
{
	int quarters = 0;
	int dimes = 0;
	int nickels = 0;
	int pennies = 0;

	cout << "for 85 cents:" << endl;
	getChange(85, quarters, dimes, nickels, pennies);
	cout << "Quarters: " << quarters << endl;
	cout << "Dimes: " << dimes << endl;
	cout << "Nickels: " << nickels << endl;
	cout << "Pennies: " << pennies << endl;

	cout << endl;

	quarters = 0;
	dimes = 0;
	nickels = 0;
	pennies = 0;

	cout << "for 37 cents: " << endl;
	getChange(37, quarters, dimes, nickels, pennies);
	cout << "Quarters: " << quarters << endl;
	cout << "Dimes: " << dimes << endl;
	cout << "Nickels: " << nickels << endl;
	cout << "Pennies: " << pennies << endl;
}
