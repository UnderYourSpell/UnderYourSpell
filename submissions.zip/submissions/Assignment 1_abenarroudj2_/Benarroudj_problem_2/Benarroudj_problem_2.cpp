#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

// Function to roll the dice
int rollDice() {
    return rand() % 6 + 1;
}

int main() {
  // Seed the random number generator
  srand(time(0));

  int money = 100;
  int wager;
  int chosenNumber;
  char playAgain;
  bool continuePlaying = true;

  cout << "Welcome to Chuck-a-luck!\n";

  while (continuePlaying) {
    cout << "\nYou currently have $" << money << ".\n";
    cout << "Enter your wager (or enter 0 to quit): $";
    cin >> wager;

    if (wager == 0) {
      cout << "Thanks for playing!\n";
      break;
    }

    if (wager > money) {
        cout << "You can't wager more than you have!\n";
        continue;
    }

    cout << "Choose a number between 1 and 6: ";
    cin >> chosenNumber;

    if (chosenNumber < 1 || chosenNumber > 6) {
      cout << "Invalid number. Please choose a number between 1 and 6.\n";
      continue;
    }

    // subtract the wager from the "wallet"
    money = money - wager;

    
    // Roll the dice
    int roll1 = rollDice();
    int roll2 = rollDice();
    int roll3 = rollDice();

    cout << "The dice roll results are: " << roll1 << " " << roll2 << " " << roll3 << endl;

    // Determine outcome
    if ( (roll1 == chosenNumber) || (roll2 == chosenNumber) || (roll3 == chosenNumber) ) {
        cout << "You've won your money back !!!" << endl;
        money += 1 * wager;
    }
    else if ( ((roll1 == chosenNumber) && (roll2 == chosenNumber)) || ((roll1 == chosenNumber) && (roll3 == chosenNumber)) || ((roll2 == chosenNumber) && (roll3 == chosenNumber)) ) {
        cout << "Congrats, You've won double !!!" << endl;
      money += 2 * wager;
    }
    else if ( (roll1 == chosenNumber) && (roll2 == chosenNumber) && (roll3 == chosenNumber) ) {
        cout << "Congrats, You've won triple !!!" << endl;
      money += 3 * wager;
    }
    else {
        cout << "Sorry, you lost. Better luck next time!" << endl;
    }

    cout << "Would you like to play again? (y/n): ";
    cin >> playAgain;

    if (playAgain != 'y' && playAgain != 'Y') {
      continuePlaying = false;
    }
  }

  cout << "Thank you for playing!\n";

  return 0;
}