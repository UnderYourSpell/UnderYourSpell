#include <iostream>
using namespace std;

void calculateChange(int change, int &quarters, int &dimes, int &nickels, int &pennies) {
  quarters = change / 25;
  change %= 25;

  dimes = change / 10;
  change %= 10;

  nickels = change / 5;
  change %= 5;

  pennies = change;
}

int main() {
  int change, quarters, dimes, nickels, pennies;

  // Test Case 1: amount = 73
  change = 99;
  calculateChange(change, quarters, dimes, nickels, pennies);
  cout << "For " << change << " cents, you need:\n";
  cout << quarters << " quarters, " << dimes << " dimes, " << nickels << " nickels, and " << pennies << " pennies." << endl;

    
  // Test Case 2: amount = 38
  change = 67;
  calculateChange(change, quarters, dimes, nickels, pennies);
  cout << "\nFor " << change << " cents, you need:\n";
  cout << quarters << " quarters, " << dimes << " dimes, " << nickels << " nickels, and " << pennies << " pennies." << endl;

  return 0;
}
