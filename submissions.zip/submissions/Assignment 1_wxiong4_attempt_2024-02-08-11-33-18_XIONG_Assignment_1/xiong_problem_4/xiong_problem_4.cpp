#include <iostream>


void change(int changes, int& quarters, int& dimes, int& nickels, int& pennies)
{
	if (changes > 1 && changes < 99){ 

		int remainder;
		int amount = changes;

		// compute quarters
		quarters = amount / 25;
		remainder = amount % 25;

		// compute dimes
		dimes = remainder / 10;
		remainder = remainder % 10;

		// compute nickels
		nickels = remainder / 5;
		remainder = remainder % 5;

		// compute pennies
		pennies = remainder / 1;
	}
	else { std::cout << "Change must be between 1-99" << std::endl; }
}

int main()
{
	// variable declarations
	int changes;
	int quarters = 0;
	int dimes = 0;
	int nickels = 0;
	int pennies = 0;

	// change test cases
	int test_one = 40;
	int test_two = 96;

	// test case 1
	std::cout << "Test 1: " << test_one  << std::endl;
	change(test_one, quarters, dimes, nickels, pennies);

	// result
	std::cout << "Give the customer: "
		  << quarters << " quarters, "
		  << dimes    << " dimes, "
		  << nickels  << " nickels, and "
		  << pennies  << " pennies."
 	          << std::endl;


	// test case 2
	std::cout << "Test 2: " << test_two << std::endl;
	change(test_two, quarters = 0, dimes = 0, nickels = 0, pennies = 0);

	std::cout << "Give the customer: "
		  << quarters << " quarters, "
		  << dimes    << " dimes, "
		  << nickels  << " nickels, and "
		  << pennies  << " pennies."
 	          << std::endl;


	// program ran successfully
	return 0;
}

