#include <iostream>
#include <math.h>
using namespace std;

int main()
{
	int count[10] = {0,0,0,0,0,0,0,0,0,0};
	int input;

	// calculate results
	for (int i = 0; i < 3295; i++){
		cin >> input;
		input = floor(input);
		while (input >=  10){
			if (abs(10 - input) < 0.001) { input = 1; }
			else { input /= 10.0; }
		 }

		++count[input];
	}

	// print results
	for (int i = 0; i < 10; i++){
		std::cout << "Start with " << i << ": " << count[i] << std::endl;
	}

	// program ran successfully
	return 0;
}
