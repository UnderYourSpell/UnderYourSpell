Problem 1:
Seems to work perfectly fine.
	
	Steps to run:
		Execute with along with "< Enrollments.txt"

Problem 2:

There doesn't seem to be any noticeable problems from my end. Though admittedly, for the function requirement, my dice roll function is quite uneccessary.
However, since it's such a small program I couldn't find anywhere in the code where a user-made function would make more sense.

Problem 3:
-Explained in text file.

Problem 4:

I haven't noticed any problems with the program. Though it'd be visually nice if I didn't print out the coins with a zero count.
For example, $0.79 is 3 quarters, 0 dimes, 0 nickels, and 4 pennies. Ideally, the program only prints out quarters and pennies. 
Howevere, that'll require multiple if statements, and I figured the code would be prettier without it.


