#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>

int dice_roll()
{
	return rand() % 6 + 1;
}

int main()
{
	// seed random
	srand(time(NULL));

	// declare variables
	std::vector<int> rolls;
	double player_bank = 100.00;
	double wager;
	int n;
	int matches;
	int round = 0;

	std::cout << "Welcome to \'Chuck-a-Luck\' ! " << std::endl;
	std::cout << "Your balance is: $100" << std::endl;

	do {
		std::cout << "Round:" << ++round << std::endl;

		// prompt user for their wager amount
		while(player_bank > 0){
			std::cout << "Enter the amount you'd like to wager: ";
			std::cin  >> wager;

			// check input
			if (wager > player_bank){ std::cout << "You can not wager over: " << player_bank << std::endl; }
			else if (wager  < 0) { std::cout << "Must be a positive value" <<  std::endl; }
			else {
				std::cout << "You wagered: " << wager << std::endl;
				break;
			}
		}

		// promp user for dice roll
		do {
			std::cout << "Predict the dice roll, enter a value [1-6]: ";
			std::cin  >> n;
		}while (n < 1 || n > 6);

		// roll the dice
		matches = 0;
		for (int i = 0; i < 3; i++){
			int roll = dice_roll();
			std::cout << "Roll " << i + 1 << " is " << roll << std::endl;
			if(n == roll) { matches++; }
		}

		// compute
		player_bank += wager * (matches - 1);

		std::cout << "You had " << matches << " matches" << std::endl;
		std::cout << "Your new balance: " << player_bank << std::endl;
		std::cout << "----------------------------------" << std::endl;

	}while (player_bank > 0);

	// Tell the user they lost
	std::cout << "You lost" << std::endl;

	// program ran successfully
	return 0;

}

