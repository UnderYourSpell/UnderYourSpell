#include <iostream>

using namespace std;

void change(int total, int & quarters, int & dimes, int & nickels, int & pennies)
{
int change;
int q = 25;
int d = 10;
int n = 5;
int p = 1;
quarters = total / q;
total = total % q;
dimes = total / d;
total = total % d;
nickels = total / 5;
pennies = total % n;
}

int main()
{
int total, quarters, dimes, nickels, pennies;
cout << "Enter first amount of change." << endl;
cin >> total;
change(total, quarters, dimes, nickels, pennies);

cout << quarters << " quarters, " << dimes << " dimes, " << nickels << " nickels, " << pennies << " pennies." << endl;

cout << "Enter second amount of change." << endl;
cin >> total;
change(total, quarters, dimes, nickels, pennies);
cout << quarters << " quarters, " << dimes << " dimes, " << nickels << " nickels, " << pennies << " pennies." << endl;

return 0;
}
