#include <iostream>

using namespace std;

int diceroll()
{
return rand() % 6 + 1;
}

int bett(int cash)
{
int bet;
cash = cash;
cout << "Current balance: $" << cash << endl;
cout << "How much would you like to bet?" << endl;
cin >> bet;
if(bet <= 0 || bet > cash)
{
cout << "Unacceptable bet, try again." << endl;
bett(cash);
}
return bet;
}

int xp()
{
int x;
cout << "Which number would you like to bet on?" << endl;
cin >> x;
if(x < 1 || x > 6)
{
cout << "Invalid input, try again." << endl;
xp();
}
return x;
}

int main()
{
int cash = 100;
int bet;
char test = 'y';
int dummy;

cout << "Welcome to Chuck-a-Luck" << endl;

while(test == 'y' && cash > 0)
{
int x = xp();
int bet = bett(cash);
cash = cash - bet;
for(int i = 0; i < 3; ++i)
{
dummy = diceroll();
cout << "Die " << i << ": " << dummy << endl;
if(dummy == x)
{
cash += bet;
}
}

cout << "Updated Balance: $" << cash << endl;
if(cash > 0)
{
cout << "Would you like to play again? Enter 'y' to play again, enter any other character to quite." << endl;
cin >> test;
}
}

return 0;
}
