#include <iostream>

using namespace std;

int main()
{
string test;
int data[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};

for(int w = 0; w < 3295; w++)
{

cin >> test;

for(int i = 1; i < 10; i++)
{

if(test.at(0) - 48 == i)
{
data[i - 1] = data[i - 1] + 1;
}
}
}

for(int j = 1; j < 10; ++j)
{
cout << j << ": " << data[j - 1] << endl;
}

return 0;
}
