#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    int numbers[3295];

    ifstream file("enrollments.txt");

    if (!file)
    {
        cout << "File not found!" << endl;
        return 1;
    }

    for (int i = 0; i < 3295; i++)
    {
        file >> numbers[i];
    }

    file.close();

    int count[10] = {0};

    for (int i = 0; i < 3295; i++)
    {
        int leadingDigit = numbers[i];

        while (leadingDigit >= 10)
        {
            leadingDigit /= 10;
        }

        count[leadingDigit]++;
    }

    for (int i = 1; i < 10; i++)
    {
        cout << i << ": " << count[i] << endl;
    }

    return 0;
}
