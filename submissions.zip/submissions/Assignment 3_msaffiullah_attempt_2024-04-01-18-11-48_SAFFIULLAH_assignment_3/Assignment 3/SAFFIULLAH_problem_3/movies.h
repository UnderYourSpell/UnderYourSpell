#ifndef MOVIES_H
#define MOVIES_H

#include <iostream>

class Movie 
{
    private:
        std::string name;
        std::string rating;
    public:
        Movie(std::string name, std::string rating);
        std::string getName();
        std::string getRating();
        void setName(std::string name);
        void setRating(std::string rating);
};

#endif