#include <iostream>
#include <string>
#include "movies.h"

using namespace std;

Movie::Movie(string name, string rating)
{
    this->name = name;
    this->rating = rating;
}

string Movie::getName()
{
    return name;
}

string Movie::getRating()
{
    return rating;
}

void Movie::setName(string name)
{
    this->name = name;
}

void Movie::setRating(string rating)
{
    this->rating = rating;
}