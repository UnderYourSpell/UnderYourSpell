#include <iostream>
#include <string>
#include "movies.h"

using namespace std;

void sortMovies(Movie movies[], int size)
{
    for (int i = 0; i < size - 1; i++)
    {
        for (int j = 0; j < size - 1 - i; j++)
        {
            if (movies[j].getName() > movies[j + 1].getName())
            {
                Movie temp = movies[j];
                movies[j] = movies[j + 1];
                movies[j + 1] = temp;
            }
        }
    }
}

int main()
{
    Movie movies[6] = 
    {
        Movie("Black Panther", "PG-13"),
        Movie("Avengers: Infinity War", "PG-13"),
        Movie("A Wrinkle In Time", "PG"),
        Movie("Ready Player One", "PG-13"),
        Movie("Red Sparrow", "R"),
        Movie("The Incredibles 2", "G")
    };

    sortMovies(movies, 6);

    for (int i = 0; i < 6; i++)
    {
        cout << movies[i].getName() << ", " << movies[i].getRating() << endl;
    }

    return 0;
}