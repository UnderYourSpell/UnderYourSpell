** I used Visual Studio Code for this assignment so I will describe how to run the programs in that IDE (it might be different 
if you're using Visual Studio, for example) **

** For all the questions, make sure that it's corresponding .h and .cpp files are in the same directory and that your terminal is also
in that same directory. You can go to the directory of the specific question by using the cd command in the terminal. **

Question 1: 
You can open the terminal and type in this command and press enter: g++ -o main.exe main.cpp Pair.cpp
That command compiles the program. To run it, use this command and press enter: .\main.exe 

Question 2:
Follow the same procedure as compiling and running question 1. The commands are just slightly different.
For compiling: g++ -o main.exe main.cpp postnet.cpp
For running: .\main.exe

Question 3:
For compiling: g++ -o main.exe main.cpp movies_class.cpp
For running: .\main.exe

Question 4:
You can run this program by simply opening benfords_law.cpp in the IDE and pressing the run button on the top right.

Question 5:
For compiling: g++ -o main.exe main.cpp maze.cpp
For running: .\main.exe