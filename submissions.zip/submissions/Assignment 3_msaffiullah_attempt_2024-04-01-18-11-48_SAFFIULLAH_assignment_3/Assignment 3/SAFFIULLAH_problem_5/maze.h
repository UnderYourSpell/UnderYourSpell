#ifndef MAZE_H
#define MAZE_H

#include <iostream>
#include <ctime>
#include <cstdlib>

const int WIDTH = 20;
const int HEIGHT = 20;

class Maze 
{
public:
    Maze();
    void printMaze(int curx, int cury);
    bool search(int x, int y, int solutionX[], int solutionY[], int &numEntries);
    void addToArrays(int x[], int y[], int &numEntries, int xVal, int yVal);
    bool validMove(int newX, int newY);
    bool move(int &curX, int &curY, int newX, int newY);

private:
    char maze[HEIGHT][WIDTH];
    bool visited[HEIGHT][WIDTH];
};

#endif
