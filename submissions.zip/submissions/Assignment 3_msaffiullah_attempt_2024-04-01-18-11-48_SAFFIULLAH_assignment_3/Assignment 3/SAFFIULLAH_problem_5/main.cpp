#include <iostream>
#include "maze.h"

using namespace std;

int main() 
{
    Maze maze;

    int solutionX[(20 - 2) * (20 - 2)], solutionY[(20 - 2) * (20 - 2)];
    int numPoints = 0;

    bool found = maze.search(1, 1, solutionX, solutionY, numPoints);

    if (!found) 
    {
        cout << "No solution found.";
    } 

    else 
    {
        cout << "Solution found!  Here is the path from the start." << endl;

        for (int i = numPoints - 1; i >= 0; i--) 
        {
            maze.printMaze(solutionX[i], solutionY[i]);
            cout << endl;
        }
    }

    return 0;
}