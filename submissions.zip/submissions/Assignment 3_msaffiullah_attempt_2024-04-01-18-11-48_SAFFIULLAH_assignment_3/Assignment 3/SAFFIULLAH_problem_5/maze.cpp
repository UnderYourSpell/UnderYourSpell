#include "maze.h"
#include <iostream>

using namespace std;

Maze::Maze() 
{
    srand(time(NULL));

    for (int x = 0; x < WIDTH; x++)
    {
        for (int y = 0; y < HEIGHT; y++) 
        {
            maze[y][x] = ' ';
        }
    }

    for (int x = 0; x < WIDTH; x++) 
    {
        maze[0][x] = 'X';
        maze[HEIGHT - 1][x] = 'X';
    }

    for (int y = 0; y < HEIGHT; y++) 
    {
        maze[y][0] = 'X';
        maze[y][WIDTH - 1] = 'X';
    }

    int numCells = static_cast<int>((HEIGHT - 2) * (WIDTH - 2) * 0.25);
    int count = 0;

    while (count < numCells) 
    {
        int x = (rand() % (WIDTH - 2)) + 1;
        int y = (rand() % (HEIGHT - 2)) + 1;

        if (maze[y][x] == ' ') 
        {
            maze[y][x] = 'X';
            count++;
        }
    }

    int x = (rand() % (WIDTH - 2)) + 1;
    int y = (rand() % (HEIGHT - 2)) + 1;

    while (maze[y][x] == 'X') 
    {
        x = (rand() % (WIDTH - 2)) + 1;
        y = (rand() % (HEIGHT - 2)) + 1;
    }

    int exitX = (rand() % (WIDTH - 2)) + 1;
    int exitY = (rand() % (HEIGHT - 2)) + 1;

    while (maze[exitY][exitX] == 'X') 
    {
        exitX = (rand() % (WIDTH - 2)) + 1;
        exitY = (rand() % (HEIGHT - 2)) + 1;
    }

    maze[exitY][exitX] = 'E';

    for (int x = 0; x < WIDTH; x++) 
    {
        for (int y = 0; y < HEIGHT; y++) 
        {
            visited[y][x] = false;
        }
    }

    visited[y][x] = true;
}

void Maze::printMaze(int curx, int cury) 
{
    for (int y = 0; y < HEIGHT; y++) 
    {
        for (int x = 0; x < WIDTH; x++) 
        {
            if ((x == curx) && (y == cury)) 
            {
                cout << "@";
            } 
            
            else 
            {
                cout << maze[y][x];
            }
        }

        cout << endl;
    }
}

bool Maze::search(int x, int y, int solutionX[], int solutionY[], int &numEntries) 
{
    bool foundExit = false;

    if (maze[y][x] == 'E') 
    {
        return true;
    }

    visited[y][x] = true;

    if (validMove(x, y - 1)) 
    {
        foundExit = search(x, y - 1, solutionX, solutionY, numEntries);
    }

    if (!foundExit && validMove(x, y + 1)) 
    {
        foundExit = search(x, y + 1, solutionX, solutionY, numEntries);
    }

    if (!foundExit && validMove(x - 1, y)) 
    {
        foundExit = search(x - 1, y, solutionX, solutionY, numEntries);
    }

    if (!foundExit && validMove(x + 1, y)) 
    {
        foundExit = search(x + 1, y, solutionX, solutionY, numEntries);
    }

    if (foundExit) 
    {
        addToArrays(solutionX, solutionY, numEntries, x, y);
        return true;
    }

    return false;
}

void Maze::addToArrays(int x[], int y[], int &numEntries, int xVal, int yVal) 
{
    x[numEntries] = xVal;
    y[numEntries] = yVal;
    numEntries++;
}

bool Maze::validMove(int newX, int newY) 
{
    if (newX < 0 || newX >= WIDTH) 
    {
        return false;
    }

    if (newY < 0 || newY >= HEIGHT) 
    {
        return false;
    }

    if (maze[newY][newX] == 'X') 
    {
        return false;
    }

    if (visited[newY][newX]) 
    {
        return false;
    }

    return true;
}

bool Maze::move(int &curX, int &curY, int newX, int newY) 
{
    bool foundExit = false;

    if (maze[newY][newX] == 'E') 
    {
        foundExit = true;
    }

    curX = newX;
    curY = newY;
    visited[curY][curX] = true;

    return foundExit;
}