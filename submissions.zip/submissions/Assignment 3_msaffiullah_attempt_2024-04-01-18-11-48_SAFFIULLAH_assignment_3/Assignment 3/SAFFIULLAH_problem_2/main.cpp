#include <iostream>
#include "postnet.h"

using namespace std;

int main()
{
    Postnet postalCode("110100101000101011000010011");
    cout << "ZIP code: " << postalCode.getZipCode() << endl;

    Postnet postalCode2(99504);
    cout << "Bar code: " << postalCode2.getBarCode() << endl;

    return 0;
}