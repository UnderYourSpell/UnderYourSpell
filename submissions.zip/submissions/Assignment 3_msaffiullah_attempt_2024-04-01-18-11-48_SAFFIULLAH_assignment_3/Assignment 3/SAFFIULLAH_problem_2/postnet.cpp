#include <iostream>
#include <string>
#include "postnet.h"

using namespace std;

Postnet::Postnet(int zipCode) : zipCode(zipCode) {}

Postnet::Postnet(string barCode) : barCode(barCode) {}

int Postnet::getZipCode()
{
    if (!checkBarCode())
    {
        cout << "Invalid bar code!" << endl;
        return -1;
    }

    if (!hasTwoConsecOnes())
    {
        cout << "Invalid bar code!" << endl;
        return -1;
    }

    return calcZipCode();
}

string Postnet::getBarCode()
{
    return "1" + getFiveDigitVals() + "1";
}

bool Postnet::checkBarCode()
{
    return barCode.length() == 27 && barCode[0] == '1' && barCode[26] == '1';
}

bool Postnet::hasTwoConsecOnes()
{
    for(int i = 1; i <= 25; i += 5)
    {
        int ones = 0;

        for (int j = i; j <= i + 4; j++)
        {
            if (barCode[j] == '1')
            {
                ones++;
            }
        }

        if (ones != 2)
        {
            return false;
        }
    }

    return true;
}

int Postnet::calcZipCode()
{
    int result = 0;
    int sumArr[5] = {0};
    int weights[5] = {7, 4, 2, 1, 0};

    for (int i = 0; i < 5; i++)
    {
        for (int j = 0; j < 5; j++)
        {
            sumArr[i] += (static_cast<int>(barCode[i * 5 + j + 1]) - 48) * weights[j];
        }

        if (sumArr[i] == 11) 
        {
            sumArr[i] = 0;
        }
    }

    int multiplier = 10000;

    for (int i = 0; i < 5; i++)
    {
        result += sumArr[i] * multiplier;
        multiplier /= 10;
    }

    return result;

}

string Postnet::getFiveDigitVals()
{
    const string barCodes[10] = 
    {
        "11000", "00011", "00101", "00110", "01001",
        "01010", "01100", "10001", "10010", "10100"
    };

    string zipCodeStr = "";
    int zipCode = this->zipCode;

    for (int i = 0; i < 5; i++)
    {
        int digit = zipCode % 10;
        zipCode /= 10;
        zipCodeStr = barCodes[digit] + zipCodeStr;
    }

    return zipCodeStr;
}