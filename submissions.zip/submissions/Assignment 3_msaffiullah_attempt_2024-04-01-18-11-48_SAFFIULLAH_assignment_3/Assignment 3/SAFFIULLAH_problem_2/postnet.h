#ifndef POSTNET_H
#define POSTNET_H

#include <string>

class Postnet
{
public:
        int getZipCode();
        std::string getBarCode();

        Postnet(int zipCode);
        Postnet(std::string barCode);

    private:
        std::string barCode;
        int zipCode;

        bool checkBarCode();
        bool hasTwoConsecOnes();
        int calcZipCode();
        std::string getFiveDigitVals();
};

#endif