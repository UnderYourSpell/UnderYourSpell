#include <iostream>

using namespace std;

int get_first_digit(int &a) {
	/* Get the first digit of a number */
    while (a > 10) {
        a /= 10;
    }
    return a;
}
int main() {
    int count_arr[9] = { 0 };
    int a;
    while (cin >> a) {		// Count the amount of first digits in numbers
        get_first_digit(a);
        count_arr[a - 1]++;
    }

    for (int i=0; i < size(count_arr); i++) {	// Output the amount
        cout << i + 1 << ": " << count_arr[i] << endl;
    }
    return 0;
}
