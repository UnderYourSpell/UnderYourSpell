#include <iostream>

using namespace std;

void change_dispenser(int amount, int& quarters, int& dimes, int& nickels, int& pennies) {
	/* Dispense the amount of change to the coins */
	quarters = amount / 25;
	amount -= quarters * 25;
	dimes = amount / 10;
	amount -= dimes * 10;
	nickels = amount / 5;
	amount -= nickels * 5;
	pennies = amount;
	
}
int main() {
	int test;
	
	for (int i = 0; i < 2; i++) {	// run two tests with user inputs
		int quarters = 0, dimes = 0, nickels = 0, pennies = 0;
		cout << "Input an amount of change 1-99: ";
		cin >> test;
		change_dispenser(test, quarters, dimes, nickels, pennies);
		cout << "quarters: " << quarters << "\ndimes: " << dimes << "\nnickels: " << nickels << "\npennies" << pennies << endl;
	}
	
}