#include <iostream>
#include <random>
#include <ctime>
using namespace std;

void roll_dice(int arr[]) {
	/* Roll three dices of 1-6 */
    arr[0] = rand() % 6 + 1;
    arr[1] = rand() % 6 + 1;
    arr[2] = rand() % 6 + 1;
    cout << "You got " << arr[0] << ", " << arr[1] << ", and " << arr[2] << endl;
}

int main() {
    srand(time(NULL));
    int dice_arr[3] = {};
    int money = 100, wager, num, wins=0;
    string play = "yes";

    cout << "Welcome to the chuck-a-luck gamble game!\nYou currently have $100." << endl;
    while (play[0] == 'y' or play[0] == 'Y') {	// Start the game
        cout << "Place your wager : ";
        while (cin >> wager) {	// Input the wager
            if (wager <= money and wager > 0) {
                money -= wager;
                break;
            }
            cout << "Your balance is $" << money << ". Please select an appropriate amount: ";
        }
        
        cout << "Select a number 1-6: ";
        while (cin >> num) {	// Input a bet
            if (num > 0 and num < 7)
                break;
            cout << "Please enter a valid number 1-6: ";
        }
        
        roll_dice(dice_arr);
        for (int i=0; i < 3; i++) {		// Check how many match
            if (dice_arr[i] == num) {
                wins++;
            } 
        }
        
        cout << wins << " correct guesses. You get $" << wins * wager << "." << endl;	// How much money you win
        money += wager * wins;
        wins = 0;
        cout << "You balance is $" << money << endl;
        if (money == 0) {
            cout << "You have no money left! Ending the game..." << endl;
            break;
        }
            
        cout << "Do you want to play again? (yes/no): ";
        cin >> play;
        cout << endl;

    }

    return 0;
}
