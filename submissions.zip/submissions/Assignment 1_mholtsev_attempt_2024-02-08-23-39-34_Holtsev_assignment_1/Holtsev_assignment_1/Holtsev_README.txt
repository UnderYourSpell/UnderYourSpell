How to run programs:
1 program: "./a.out < enrollment.txt" on a unix system.
2 program: "./a.out" on a unix system and input what is asked. 
3 program: double click on the txt file and read!
4 program: "./a.out" on a unix system and input what is asked.
Everything works!