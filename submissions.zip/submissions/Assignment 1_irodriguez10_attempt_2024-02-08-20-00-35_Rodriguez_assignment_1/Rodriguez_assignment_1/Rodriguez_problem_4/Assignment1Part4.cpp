#include <iostream>
using namespace std;

void calcCoins(int numChange, int &numQuarters, int &numDimes, int &numNickels, int &numPennies) { 
	numQuarters = numChange / 25;
	numChange = numChange % 25;
	numDimes = numChange / 10;
	numChange = numChange % 10;
	numNickels = numChange / 5;
	numChange = numChange % 5;
	numPennies = numChange;
}

int main() {
	int change = 0;
	int numQuarters, numDimes, numNickels, numPennies;
	while (change < 1 || change > 99 || cin.fail()) {
		cout << "Enter change: ";
		cin >> change;
		cout << endl;
	}

	calcCoins(change, numQuarters, numDimes, numNickels, numPennies);
	cout << numQuarters << ((numQuarters == 1) ? " quarter\n" : " quarters\n");
	cout << "\n" << numDimes << ((numDimes == 1) ? " dime\n" : " dimes\n");
	cout << "\n" << numNickels << ((numNickels == 1) ? " nickel\n" : "nickels\n");
	cout << "\n" << numPennies << ((numPennies == 1) ? " penny\n" : " pennies\n");

	return 0;
}
