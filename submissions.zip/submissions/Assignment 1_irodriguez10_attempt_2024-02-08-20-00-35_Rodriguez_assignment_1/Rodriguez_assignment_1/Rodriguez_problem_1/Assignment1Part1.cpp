#include <iostream>
using namespace std;

int main() {

	int benfordCounter[9]; // Index 0 = 1, Index 8 = 9.
	for (int i = 0; i < 3295; i++) {
		unsigned int currNum = 0;
		cin >> currNum;
		while (currNum >= 10) {
			currNum /= 10;
		}
		switch(currNum) {
			case 1:
				benfordCounter[0]++;
				break;
			case 2:
				benfordCounter[1]++;
				break;
			case 3:
				benfordCounter[2]++;
				break;
			case 4:
				benfordCounter[3]++;
				break;
			case 5:
				benfordCounter[4]++;
				break;
			case 6:
				benfordCounter[5]++;
				break;
			case 7:
				benfordCounter[6]++;
				break;
			case 8:
				benfordCounter[7]++;
				break;
			case 9:
				benfordCounter[8]++;
				break;
			default:
				break;
		}
	}

	for (int i = 0; i < 9; i++) {
		double chance = (static_cast<double>(benfordCounter[i]) / 3295.0) * 100;
		cout << "\n" << (i + 1) << " was used " << benfordCounter[i] << " times, or " << chance << "% of the time." << endl;
	}
	return 0;
}
