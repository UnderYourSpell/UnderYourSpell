#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

// Chuck-a-luck!
int rollDie() {
	return (rand() % 6) + 1;
}

void endScreen(double money, int numTries) {
    if (money == 0) {
        cout << "\nYou ran out of money! You gambled " << numTries << ((numTries == 1) ? " time" : " times") << endl;
    }
    else {
        cout << "\nYou finished Chuck-a-luck with " << money << " remaining.\nYou gambled " << numTries << ((numTries == 1) ? " time." : " times.") << endl;
    }
    abort();
}

int main() {
	srand(time(0));
	double playerMoney = 100;
	int gambles = 0;

	cout << "This program is meant to simulate a game of Chuck-a-luck!" << endl;

	while (playerMoney > 0) {
		cout << "\nYou have $" << fixed << setprecision(2) << playerMoney << ". Enter your wager: ";
		double wager;
		cin >> wager;

		while (cin.fail() || wager > playerMoney || wager <= 0) {
			cin.clear();
			cin.ignore(1000, '\n');
			cout << "Invalid input. Enter a valid wager: ";
			cin >> wager;
		}

		cout << "Enter a number 1-6 to guess the dice, or -1 to quit early: ";
		int selectNum;
		cin >> selectNum;
		if (selectNum == -1) {
            endScreen(playerMoney, gambles);
		}

		while (cin.fail() || selectNum < 1 || selectNum > 6) {
			cin.clear();
			cin.ignore(1000, '\n');
			cout << "Invalid input. Enter a number 1-6 to guess the dice, or -1 to quit early: "; // Sentinel value = -1
			cin >> selectNum;
            if (selectNum == -1) {
                endScreen(playerMoney, gambles);
            }
		}
		gambles++;

		int countMatches = 0;
		int dice[3] = {0};

		for (int i = 0; i < 3; i++) {
			dice[i] = rollDie();
			cout << "\nYou rolled a " << dice[i] << ".";
			if (dice[i] == selectNum) {
				countMatches++;
			}
		}

		if (countMatches == 0) {
			cout << "\n\nNo matches! You lose $" << fixed << setprecision(2) << wager << "!\n";
			playerMoney -= wager;
		}
		else {
			double winnings = wager * countMatches;
			cout << "\nYou matched " << countMatches << ((countMatches == 1) ? " die" : " dice") << ". You win $" << fixed << setprecision(2) << winnings << "!\n";
			playerMoney += winnings;
		}
	}

	endScreen(playerMoney, gambles);

	return 0;
}
