#include <iostream>
#include <string>
#include <vector>

class ZipCode {
private:
    int zipCode;

    int decodeGroup(const std::string& group) const {
        int values[5] = {7, 4, 2, 1, 0};
        int sum = 0;
        for (int i = 0; i < 5; ++i) {
            if (group[i] == '1') {
                sum += values[i];
            }
        }
        return sum == 11 ? 0 : sum;
    }

    std::string encodeGroup(int digit) const {
        std::string barCodeGroup = "00000";
        int values[5] = {7, 4, 2, 1, 0};
        for (int i = 0; digit > 0 && i < 5; ++i) {
            if (digit >= values[i]) {
                barCodeGroup[i] = '1';
                digit -= values[i];
            }
        }
        return barCodeGroup;
    }

    std::string encodeZip() const {
        int tempZip = zipCode;
        std::string barCode = "1";
        for (int i = 10000; i > 0; i /= 10) {
            int digit = (tempZip / i) % 10;
            barCode += encodeGroup(digit);
        }
        barCode += "1";
        return barCode;
    }

    void decodeZip(const std::string& barCode) {
        zipCode = 0;
        for (int i = 1; i < barCode.length() - 5; i += 5) {
            std::string group = barCode.substr(i, 5);
            int digit = decodeGroup(group);
            zipCode = zipCode * 10 + digit;
        }
    }

public:
    ZipCode(int zipCode) : zipCode(zipCode) {}

    ZipCode(const std::string& barCode) {
        decodeZip(barCode);
    }

    int getZipCode() const {
        return zipCode;
    }

    std::string getBarCode() const {
        return encodeZip();
    }
};

int main() {
    ZipCode zip1(99504);
    std::cout << "Zip Code: " << zip1.getZipCode() << ", Bar Code: " << zip1.getBarCode() << std::endl;

    ZipCode zip2("110100101000101011000010011");
    std::cout << "Zip Code: " << zip2.getZipCode() << ", Bar Code: " << zip2.getBarCode() << std::endl;

    return 0;
}
