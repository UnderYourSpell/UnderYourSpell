#include <iostream>
#include "Pair.h"

using namespace std;

int main()
{
	Pair p1(5, 10);
	Pair p2(1, 2);

	// Outputs 5 and 10
	cout << p1.get1() << " " << p1.get2() << endl;
	// Outputs 1 and 2
	cout << p2.get1() << " " << p2.get2() << endl;

	Pair p3 = p2 + p1;
	// Outputs 6 and 12
	cout << p3.get1() << " " << p3.get2() << endl;

	p3 = p3 + 2; //the Pair class can add another pair to
	//itself or add a number to its elements,
	//but it can't handle a number being added to it from the left side, 
	//like "2 + a Pair." This is because the class is only designed to add to itself, not to be added to by something else.

	// Outputs 8 and 14
	cout << p3.get1() << " " << p3.get2() << endl;
}

