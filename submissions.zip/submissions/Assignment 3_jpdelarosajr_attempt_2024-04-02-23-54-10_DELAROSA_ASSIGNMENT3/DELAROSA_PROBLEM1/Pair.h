#pragma once

class Pair {
private:
    int num1, num2;
public:
    Pair();
    Pair(int num1, int num2);
    int get1() const;
    int get2() const;
    // Friend declaration for the + operator functions
    friend Pair operator+(const Pair& a, const Pair& b);
    friend Pair operator+(const Pair& a, int num);
    friend Pair operator+(int num, const Pair& a);
};
