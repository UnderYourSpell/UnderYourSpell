#include "Pair.h"

Pair::Pair() : num1(0), num2(0) {}

Pair::Pair(int num1, int num2) : num1(num1), num2(num2) {}

int Pair::get1() const {
    return num1;
}

int Pair::get2() const {
    return num2;
}

// Overloaded + operators as friend functions
Pair operator+(const Pair& a, const Pair& b) {
    return Pair(a.num1 + b.num1, a.num2 + b.num2);
}

Pair operator+(const Pair& a, int num) {
    return Pair(a.num1 + num, a.num2 + num);
}

Pair operator+(int num, const Pair& a) {
    return Pair(a.num1 + num, a.num2 + num);
}
