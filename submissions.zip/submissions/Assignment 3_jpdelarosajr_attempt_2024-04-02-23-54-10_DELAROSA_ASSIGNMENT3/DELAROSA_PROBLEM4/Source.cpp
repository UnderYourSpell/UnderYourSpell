#include <iostream>
#include <fstream> // Include for file operations
using namespace std;

int main() {
    int leadingcount[9] = { 0 };
    int num;
    ifstream inFile("enrollments.txt"); // Open the file

    // Checks if file is opened
    if (!inFile) {
        cerr << "Unable to open file enrollments.txt";
        return 1; 
    }

    while (inFile >> num) { // Read from file instead of I/O redirection
        if (num <= 0) continue;
        while (num >= 10) {
            num /= 10; // Divides until there's only 1 digit left
        }
        leadingcount[num - 1]++;
    }

    // Close the file
    inFile.close();

    for (int i = 0; i < 9; ++i) {
        cout << "Leading Digit " << i + 1 << ": " << leadingcount[i] << " occurrences." << endl;
    }
    return 0;
}
