#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Movie {
private:
    string name;
    string rating;

public:
    // Constructor
    Movie(string name, string rating) : name(name), rating(rating) {}

    // Name Setter
    void setName(string newName) {
        name = newName;
    }

    // Rating Setter
    void setRating(string newRating) {
        rating = newRating;
    }

    // Name Getter
    string getName() const {
        return name;
    }

    // Rating Getter
    string getRating() const {
        return rating;
    }
};

int main() {
    vector<Movie> movies = {
        Movie("Black Panther", "PG-13"),
        Movie("Avengers: Infinity War", "PG-13"),
        Movie("A Wrinkle In Time", "PG"),
        Movie("Ready Player One", "PG-13"),
        Movie("Red Sparrow", "R"),
        Movie("The Incredibles 2", "G")
    };

    // Bubble Sort
    bool sorted = false;
    while (!sorted) {
        sorted = true;
        for (size_t i = 0; i < movies.size() - 1; ++i) {
            if (movies[i].getName() > movies[i + 1].getName()) {
                swap(movies[i], movies[i + 1]);
                sorted = false;
            }
        }
    }


    for (const Movie& movie : movies) {
        cout << movie.getName() << ", " << movie.getRating() << endl;
    }

    return 0;
}
