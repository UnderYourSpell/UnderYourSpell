#include <iostream>

using namespace std;

class Movie 
{
    private:
        string name;
        string rating;

    public:
        Movie();
        Movie(string n, string r) : name(n), rating(r){};

        void setName(string n) {
            name = n;
        }

        void setRating(string r) {
            rating = r;
        }

        string getName() {
            return name;
        }
        string getRating() {
            return rating;
        }
};

void sort(Movie arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j].getName() > arr[j + 1].getName()) {
                Movie temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int main() {
    const int MOVIES_NUM = 6;
    Movie movies[MOVIES_NUM] = {
        Movie("Black Panther", "PG-13"),
        Movie("Avengers: Infinity War", "PG-13"),
        Movie("A Wrinkle In Time", "PG"),
        Movie("Ready Player One", "PG-13"),
        Movie("Red Sparrow", "R"),
        Movie("The Incredibles 2", "G")
    };
    sort(movies, MOVIES_NUM);

    cout << "Sorted Movies:\n";
    for (int i = 0; i < MOVIES_NUM; i++) {
        cout << movies[i].getName() << ", " << movies[i].getRating() << endl;
    }
    return 0;
}