#include <iostream>
#include <fstream>
using namespace std;

int main() {
	const int ENROLL_NUM = 3300;
	int count[10] = {0};
	int num;

    ifstream inputFile("enrollments.txt");
    if (!inputFile) {
        cout << "Unable to open file" << endl;
        return 1;
    }

    while (inputFile >> num) {
        int lead_num = num;
        while (lead_num >= 10) {
            lead_num /= 10;
        }
        count[lead_num]++;
    }

    inputFile.close();

	for (int i = 1; i < 10; i++) {
		cout << i << ": " << count[i] << endl;
	}

	return 0;
}
