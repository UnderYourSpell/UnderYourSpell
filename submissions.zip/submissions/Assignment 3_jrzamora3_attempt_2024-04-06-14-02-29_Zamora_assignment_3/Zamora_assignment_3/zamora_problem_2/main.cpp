#include <iostream>
#include <string>

using namespace std;

class ZipCode {
private:
    int zip_int;
    string bar_str;

    int decode(const string& group) {
        int val = 0;
        for (int i = 0; i < group.size(); i++) {
    		char digit = group[i];
            val = (val << 1) | (digit - '0');
        }
        if (val == 11) {
            return 0;
        }
        return val;
    }

    string valToBits(int val) {
        string bits = "";
        for (int i = 4; i >= 0; i--) {
            if (val & (1 << i)) {
                bits += '1';
            } else {
                bits += '0';
            }
        }
        return bits;
    }

public:
    ZipCode(int input) {
        zip_int = input;
        bar_str = "1";
        string binary = "";
        while (input > 0) {
            binary = to_string(input % 2) + binary;
            input /= 2;
        }
        binary.insert(0, 32 - binary.length(), '0');
        for (size_t i = 1; i < binary.length() - 1; i += 5) {
            int val = decode(binary.substr(i, 5));
            bar_str += valToBits(val);
        }
        bar_str += "1";
    }

    ZipCode(string& input_data) {
        bar_str = input_data;
        zip_int = 0;
        for (int i = 1; i < bar_str.length() - 1; i += 5) {
            int val = decode(bar_str.substr(i, 5));
            zip_int = zip_int * 10 + val;
        }
    }

    int getZipInt() {
        return zip_int;
    }

    string getBarStr() {
        return bar_str;
    }
};

int main() {
    int zip1 = 99504;
    ZipCode zip_obj1(zip1);

    cout << "Bar code: " << zip_obj1.getBarStr() << endl;
    cout << "Zip code: " << zip_obj1.getZipInt() << endl;

    return 0;
}