#include "Pair.h"

Pair::Pair() : num1(0), num2(0)
{
}

Pair::Pair(int num1, int num2) : num1(num1), num2(num2)
{
}

int Pair::get1()
{
	return num1;
}

int Pair::get2()
{
	return num2;
}

// Return a new pair that adds the corresponding numbers
Pair operator+(const Pair& pair, int otherNum)
{
	return Pair(pair.num1 + otherNum, pair.num2 + otherNum);
}

// Return a new pair that adds otherNum to num1 and num2
Pair operator+(int otherNum, const Pair& pair)
{
	return Pair(pair.num1 + otherNum, pair.num2 + otherNum);
}

Pair operator+(const Pair& pair1, const Pair& pair2) {
	return Pair(pair1.num1 + pair2.num1, pair1.num2 + pair2.num2);
}

Pair Pair::operator+(const Pair& other) {
	return Pair(this->num1 + other.num1, this->num2 + other.num2);
}