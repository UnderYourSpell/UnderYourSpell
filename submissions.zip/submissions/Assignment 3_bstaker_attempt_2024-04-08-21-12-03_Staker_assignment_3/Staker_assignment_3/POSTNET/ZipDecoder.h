#pragma once
#include<string>
using namespace std;
class ZipDecoder
{
private:
		int Zip;
		string Barcode;
		string NumtoCode(int num);
		int CodetoNum( const string& group);
public:
	ZipDecoder(int input);
	ZipDecoder(const string& input);
	int getZip() const;
	string getBarcode()const;


		
	
};

