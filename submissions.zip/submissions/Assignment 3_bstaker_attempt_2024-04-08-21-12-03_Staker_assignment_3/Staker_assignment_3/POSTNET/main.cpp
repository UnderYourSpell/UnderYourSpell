#include<iostream>
#include"ZipDecoder.h"
using namespace std;
int main() {
      ZipDecoder zip(99504); // Object named zip
    cout << "Zip Code: " << zip.getZip() << endl; // Corrected function name to getZip
    cout << "Barcode: " << zip.getBarcode() << endl;

    ZipDecoder barcode("110100101000101011000010011"); // Object named barcode
    cout << "Zip Code: " << barcode.getZip() << endl; // Corrected function name to getZip
    cout << "Barcode: " << barcode.getBarcode() << endl;

    return 0;
}