#include "ZipDecoder.h"
ZipDecoder::ZipDecoder(int input) {
	Zip = input;
	Barcode = "1";
	while (input>0)
	{
		int digit = input % 10;
		Barcode = NumtoCode(digit) + Barcode;
		input /= 10;
	}
	Barcode += "1";
}
ZipDecoder::ZipDecoder(const string& input):Zip(0) {
	for (size_t i = 0; i < input.length() - 1; i += 5) 
	{
		string digit = input.substr(i, 5);
			Zip *= 10;
			Zip += CodetoNum(digit);
		}
	Barcode = input;
	}
int ZipDecoder::getZip()const{
	return Zip;
}
string ZipDecoder::getBarcode() const{
	return Barcode;
}
string ZipDecoder::NumtoCode(int num) {
	switch (num) {
	case 0: return "11000";
	case 1: return "00011";
	case 2: return "00101";
	case 3: return "00110";
	case 4: return "01001";
	case 5: return "01010";
	case 6: return "01100";
	case 7: return "10001";
	case 8: return "10010";
	case 9: return "10100";
	}
}
	int ZipDecoder::CodetoNum(const string & group) {
		if (group == "11000") return 0;
		if (group == "00011") return 1;
		if (group == "00101") return 2;
		if (group == "00110") return 3;
		if (group == "01001") return 4;
		if (group == "01010") return 5;
		if (group == "01100") return 6;
		if (group == "10001") return 7;
		if (group == "10010") return 8;
		if (group == "10100") return 9;

	
}

