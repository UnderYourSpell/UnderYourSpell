#include "Movie.h"
using namespace std;
Movie::Movie(string title, string Mpr) :title(title), Mpr(Mpr) {}
	string Movie::getTitle()const {
		return title;
	}
	void Movie::setTitle(string newTitle) {
		title = newTitle;
	}
	string Movie::getMpr() const {
		return Mpr;
	}
	void Movie::setMpr(string newMpr) {
		Mpr = newMpr;
	}