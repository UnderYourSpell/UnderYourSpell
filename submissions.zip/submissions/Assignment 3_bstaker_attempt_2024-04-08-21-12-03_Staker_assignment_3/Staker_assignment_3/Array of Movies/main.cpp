#include<iostream>
#include"Movie.h"
#include<string>
#include<algorithm>
using namespace std;

bool Compare(const Movie& a, const Movie& b) {
	return a.getTitle() < b.getTitle();
}
void sort(Movie movies[], int size) {
	for (int i = 0; i < size-1; ++i)
	{
		for (int j = 0; j < size -i -1; ++j)
		{
			if (!Compare(movies[j],movies[j+1]))
			{
				swap(movies[j], movies[j + 1]);
			}
		}

	}
}

using namespace std;
int main() {
	string title;
	string Mpr; //MPAA rating 
	const int movielimit = 6;
	Movie movies[movielimit];
	movies[0] = Movie("Black Panther", "PG - 13");
	movies[1] = Movie("Avengers", "PG - 13");
	movies[2] = Movie("A Wrinkle in Time", "PG");
	movies[3] = Movie("Ready Player One", "PG - 13");
	movies[4] = Movie("Red Sparrow", "R");
	movies[5] = Movie("Incredibles", "G");
	sort(movies, movielimit);
	cout << "Your Movies in Alpehetical order: " << endl;
	for ( int i = 0; i < movielimit; ++i)
	{
		cout << "Title: " << movies[i].getTitle() << "Rated: " << movies[i].getMpr() << endl;
	}
}