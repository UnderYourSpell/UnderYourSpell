#pragma once
#include<string>
using namespace std;
class Movie
{private:
	string title;
	string Mpr;
public:
	Movie(string title = "", string Mpr = "");
	string getTitle()const;
	void setTitle(string newTitle);
	string getMpr()const;
	void setMpr(string newMpr);

  
	
};


