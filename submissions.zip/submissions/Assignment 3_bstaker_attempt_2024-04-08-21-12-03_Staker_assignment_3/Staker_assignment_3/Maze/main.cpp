#include<iostream>
#include "Maze.h"
int main() {
	Maze solver;
	solver.solveMaze();
	return 0;
}
