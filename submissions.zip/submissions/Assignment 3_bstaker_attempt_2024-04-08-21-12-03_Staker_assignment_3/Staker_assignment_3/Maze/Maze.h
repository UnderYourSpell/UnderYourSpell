#pragma once
class Maze
{
private:
	static const int WIDTH = 20;
	static const int HEIGHT = 20;
	char maze[HEIGHT][WIDTH];
	bool visited[HEIGHT][WIDTH];
	int solutionX[(HEIGHT - 2) * (WIDTH - 2)];
	int solutionY[(HEIGHT - 2) * (WIDTH - 2)];
	int numPoints;
	
public:
	Maze();

	void generateMaze();
	void printMaze(int curx, int cury);
	bool validMove(int x, int y);
	bool search(int x, int y);
	bool move(int& curx, int& cury, int newX, int newY);
	void solveMaze();


};

