#include "Maze.h"
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;
Maze::Maze() {
	numPoints = 0;
	for (int x = 0; x < WIDTH; x++)
	{
		for (int y = 0; y < HEIGHT; y++)
		{
			maze[y][x] = ' ';
			visited[y][x] = false;



		}
	}
}
void Maze::generateMaze() {
	srand(time(NULL));

}
void Maze::printMaze(int curx, int cury) {
	for (int y = 0; y < HEIGHT; y++) {
		for (int x = 0; x < WIDTH; x++) {
			if ((x == curx) && (y == cury))
				std::cout << "@";
			else
				std::cout << maze[y][x];
		}
		std::cout << std::endl;
	}

}
bool Maze::validMove(int x, int y) {
	if (x < 0 || x >= WIDTH)
		return false;
	if (y < 0 || y >= HEIGHT)
		return false;
	if (maze[y][x] == 'X')
		return false;
	if (visited[y][x])
		return false;
	return true;
}
bool Maze::move(int& curx, int& cury, int newX, int newY) {
	bool foundExit = false;
	if (maze[newY][newX] == 'E')
		foundExit = true;
	curx = newX;
	cury = newY;
	visited[cury][curx] = true;
	return foundExit;
}
bool Maze::search(int x, int y) {
	
	bool foundExit = false;
	if (maze[y][x] == 'E')
		return true;
	visited[y][x] = true;
	if (validMove(x, y - 1))
		foundExit = search(x, y - 1);
	if (!foundExit && validMove(x, y + 1))
		foundExit = search(x, y + 1);
	if (!foundExit && validMove(x - 1, y))
		foundExit = search(x - 1, y);
	if (!foundExit && validMove(x + 1, y))
		foundExit = search(x + 1, y);
	if (foundExit) {
		solutionX[numPoints] = x;
		solutionY[numPoints] = y;
		numPoints++;
	}
	return foundExit;

}

void Maze::solveMaze() {
	generateMaze();
	int x = (rand() % (WIDTH - 2)) + 1;
	int y = (rand() % (HEIGHT - 2)) + 1;
	int exitX = (rand() % (WIDTH - 2)) + 1;
	int exitY = (rand() % (HEIGHT - 2)) + 1;

	bool found = search(x, y);
	if (!found)
	{
		cout << "no solution found";
	}
	else {
		 cout << "Solution found!Here is the path from the start.";
		for (int i = numPoints - 1; i >= 0; i--)
		{
			printMaze(solutionX[i], solutionY[i]);
			cout << endl;
		}
	}


}