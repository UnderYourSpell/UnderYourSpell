Staker

Operator Overloading.

Everything on this program worked for me while running it. 
it wouldnt work because the program was expecting certain variables in a specific order. 

POSTNET

I couldnt get the program to output the correct zipcode im not sure whats happening, but it gives a random number in return. 
Array of Classes
This works as to my interpertaion of the instructions. 

Maze

This works as well I only used one class for Maze.

Benfords law

I was unable to get to this problem 
