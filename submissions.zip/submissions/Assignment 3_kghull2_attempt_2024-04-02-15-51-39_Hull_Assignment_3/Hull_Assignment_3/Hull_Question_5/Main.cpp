#include <iostream>
#include <ctime>
#include <cstdlib>
#include "Maze.h"
using namespace std;

int main()
{
	bool impossible = false;
	cout << "Start" << endl;
	srand(time(NULL));

	Maze game;
	game.initialize();
	impossible = game.search();
	if (!impossible)
	{
		while (!impossible)
		{
			cout << "The generated maze was impossible. Regenerating." << endl << endl;
			game.reset();
			game.initialize();
			impossible = game.search();
		}
	} 
}
