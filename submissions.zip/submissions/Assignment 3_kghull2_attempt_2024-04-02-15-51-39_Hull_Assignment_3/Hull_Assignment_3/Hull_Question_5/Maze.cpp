#include "Maze.h"
#include <iostream>
using namespace::std;

// Display the maze in ASCII
void Maze::printMaze(int curx, int cury)
{
	for (int y = 0; y < HEIGHT; y++)
	{
		for (int x = 0; x < WIDTH; x++)
		{
			if ((x == curx) && (y == cury))
				cout << "@";
			else
				cout << maze[y][x];
		}
		cout << endl;
	}
}

// Return true or false if moving to the specified coordinate is valid
// Return false if we have been to this cell already
bool Maze::validMove(int newX, int newY)
{
	// Check for going off the maze edges
	if (newX < 0 || newX >= 20)
		return false;
	if (newY < 0 || newY >= 20)
		return false;
	// Check if target is a wall
	if (maze[newY][newX] == 'X')
		return false;
	// Check if visited
	if (visited[newY][newX])
		return false;
	return true;
}

// Recursively search from x,y until we find the exit
bool Maze::search()
{
	if (maze[y][x] == 'E') {
		for (int i = 0; i < counter; i++) {
			printMaze(moveListX[i], moveListY[i]);
			cout << "Turn: " << i << endl << endl;
		}
		cout << "Completed in " << counter << " moves." << endl;
		return true;
	}

	visited[y][x] = true;
	moveListX[counter] = x;
	moveListY[counter] = y;
	counter += 1;
	if (validMove(x, y - 1))
	{
		y -= 1;
		foundExit = search();
	}
	if (!foundExit && (validMove(x, y + 1)))
	{
		y += 1;
		foundExit = search();
	}
	if (!foundExit && (validMove(x - 1, y)))
	{
		x -= 1;
		foundExit = search();
	}
	if (!foundExit && (validMove(x + 1, y)))
	{
		x += 1;
		foundExit = search();
	}

	if (foundExit)
	{
		return true;
	}
	return false;
}

void Maze::reset() // Used to "reconstruct" the maze should an impossible maze be generated.
{
	foundExit = false;
	x = 1;
	y = 1;
	WIDTH = 20;
	HEIGHT = 20;
	counter = 0;
}

Maze::Maze()
{
	foundExit = false;
	x = 1;
	y = 1;
	WIDTH = 20;
	HEIGHT = 20;
	counter = 0;
}

void Maze::initialize()
{
	for (int i = 0; i < 20; i++)
	{
		for (int j = 0; j < 20; j++)
		{
			if (i == 0 || i == 19 || j == 0 || j == 19)
			{
				maze[j][i] = 'X';
			}
			else
			{
				maze[j][i] = ' ';
			}
		}
	}

	// Initialize visited locations to false
	for (int x = 0; x < WIDTH; x++)
		for (int y = 0; y < HEIGHT; y++)
			visited[y][x] = false;
	visited[y][x] = true;

	cout << "Visited set to false" << endl;

	// Randomly generate maze
	int fill = 0;
	while (fill <= 90) {
		for (int x = 1; x < WIDTH - 2; x++) {
			for (int y = 1; y < HEIGHT - 2; y++) {
				switch (rand() % 2) {
				case 0:
					maze[y][x] = 'X';
					fill++;
					break;
				case 1:
					break;
				default:
					break;
				}
			}
		}
	}

	cout << "Maze generated" << endl;

	// Randomly places start and exit
	bool exitPlaced = false, startPlaced = false;
	while (!startPlaced) {
		int tempX = rand() % 18 + 1;
		int tempY = rand() % 18 + 1;
		if (maze[tempY][tempX] == ' ') {
			maze[tempY][tempX] = 'S';
			x = tempX;
			y = tempY;
			startPlaced = true;
		}
	}

	while (!exitPlaced) {

		int tempX2 = rand() % 18 + 1;
		int tempY2 = rand() % 18 + 1;
		if (maze[tempY2][tempX2] == ' ') {
			maze[tempY2][tempX2] = 'E';
			exitPlaced = true;
		}
	}

	cout << "Start and exit placed" << endl;
}
