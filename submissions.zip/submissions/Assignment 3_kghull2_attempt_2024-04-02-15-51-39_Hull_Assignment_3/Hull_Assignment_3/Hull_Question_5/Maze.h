#pragma once
class Maze
{
protected:
	int WIDTH, HEIGHT, counter;

	bool visited[20][20], foundExit;
	int moveListX[200], moveListY[200], x, y;
	char maze[20][20];

public:
	Maze();
	void initialize();
	void printMaze(int curx, int cury);
	bool validMove(int newX, int newY);
	bool search();
	void reset();
};

