#include <iostream>
#include "Pair.h"

using namespace std;

int main()
{
	Pair p1(5, 10);
	Pair p2(1, 2);

	// Outputs 5 and 10
	cout << p1.get1() << " " << p1.get2() << endl;
	// Outputs 1 and 2
	cout << p2.get1() << " " << p2.get2() << endl;

	Pair p3 = p2 + p1;
	// Outputs 6 and 12
	cout << p3.get1() << " " << p3.get2() << endl;

	p3 = 2 + p3;	// In the original code, the + operator was only overloaded to handle a Pair + int, not the other way around. 
	// Outputs 8 and 14
	cout << p3.get1() << " " << p3.get2() << endl;
}

// Return a new pair that adds num to num1 and num2
Pair operator+(int num, const Pair& other)
{
	Pair newPair(other.num1, other.num2);
	newPair.num1 += num;
	newPair.num2 += num;
	return newPair;
}

// Return a new pair that adds the corresponding numbers
Pair operator+(const Pair& main, const Pair& other)
{
	Pair newPair(main.num1, main.num2);
	newPair.num1 += other.num1;
	newPair.num2 += other.num2;
	return newPair;
}

// Return a new pair that adds otherNum to num1 and num2
Pair operator+(const Pair& other, int otherNum)
{
	Pair newPair(other.num1, other.num2);
	newPair.num1 += otherNum;
	newPair.num2 += otherNum;
	return newPair;
}
