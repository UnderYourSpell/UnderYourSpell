1. Code runs fine, comment is included in main.cpp
2. Code runs fine.
3. Code runs fine. (I used selection sort)
4. Code runs fine, succesfully reads from file instead of redirection.
5. Code runs fine. I added detection for if the generated maze is impossible, and to regenerate until its solveable so the program doesn't have to manually be reran whenever its impossible :D