#include <iostream>
#include <string>
#include "Movie.h"

using namespace::std;

void sort(Movie arr[], int SIZE);

int main(void) 
{
	const int SIZE = 6;
	Movie list[SIZE] = { 
		Movie("Black Panther", "PG-13"),
		Movie("Avengers: Infinity War", "PG-13"),
		Movie("A Wrinkle In Time", "PG"),
		Movie("Ready Player One", "PG-13"),
		Movie("Red Sparrow", "R"),
		Movie("The Incredibles 2", "G")
	};

	sort(list, SIZE);
	for (int i = 0; i < SIZE; i++)
	{
		cout << list[i].getName() << ", " << list[i].getRating() << endl;
	}

}

void sort(Movie arr[], int SIZE) 
{
	int first;
	for (int i = 0; i < SIZE - 1; i++)
	{
		first = i;
		for (int j = first + 1; j < SIZE; j++)
		{
			if (arr[j].getName() < arr[first].getName())
			{
				first = j;
			}
		}
		swap(arr[first], arr[i]);
	}
}