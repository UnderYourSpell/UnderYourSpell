#include "Movie.h"
#include <string>
Movie::Movie()
{
	name = "Unknown";
	rating = "Unknown";
}

Movie::Movie(std::string name, std::string rating)
{
	this->name = name;
	this->rating = rating;
}

void Movie::setName(std::string newName)
{
	this->name = newName;
}

void Movie::setRating(std::string newRating)
{
	this->rating = newRating;
}

std::string Movie::getName()
{
	return this->name;
}

std::string Movie::getRating()
{
	return this->rating;
}
