#pragma once
#include <string>
class Movie
{
private:
	std::string name;
	std::string rating;
public:
	Movie();
	Movie(std::string name, std::string rating);
	void setName(std::string newName);
	void setRating(std::string newRating);
	std::string getName();
	std::string getRating();
};

