#include <iostream>
#include "POSTNET.h"

using namespace::std;

int main(void)
{
	POSTNET Alaska(99654);
	cout << "Barcode: " << Alaska.getBarcode() << " Zipcode: " << Alaska.getZipcode() << endl;
}