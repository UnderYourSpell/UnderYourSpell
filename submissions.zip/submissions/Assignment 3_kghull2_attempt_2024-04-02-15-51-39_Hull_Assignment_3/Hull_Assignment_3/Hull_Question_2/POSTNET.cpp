#include "POSTNET.h"
#include <string>

POSTNET::POSTNET()
{
	barcode = "100000000000000000000000001";
}

POSTNET::POSTNET(int zipcode)
{
	barcode = "1";
	int temp, zip = zipcode;

	for (int i = 10000; i >= 1; i /= 10)
	{
		temp = zip / i;
		if (temp == 0)
		{
			barcode += "1100";
		}
		while (temp > 0)
		{
			if (temp >= 7)
			{
				barcode += "1";
				temp -= 7;
			}
			else
			{
				barcode += "0";
			}
			if (temp >= 4)
			{
				barcode += "1";
				temp -= 4;
			}
			else
			{
				barcode += "0";
			}
			if (temp >= 2)
			{
				barcode += "1";
				temp -= 2;
			}
			else
			{
				barcode += "0";
			}
			if (temp == 1)
			{
				barcode += "1";
				temp -= 1;
			}
			else
			{
				barcode += "0";
			}
		}
		barcode += "0";
		zip -= (zip / i ) * i;
	}
	barcode += "1";
}

POSTNET::POSTNET(std::string barcode)
{
	this->barcode = barcode;
}

int POSTNET::getZipcode()
{
	int temp = 0, startIndex = 1, zip = 0;
	std::string tempBar = "";
	for (int j = 10000; j >= 1; j /= 10)
	{
		for (int i = startIndex; i < startIndex + 5; i++)
		{
			tempBar += barcode[i];
		}
		for (int i = 0; i < 5; i++)
		{
			if (tempBar[i] == '1')
			{
				switch (i) {
				case 0:
					temp += 7;
					break;
				case 1:
					temp += 4;
					break;
				case 2:
					temp += 2;
					break;
				case 3:
					temp += 1;
					break;
				case 4:
					temp += 0;
					break;
				default:
					break;
				}
			}
		}
		if (temp == 11)
		{
			zip += 0;
		}
		else
		{
			zip += temp * j;
		}
		tempBar = "";
		temp = 0;
		startIndex += 5;
	}
	return zip;
}

std::string POSTNET::getBarcode()
{
	return barcode;
}
