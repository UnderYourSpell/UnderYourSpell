#pragma once
#include <string>
class POSTNET
{
private:
	std::string barcode;
public:
	POSTNET();
	POSTNET(int zipcode);
	POSTNET(std::string barcode);
	int getZipcode();
	std::string getBarcode();
};

