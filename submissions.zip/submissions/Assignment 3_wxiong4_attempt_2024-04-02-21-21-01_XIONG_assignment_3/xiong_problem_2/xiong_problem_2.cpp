#include <iostream>
#include "Zipcode.h"
using namespace std;

int main()
{

    // test going from barcode to zipcode
    Zipcode test("1010010100010101100001001");
    cout << test.get_zipcode() << endl;

    // test going from zipcode to barcode
    Zipcode test2(99504);
    cout << test2.get_barcode() << endl;

}