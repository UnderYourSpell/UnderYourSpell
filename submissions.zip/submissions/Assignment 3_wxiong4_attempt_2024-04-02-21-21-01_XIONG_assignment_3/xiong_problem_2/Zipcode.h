#pragma once
#include <string>
#include <vector>
using namespace std;

class Zipcode
{
public:
    // constructors
    Zipcode(int zipcode);
    Zipcode(string barcode);

    int get_zipcode();
    string get_barcode();

private:
    int zipcode;

};