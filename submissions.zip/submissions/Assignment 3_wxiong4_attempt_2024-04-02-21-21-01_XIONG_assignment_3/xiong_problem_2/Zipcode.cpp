#include "Zipcode.h"
#include <iostream>
using namespace std;

// Constructor
Zipcode::Zipcode(int zipcode)
{
    this->zipcode = zipcode;
}

Zipcode::Zipcode(string barcode)
{
    vector<int> zipcode_holder(5, 0);

    // find sums of digits by grouping
    for (int group = 0; group < 5; group++)
    {
        int first_digit     = (barcode[group * 5 + 0] - '0') * 7;
        int second_digit    = (barcode[group * 5 + 1] - '0') * 4;
        int third_digit     = (barcode[group * 5 + 2] - '0') * 2;
        int fourth_digit    = (barcode[group * 5 + 3] - '0') * 1;
        int fifth_digit     = (barcode[group * 5 + 4] - '0') * 0;

        zipcode_holder[group] = first_digit + second_digit + third_digit + fourth_digit + fifth_digit;

        if (zipcode_holder[group] == 11) { zipcode_holder[group] = 0; }
    }

    // convert all into single zip code
    this->zipcode = stoi(to_string(zipcode_holder[0])
        + to_string(zipcode_holder[1])
        + to_string(zipcode_holder[2])
        + to_string(zipcode_holder[3])
        + to_string(zipcode_holder[4]));

}

// Getters
int Zipcode::get_zipcode()
{
    return zipcode;
}

string Zipcode::get_barcode()
{
    // size 27
    string barcode = "";
    vector<char> barcode_holder(27,0);
    barcode_holder[0] = '1';
    barcode_holder[26] = '1';

    string zipcode_holder = to_string(this->zipcode);

    for (int i = 0; i < 5; i++)
    {
        // assign current
        int temp_num = zipcode_holder[i] - '0';

        // If the value is 0, the sum must be 11
        if (temp_num == 0)
        {
            temp_num = 11;
        }

        int ones_count = 0;
        int first = 0;
        int second = 0;
        int third = 0;
        int fourth = 0;
        int fifth = 0;

        if (temp_num - 7 >= 0)  // First Digit- Value:7
        {
            temp_num -= 7;
            first = 1;
            ones_count++;
        }
        if (temp_num - 4 >= 0)  // Second Digit- Value:4
        {
            temp_num -= 4;
            second = 1;
            ones_count++;
        }
        if (temp_num - 2 >= 0)  // Third Digit- Value: 2
        {
            temp_num -= 2;
            third = 1;
            ones_count++;
        }
        if (temp_num - 1 >= 0)  // Fourth Digit- Value: 1
        {
            temp_num -= 1;
            fourth = 1;
            ones_count++;
        }
        if (ones_count < 2)     // Fifth Digit- Value: 0
        {
            fifth = 1;
        }

        // assign into barcode_holder
        barcode_holder[5 * i + 1] = first  + '0';
        barcode_holder[5 * i + 2] = second + '0';
        barcode_holder[5 * i + 3] = third  + '0';
        barcode_holder[5 * i + 4] = fourth + '0';
        barcode_holder[5 * i + 5] = fifth  + '0';

    }

    // assign to string
    for (int i = 0; i < 26; i++)
    {
        barcode += barcode_holder[i];
    }

    return barcode;
}