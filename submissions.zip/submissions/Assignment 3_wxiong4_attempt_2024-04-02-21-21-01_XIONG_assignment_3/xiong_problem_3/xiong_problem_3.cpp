#include <iostream>
#include <string>
#include "Movie.h"
using namespace std;

void swap(Movie& m1, Movie& m2)
{
	Movie temp = m1;
	m1 = m2;
	m2 = temp;
}

void alphabetical_sort(Movie movies[], int n)
{
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			// determine size
			int word_size;
			Movie current_movie = movies[i];
			Movie next_movie = movies[j];
			if (size(current_movie.get_name()) < size(next_movie.get_name()))
			{
				word_size = size(current_movie.get_name());
			}
			else
			{
				word_size = size(next_movie.get_name());
			}
			
			for (int k = 0; k < word_size; k++)
			{
				if (tolower(current_movie.get_name()[k]) < tolower(next_movie.get_name()[k]))
				{
					// swap
					swap(movies[i], movies[j]);
					break;
				}
				else if (tolower(next_movie.get_name()[k]) < tolower(current_movie.get_name()[k]))
				{
					break;
				}

			}
		}
	}
}

int main()
{
	Movie a[6];

	// Create movies
	Movie m1("Black Panther", "PG-13");
	Movie m2("Avengers: Infinity War", "PG-13");
	Movie m3("A Wrinkle In Time", "PG");
	Movie m4("Ready Player One", "PG-13");
	Movie m5("Red Sparrow", "R");
	Movie m6("The Incredibles 2", "G");

	// add to array
	a[0] = m1;
	a[1] = m2;
	a[2] = m3;
	a[3] = m4;
	a[4] = m5;
	a[5] = m6;

	// print out
	cout << "Unsorted: " << endl;
	for (int i = 0; i < 6; i++)
	{
		cout << a[i].get_name() << ", " << a[i].get_rating() << endl;
	}

	// call sort function
	alphabetical_sort(a, 6);

	// print out
	cout << "\nSorted: " << endl;
	for (int i = 0; i < 6; i++)
	{
		cout << a[i].get_name() << ", " << a[i].get_rating() << endl;
	}


}