#include "Movie.h"

Movie::Movie() : name("N/A"), rating("Not Set") {}

Movie::Movie(string name, string rating) : name(name), rating(rating) {}

string Movie::get_name()
{
	return name;
}

string Movie::get_rating()
{
	return rating;
}

void Movie::set_name(string name)
{
	this->name = name;
}

void Movie::set_rating(string rating)
{
	this->rating = rating;
}