#pragma once
#include <string>
using namespace std;

class Movie
{
	public:
		Movie();
		Movie(string name, string rating);

		// getters
		string get_name();
		string get_rating();

		// setters
		void set_name(string name);
		void set_rating(string rating);

	private:
		string name;
		string rating;

};

