//
//  Question2.cpp
//  CSCE A211 Assignment 3
//
//  Created by Hannah Trotter on 3/21/24.
//

#include <iostream>
using namespace std;

// declaration of class zip
class zip
{
public:
    // constructors
    zip(int  num);
    zip(string binaryNum);
    // public functions to get zip code
    int getZipInt();
    string getZipString();    
private:
    string code;
    int stringToNum();
    string numToString(int num);
    int stringValueToInt(int index);
        
};

// constructors using number
zip:: zip(int num)
{
    code = numToString(num);
}

// constructor using binary string
zip:: zip(string binaryNum){
    
    code = binaryNum;

}

// function decodes binary string to digit
int zip:: stringToNum(){
    
    // creates num and n0 - n4 representing value for binary numbers * placement number
    int num;
    int n4, n3, n2, n1, n0;
    
    n4 = 7 * stringValueToInt(0);
    n3 = 4 * stringValueToInt(1);
    n2 = 2 * stringValueToInt(2);
    n1 = 1 * stringValueToInt(3);
    n0 = 0 * stringValueToInt(4);
    
    num = n4 + n3 + n2 + n1 + n0;
    
    // if num is 11 then the integer is 0
    if (num == 11){
        num = 0;
    }
    
    return num;
}

// function encodes digit to binary string
string zip:: numToString(int num){
    
    // sets binaryCode to all zeros
    string binaryCode = "00000";
    int count = 0;
    
    // returns code equal to 11 if num is 0
    if (num == 0){
        return "11000";
    }
    
    // determines binary code based on integer by subtracting each placement number
    else {
        if ((num - 7) >= 0){
            binaryCode[0] = '1';
            num -= 7;
            count++;
        }
        if ((num - 4) >= 0){
            binaryCode[1] = '1';
            num -= 4;
            count++;
        }
        if ((num - 2) >= 0){
            binaryCode[2] = '1';
            num -= 2;
            count++;
        }
        if ((num - 1) >= 0){
            binaryCode[3] = '1';
            num -= 1;
            count++;
        }
        // used to make sure there are at elast two 1's
        if (count < 2){
            binaryCode[4] = '1';
        }
    }
    
    code = binaryCode;
    
    return code;
    
}

// returns zip as int
int zip:: getZipInt(){
    
    return stringToNum();
}

// returns zip as String
string zip:: getZipString(){
    
    return code;
}

// converts '0' to 0 and '1' to 1 for multiplcation purposes(other wise '0' = 48 and '1' = 49)
int zip:: stringValueToInt(int index){
    
    if(code[index] == '1'){
        return 1;
    }
    else{
        return 0;
    }
}
    



int main(){
    
    // creates zips
    zip zipCode1(9);
    zip zipCode2("11000");
    zip zipCode3(0);
    zip zipCode4(4);
    zip zipCode5("01001");
    
    // displays zips as inters and binary codes
    cout << "zipCode1: "  << zipCode1.getZipInt() << " " << zipCode1.getZipString() << endl;
    cout << "zipCode2: "  << zipCode2.getZipInt() << " " << zipCode2.getZipString() << endl;
    cout << "zipCode3: "  << zipCode3.getZipInt() << " " << zipCode3.getZipString() << endl;
    cout << "zipCode4: "  << zipCode4.getZipInt() << " " << zipCode4.getZipString() << endl;
    cout << "zipCode5: "  << zipCode5.getZipInt() << " " << zipCode5.getZipString() << endl;
}



