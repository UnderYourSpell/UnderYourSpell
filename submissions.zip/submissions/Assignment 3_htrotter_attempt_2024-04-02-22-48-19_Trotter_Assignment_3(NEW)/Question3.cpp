//
//  Question3.cpp
//  CSCE A211 Assignment 3
//
//  Created by Hannah Trotter on 3/22/24.
//

#include <iostream>
using namespace std;

class Movie
{
public:
    // setter
    void Set(string N, string R){
        name = N;
        rating = R;
    }
    // getters
    string getName(){ return name;};
    string getRating(){return rating;};
    // sorting function
    void sort(Movie a[], int lastIndex);
private:
    string name;
    string rating;
};

void Movie:: sort(Movie a[], int size){
    
    for (int i = 0; i < size; i++){
        if(a[i].name[0] > a[i + 1].name[0]){
            Movie temp;
            temp.name = a[i].name;
            temp.rating = a[i].rating;
            a[i].name = a[i + 1].name;
            a[i].rating = a[i + 1].rating;
            a[i + 1].name = temp.name;
            a[i + 1].rating = temp.rating;
        }
        if(a[i].name[0] == a[i + 1].name[0]){
            int j = 0;
            while(a[i].name[j] == a[i + 1].name[j]){
                j++;
                if(a[i].name[j] > a[i + 1].name[j]){
                    Movie temp;
                    temp.name = a[i].name;
                    temp.rating = a[i].rating;
                    a[i].name = a[i + 1].name;
                    a[i].rating = a[i + 1].rating;
                    a[i + 1].name = temp.name;
                    a[i + 1].rating = temp.rating;
                }
            }
        }
    }
}

int main(){
    
    // creates array type Moie
    Movie array[6];
    
    // sets values in array to movies names and ratings
    array[0].Set("Black Panther", "PG-13");
    array[1].Set("Avengers: Infinity War", "PG-13");
    array[2].Set("A Wrinkle In Time", "PG");
    array[3].Set("Ready Player One", "PG-13");
    array[4].Set("Red Sparrow", "R");
    array[5].Set("The Incredibles 2", "G");
    
    
    array[0].sort(array, 5);
    
    // outputs sorted array
    for(int i = 0; i < 6; i++){
        cout << "Name: " << array[i].getName() << " Rating: " << array[i].getRating() << endl;
    }
    
}



                  
