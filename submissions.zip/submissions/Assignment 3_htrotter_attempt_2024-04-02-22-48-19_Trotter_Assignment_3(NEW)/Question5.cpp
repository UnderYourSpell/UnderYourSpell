//
//  Question5WS.cpp
//  CSCE A211 Assignment 3 Workspace
//
//  Created by Hannah Trotter on 4/1/24.
//

#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;


class MAZE 
{
public:
    MAZE();
    void printMaze();
    bool validMove();
    bool move();
    // *** search has new parameters to remember the coordinates of the solution we find
    bool search();
    // *** New function, see below
    void addToArrays();
    void fillMaze();
    void pickStartandEnd();
    void initializeVisited();
    int getEntries();
private:
    const int WIDTH = 20;
    const int HEIGHT = 20;
    char maze[20][20];
    int curX;
    int curY;
    int newX;
    int newY;
    bool visited[20][20];
    int x;
    int y;
    int solutionX[20];
    int solutionY[20];
    int numEntries = 0;
};

// constructor
MAZE :: MAZE(){};


int MAZE:: getEntries(){
    return numEntries;
}

void MAZE:: initializeVisited()
{
    
    // Initialize visited locations to false
    for (int x = 0; x < WIDTH; x++)
        for (int y = 0; y < HEIGHT; y++)
            visited[y][x] = false;
    visited[y][x] = true;
}


void MAZE:: pickStartandEnd()
{

    // ***** Pick a random start and end that is not a wall *****
    int x = (rand() % (WIDTH-2)) +1;
    int y = (rand() % (HEIGHT-2)) +1;
    while (maze[y][x]=='X')
    {
        x = (rand() % (WIDTH-2)) +1;
        y = (rand() % (HEIGHT-2)) +1;
    }
    // At this point, (x,y) contains our start position
    // ***** Pick a random end position that is not a wall *******
    int exitX = (rand() % (WIDTH-2)) +1;
    int exitY = (rand() % (HEIGHT-2)) +1;
    while (maze[exitY][exitX]=='X')
    {
        exitX = (rand() % (WIDTH-2)) +1;
        exitY = (rand() % (HEIGHT-2)) +1;
    }
    maze[exitY][exitX]='E';
}



void MAZE:: fillMaze()
{ /****************
   Programmatically fill out the maze with ***'s on the borders and spaces in the middle
   ****************/
    // All blank
    
    for (int x = 0; x < WIDTH; x++)
        for (int y = 0; y < HEIGHT; y++)
            maze[y][x] = ' ';
    // Borders with X
    for (int x = 0; x < WIDTH; x++)
    {
        maze[0][x] = 'X';
        maze[HEIGHT-1][x] = 'X';
    }
    for (int y = 0; y < HEIGHT; y++)
    {
        maze[y][0] = 'X';
        maze[y][WIDTH-1] = 'X';
    }
}
    
// !!! does not seem to be being called collectly!
// This new function adds two numbers to the arrays and increments the count of how many
// numbers have been added. It assumes the arrays have been created big enough to not
// have overflow. It is used to remember the coordinates of our solution.
void MAZE:: addToArrays()
{
    
   solutionX[numEntries] = x;
   solutionY[numEntries] = y;
   numEntries++;
}

// Return true or false if moving to the specified coordinate is valid
// Return false if we have been to this cell already
bool MAZE:: validMove()
{
 // Check for going off the maze edges
 if (newX < 0 || newX >= WIDTH)
    return false;
 if (newY < 0 || newY >= HEIGHT)
    return false;
 // Check if target is a wall
 if (maze[newY][newX]=='X')
    return false;
 // Check if visited
 if (visited[newY][newX])
    return false;
 return true;
}

// !! does not seem to being called correctly
// Make the move on the maze to move to a new coordinate
// I passed curX and curY by reference so they are changed to
// the new coordinates.  Here we assume the move coordinates are valid.
// This returns true if we move onto the exit, false otherwise.
// Also update the visited array.
bool MAZE:: move()
{
    cout << "test" << endl;
  bool foundExit = false;
  if (maze[newY][newX]=='E')     // Check for exit
    foundExit = true;
  curX = newX;            // Update location
  curY = newY;
  visited[curY][curX] = true;
 
  return foundExit;
}

// !!! does not seem to be called correctly
// Display the maze in ASCII
void MAZE:: printMaze()
{
  for (int y=0; y < HEIGHT;y++)
  {
    for (int x=0; x < WIDTH; x++)
    {
    if ((x==curX) && (y==curY))
        cout << "@";
    else
        cout << maze[y][x];
    }
    cout << endl;
  }
}

// Recursively search from x,y until we find the exit
bool MAZE:: search()
{
    bool foundExit = false;
    
    if (maze[y][x]=='E')
        return true;
    visited[y][x]=true;
    y -= 1;
    if (validMove()){
        foundExit = search();
    }
    else{
        y += 2;
    }
    if (!foundExit && (validMove())){
        foundExit = search();
    }
    else{
        y -= 2;
        x -= 1;
    }
    if (!foundExit && (validMove())){
        foundExit = search();
    }
    else{
        x += 2;
    }
    if (!foundExit && (validMove())){
        foundExit = search();
    }
   if (foundExit)
   {
    // Remember coordinates we found the exit in the solution arrays
    addToArrays();
    return true;
   }
   return false;
}


int main(){
    srand((time(nullptr));
    
    MAZE M;
    M.fillMaze();
    M.pickStartandEnd();
    M.initializeVisited();
    
    bool found = M.search();
    if (!found)
        cout << "No solution found." << endl;
    else
    {
        int numPoints = M.getEntries();
       cout << "Solution found!  Here is the path from the start." << endl;
       for (int i = numPoints-1; i >= 0; i--)
       {
           M.printMaze();
           cout << endl;
        }
    }
}
