//
//  Pair.cpp
//  CSCE A211 Assignment 3 Workspace
//
//  Created by Hannah Trotter on 4/2/24.
//

#include "Pair.h"

Pair::Pair() : num1(0), num2(0)
{
}

Pair::Pair(int num1, int num2) : num1(num1), num2(num2)
{
}

int Pair::get1()w
{
    return num1;
}

int Pair::get2()
{
    return num2;
}

// Return a new pair that adds the corresponding numbers
Pair Pair::operator+(const Pair& other)
{
    Pair newPair(this->num1, this->num2);
    newPair.num1 += other.num1;
    newPair.num2 += other.num2;
    return newPair;
}

// Return a new pair that adds otherNum to num1 and num2
Pair Pair::operator+(int otherNum)
{
    Pair newPair(this->num1, this->num2);
    newPair.num1 += otherNum;
    newPair.num2 += otherNum;
    return newPair;
}

// adds interger and Pair and returns Pair
Pair operator+(int num, Pair& p)
{
    Pair temp;
    temp.num1 = p.num1 + num;
    temp.num2 = p.num2 + num;
    return temp; 
}

// adds two Pairs and returns Pair
Pair operator+(Pair& p1, Pair& p2)
{
    Pair temp;
    temp.num1 = p1.num1 + p2.num1;
    temp.num2 = p1.num2 + p2.num2;
    return temp;
}
