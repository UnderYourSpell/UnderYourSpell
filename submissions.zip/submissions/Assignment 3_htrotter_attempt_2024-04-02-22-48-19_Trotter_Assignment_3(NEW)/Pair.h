//
//  Pair.h
//  CSCE A211 Assignment 3 Workspace
//
//  Created by Hannah Trotter on 4/1/24.
//

#ifndef Pair_h
#define Pair_h


#endif /* Pair_h */

class Pair
{
private:
    int num1, num2;
public:
    Pair();
    Pair(int num1, int num2);
    int get1();
    int get2();
    Pair operator+(const Pair& other);
    Pair operator+(int otherNum);
    friend Pair operator+(int num, Pair& p);
    friend Pair operator+(Pair& p1, Pair& p2);
    
};


