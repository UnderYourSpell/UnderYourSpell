1. In this problem, I logged into the private server (Putty) and grabbed the enrollment data on Professor Neumayer's directory. This would only work if you have my .cpp file copied onto your directory. 
	a. g++ A1Q1.cpp 
	b. ./a.out < ~sjneumayer/CSCE_A211/enrollments.txt
38.9% ones
23.9% twos
9.5% threes
7% fours 
4.6% fives
3.6% sixes
3.9% sevens 
5% eights
3.2% nines 

2. Just run the problem in an IDE and play as intended! Instructions implimented in the game. 

3.	1. Through some research on this topic. One must first initialize a variable randomly on the stack in which the maze’s walls do not cross. From there, the variable should randomly choose a direction to follow from that point. if the end location it ends up at is a dead end, it should backtrace where it was and try again from other possible locations that lead to S. It can avoid going in circles by remembering where it had been prior. 
	2. First we initialize a grid size within the code. From there on, we layer the 2D Array in a random way that follows the previous random array. Limiting how many lines follow and allowing for only white space to shift around the maze. This is done till the array is nearing exhaustion and towards the end, it will be a Wall again. There will be a function in place that once an S (Exit), another exit is not allowed to be created. 

4. Just run the IDE as is. 
