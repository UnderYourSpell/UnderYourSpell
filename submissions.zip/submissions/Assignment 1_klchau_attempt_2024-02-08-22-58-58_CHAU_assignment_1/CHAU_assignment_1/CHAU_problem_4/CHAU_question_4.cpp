// Question 1.4 Reference parameters - 20 pts

#include <iostream>
using namespace std;

void CalcCoins(int change, int &quarters, int &dimes, int &nickels, int &pennies) {
    quarters = change / 25; 
    change %= 25; 
    dimes = change / 10; 
    change %= 10; 
    nickels = change / 5; 
    change %= 5; 
    pennies = change; 
}

int main() {

    // Test 1  
    int test1 = 89;
    int quarters1, dimes1, nickels1, pennies1; 
    CalcCoins(test1, quarters1, dimes1, nickels1, pennies1); 
    cout << "Change for " << test1 << " cents: " << quarters1 << " quarters, " << dimes1 << " dimes, " << nickels1 << " nickels, " << pennies1 << " pennies" << endl;

    // Test 2
    int test2 = 67;
    int quarters2, dimes2, nickels2, pennies2;
    CalcCoins(test2, quarters2, dimes2, nickels2, pennies2);
    cout << "Change for " << test2 << " cents: " << quarters2 << " quarters, " << dimes2 << " dimes, " << nickels2 << " nickels, " << pennies2 << " pennies" << endl;

    return 0;
}

