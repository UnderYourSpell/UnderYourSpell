//Question 1-1 Benford's Law - 30 pts


#include <iostream>
#include <array>
#include <cmath>

using namespace std;

double CalcPercentage(int count, int total) {
    if (total == 0) return 0.0;
    double percentage = 100 * count / total;
    return round(percentage * 10) / 10; 
}

int main() {
    const int MAX = 3295;
    int count = 0;
    int zeros= 0, ones = 0, twos = 0, three = 0, fours = 0, fives = 0, sixes = 0, sevens = 0, eights = 0, nines = 0;

    while (count < MAX) {
        int num = 0;
        cin >> num; 

        if (num < 10) {
             switch (num) {
                case 0:
                    zeros += 1; 
                    break; 
                case 1:
                    ones += 1; 
                    break; 
                case 2:
                    twos += 1; 
                    break;
                case 3:
                    three += 1; 
                    break;
                case 4:
                    fours += 1; 
                    break; 
                case 5:
                    fives += 1; 
                    break; 
                case 6:
                    sixes += 1; 
                    break; 
                case 7:
                    sevens += 1; 
                    break; 
                case 8:
                    eights += 1; 
                    break; 
                case 9:
                    nines += 1; 
                    break; 
                default:
                    break;
            }
        }
        else {
            num = num / 10;
            switch (num) {
                case 0:
                    zeros += 1; 
                    break; 
                case 1:
                    ones += 1; 
                    break; 
                case 2:
                    twos += 1; 
                    break;
                case 3:
                    three += 1; 
                    break;
                case 4:
                    fours += 1; 
                    break; 
                case 5:
                    fives += 1; 
                    break; 
                case 6:
                    sixes += 1; 
                    break; 
                case 7:
                    sevens += 1; 
                    break; 
                case 8:
                    eights += 1; 
                    break; 
                case 9:
                    nines += 1; 
                    break; 
                default:
                    break;
            }
        }
        count += 1;
    }

    cout << "There are " << zeros << " zeros. Its percentage is " << CalcPercentage(zeros,MAX) << "%" << endl;
    cout << "There are " << ones << " ones. Its percentage is " << CalcPercentage(ones,MAX) << "%" << endl;
    cout << "There are " << twos << " twos. Its percentage is " << CalcPercentage(twos,MAX) << "%" << endl;
    cout << "There are " << three << " threes. Its percentage is " << CalcPercentage(three,MAX) << "%" << endl;
    cout << "There are " << fours << " fours. Its percentage is " << CalcPercentage(fours,MAX) << "%" << endl;
    cout << "There are " << fives << " fives. Its percentage is " << CalcPercentage(fives,MAX) << "%" << endl;
    cout << "There are " << sixes << " sixes. Its percentage is " << CalcPercentage(sixes,MAX) << "%" << endl;
    cout << "There are " << sevens << " sevens. Its percentage is " << CalcPercentage(sevens,MAX) << "%" << endl;
    cout << "There are " << eights << " eights. Its percentage is " << CalcPercentage(eights,MAX) << "%" << endl;
    cout << "There are " << nines << " nines. Its percentage is " << CalcPercentage(nines,MAX) << "%" << endl;
    
    return 0;
}

