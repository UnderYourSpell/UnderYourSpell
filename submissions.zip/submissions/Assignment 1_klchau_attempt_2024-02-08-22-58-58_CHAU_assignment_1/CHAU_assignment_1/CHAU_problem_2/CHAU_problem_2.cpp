//Question 1.2 Chuck-a-Luck - 30 pts

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int game(int guess, int rNum, int& count) {

    if (guess != rNum) {
        return 1;
    }
    else if (guess == rNum) {
        cout << "Excellent! You guessed the die!" << endl;
        count += 1;
        }
        return 1;
}


int main() {
    int uNum = 0;
    srand(time(0));
    int rNum = rand() % 6 + 1;
    int money = 100;
    int count = 0;

    cout << "I will roll 3 dies that will land between 1 and 6." << endl << "Can you guess the die rolls?" << endl;

    while (true) {
        cin >> uNum;

        while (uNum < 1 && uNum > 6){
            cout << "Please try again: ";
            cin >> uNum;
        }

        // Dice1
        int result = game(uNum, rNum, count);
        if (result == 1) {
            rNum = rand() % 6 + 1;
        }

        // Dice2
        int result2 = game(uNum, rNum, count);
        if (result2 == 1) {
            rNum = rand() % 6 + 1;
        }

        // Dice3
        int result3 = game(uNum, rNum, count);
        if (result3 == 1) {
            rNum = rand() % 6 + 1;
        }

        if (count == 0) {
            money = money - uNum;
            cout << "You got none correct. Your total has decreased by $" << uNum << ". Your total is $" << money << '.' << endl;
            count = 0;
        }
        else {
            uNum *= count;
            cout << "You got " << count << " guesses right! Your wager is multiplied by " << count << ". Your current total is $" << (money += uNum) << "." << endl;
            count = 0;
        }
        
        // Wanna play again? 
        cout << "Would you like to play again? (Y/N)" << endl;
        char play; 
        cin >> play;

        while (play != 'Y' && play != 'N') {
            cout << "Invalid. Please try again." << endl;
            cin >> play;
        }

        if (play == 'Y') {
            cout << "Please input another wager: ";
        }

        else if (play == 'N') {
            cout << "Your ending balance is: $" << money << "." << endl << "Have a nice day!" << endl;
            return 0;
        }
    }

    return 0;
}