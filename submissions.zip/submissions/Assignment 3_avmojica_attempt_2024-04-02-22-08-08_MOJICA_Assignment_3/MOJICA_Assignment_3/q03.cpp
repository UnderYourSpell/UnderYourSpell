#include <iostream>
#include <string>
#include <algorithm>

class Movie {
private:
    std::string name;



    std::string rating;







public:
    Movie() {}
    Movie(const std::string& name, const std::string& rating) : name(name), rating(rating) {}

    
    std::string getName() const { return name; }
    std::string getRating() const { return rating; }

    
    void setName(const std::string& name) { this->name = name; }
    void setRating(const std::string& rating) { this->rating = rating; }
};

// movies by alphabetically sorted names
void sortMovies(Movie movies[], int size) {
    for (int i = 0; i < size - 1; ++i) {
        for (int j = 0; j < size - i - 1; ++j) {
            if (movies[j].getName() > movies[j + 1].getName()) {
                std::swap(movies[j], movies[j + 1]);
            }

        }


    }
}

int main() {


    //array of movie type
    const int numMovies = 6;
    Movie movies[numMovies] = {
        Movie("Black Panther", "PG-13"),
        Movie("Avengers: Infinity War", "PG-13"),
        Movie("A Wrinkle In Time", "PG"),
        Movie("Ready Player One", "PG-13"),
        Movie("Red Sparrow", "R"),
        Movie("The Incredibles 2", "G")
    };
    sortMovies(movies, numMovies);

    


    std::cout << "Movies sorted by name:\n";
    for (int i = 0; i < numMovies; ++i) {
        std::cout << movies[i].getName() << ": " << movies[i].getRating() << std::endl;
    }

    return 0;
}
