#include <iostream>
#include <fstream>
#include <string>


#include <vector>




int main() {
    std::ifstream inputFile("enrollments.txt");
    if (!inputFile.is_open()) {
        std::cerr << "Failed to open the file." << std::endl;
        return 1;





    }
    std::vector<int> digitCounts(9, 0);
    std::string number;
    while (inputFile >> number) {
        if (!number.empty() && std::isdigit(number[0])) {
            int leadingDigit = number[0] - '0';


            if (leadingDigit >= 1 &&  leadingDigit <= 9) {
                digitCounts[leadingDigit - 1]++;
            }
        }
    }






    std::cout << "Leading digit counts:" << std::endl;
    for (int i = 0; i < 9; ++i) {
        std::cout << i + 1 << ": " << digitCounts[i] << std::endl;
    }





    inputFile.close();












    return 0;
}
