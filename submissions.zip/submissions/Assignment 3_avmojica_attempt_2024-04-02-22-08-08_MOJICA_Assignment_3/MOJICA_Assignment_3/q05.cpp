#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

const int WIDTH = 20;
const int HEIGHT = 20;

class Maze {
private:


    char maze[HEIGHT][WIDTH];
    bool visited[HEIGHT][WIDTH];


    int startX, startY;
    int exitX, exitY;
    int solutionX[(HEIGHT - 2) * (WIDTH - 2)];
    int solutionY[(HEIGHT - 2) * (WIDTH - 2)];


    int numPoints;

    void addToArrays(int xVal, int yVal) {
        solutionX[numPoints] = xVal;


        solutionY[numPoints] = yVal;
        numPoints++;
    }

    bool validMove(int newX, int newY) {
        if (newX < 0 || newX >= WIDTH || newY < 0 || newY >= HEIGHT)
            return false;



        if (maze[newY][newX] == 'X' || visited[newY][newX])
            return false;
        return true;
    }

    bool search(int x, int y) {
        if (maze[y][x] == 'E')
            return true;
        visited[y][x] = true;
        if (validMove(x, y - 1) && search(x, y - 1)) {
            addToArrays(x, y);
            return true;
        }
        if (validMove(x, y + 1) && search(x, y + 1)) {
            addToArrays(x, y);
            return true;
        }
        if (validMove(x - 1, y) && search(x - 1, y)) {
            addToArrays(x, y);
            return true;
        }

        if (validMove(x + 1, y) && search(x + 1, y)) {
            addToArrays(x, y);
            return true;
        }
        return false;
    }

public:
    Maze() {
        srand(time(NULL));
        generateMaze();
    }

    void generateMaze() {

    }

    void printMaze(int curX, int curY) {
       
    }

    void solveMaze() {
        numPoints = 0;
        bool found = search(startX, startY);
        if (!found)
            cout << "no solution found." << endl;
        else {
            cout << "Solution found. here is the path from the start." << endl;
            for (int i = numPoints - 1; i >= 0; i--) {
                printMaze(solutionX[i], solutionY[i]);
                cout << endl;
            }
        }
    }
};

int main() {
    Maze mazeSolver;
    mazeSolver.solveMaze();
    return 0;
}
