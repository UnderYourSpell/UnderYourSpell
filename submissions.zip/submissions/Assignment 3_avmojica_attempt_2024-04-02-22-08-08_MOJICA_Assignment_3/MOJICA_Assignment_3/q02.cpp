#include <iostream>
#include <string>

class ZipCode {
private:
    std::string barcode;
    int zipcode;

    
    int barcodeToZipcode(const std::string& barcode) {
        int zipcode = 0;
        for (int i = 0; i < 5; ++i) {
            int value = 0;
            for (int j = 0; j < 5; ++j) {
                if (barcode[i * 5 + j] == '1') {
                    value += (1 << (4 - j)); // 2^(4-j)
                }
            }
            if (value != 11) {
                zipcode = zipcode * 10 + value;
            }
        }
        return zipcode;
    }

    
    std::string zipcodeToBarcode(int zipcode) {
        std::string barcode = "1"; // start  leading 1
        while (zipcode > 0) {
            int digit = zipcode % 10;
            zipcode /= 10;
            barcode = digitToBarcode(digit) + barcode;
        }
        return barcode + "1"; // end with trailing 1
    }

    
    std::string digitToBarcode(int digit) {
        std::string barcode;
        if (digit == 0) {
            barcode = "11000";
        }
        else {
            while (digit > 0) {
                if (digit >= 7) {
                    barcode = "1" + barcode;

                    digit -= 7;
                }


                else if (digit >= 4) {
                    barcode = "01" + barcode;
                    digit -= 4;
                }


                else if (digit >= 2) {
                    barcode = "001" + barcode;
                    digit -= 2;
                }


                else if (digit == 1) {
                    barcode = "0001" + barcode;
                    digit = 0;
                }
            }

        }
        while (barcode.length()< 5) {
            barcode = "0" + barcode;
        }
        return barcode;
    }

public:
    // constructors
    ZipCode(int zipcode) : zipcode(zipcode), barcode(zipcodeToBarcode(zipcode)) {}
    ZipCode(const std::string& barcode) : barcode(barcode), zipcode(barcodeToZipcode(barcode)) {}

    // member function
    int getZipcode() const { return zipcode; }
    std::string getBarcode() const { return barcode; }
};

int main() {
    
    ZipCode zip1(99504); // input
    std::cout << "Zipcode: " << zip1.getZipcode() << ", Brcode: " << zip1.getBarcode() << std::endl;

    ZipCode zip2("110100101000101011000010011"); // barcode input
    std::cout << "Zipcode: " << zip2.getZipcode() << ", Barcode: " << zip2.getBarcode() << std::endl;

    return 0;
}
