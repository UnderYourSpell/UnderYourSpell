Problem 1) On a unix system, use this command: ./a.out < enrollments.txt
Problem 2) Works with no issues
Problem 3) I am not really confident that my in my answers.
Problem 4) Works without issues