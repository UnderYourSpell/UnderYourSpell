#include <iostream>
#include <ctime>
#include <cmath>

using namespace std;

bool rollDice(int guess, int &match)
{
	int dice[] = { 0, 0, 0 };
	match = 0;
	dice[0] = (rand() % 6) + 1; // Random number between 1 and 6
	dice[1] = (rand() % 6) + 1; // Random number between 1 and 6
	dice[2] = (rand() % 6) + 1; // Random number between 1 and 6

	cout << "Dice have been rolled with the following results:" << endl;
	cout << "Die #1: " << dice[0] << ", Die #2: " << dice[1] << ", and Die #3: " << dice[2] << "." << endl;
	cout << endl;
	
	for (int i = 0; i < 3; i++)
	{
		if (dice[i] == guess)
		{
			match++;
		}
	}

	if (match > 0)
	{
		cout << "The gambler wins!" << endl;
		cout << "The gambler's guess matches " << match << " dice." << endl;
		cout << endl;
		return true;
	}
	else
	{
		cout << "The gambler loses." << endl;
		cout << endl;
		return false;
	}
}

void responseCheck(char r)
{
	while (r != 'n' && r != 'y')
	{
		cout << "Gambler has entered an invalid response." << endl;
		cout << "Please enter a y for yes or a n for no. (y/n): ";
		cin >> r;
		cout << endl;
	}
}

int main()
{
	int W = 0; // gambler's wager amount
	int n; // gambler's number pick
	int M = 100; // gambler's starting money
	int winCount = 0;
	char play = 'y';
	char bonus = 'y';
	bool result = false;

	srand(time(0)); // initalize srand based of time for use in rollDice function

	cout << "Welcome to the Chuck-A-Luck gambling game!" << endl;
	cout << endl;

	cout << "Gambler's account balance is $" << M << "." << endl;
	cout << endl;

	
	
	while (play != 'n' && M != 0)
	{
		cout << "How much would the gambler like to wager before rolling the dice? " << endl;
		cout << "Please enter a number between 1 and " << M << ": $";
		cin >> W;
		cout << endl;

		while (W < (M - M) || W > M) // Loops until input wager is within gambler's balance
		{
			cout << "Gambler has entered an invalid wager amount." << endl;
			cout << "Please enter a number between 1 and " << M << ": $";
			cin >> W;
			cout << endl;
		}

		cout << "Please make a guess between 1 and 6: ";
		cin >> n;
		cout << endl;

		while (n < 1 || n > 6) // Loops until input guess is within dice range
		{
			cout << "Gambler's guess is an invalid number." << endl;
			cout << "Please make a guess between 1 and 6: ";
			cin >> n;
			cout << endl;
		}
		result = rollDice(n, winCount); // Call rollDice function with gambler's pick to see if win or lose

		if (result) // Runs if true and gambler wins and asks if they want to continue playing
		{
			M = M + (W * winCount);
			cout << "The gambler won $" << W * winCount << "." << endl;
			cout << "The gambler's new balance is $" << M << "." << endl;
			cout << endl;

			cout << "Would the gambler like to continue playing?(y/n): ";
			cin >> play;
			cout << endl;

			responseCheck(play); // Checks if valid response

		}
		else if (!(result)) // Runs if win result returns false and asks if they want to continue playing
		{
			M -= W; // Subtracts wager from account balance
			cout << "Gambler's balance is $" << M << "." << endl;
			cout << endl;

			if (M != 0)
			{
				cout << "Would the gambler like to continue playing?(y/n): ";
				cin >> play;
				cout << endl;

				responseCheck(play); // Checks if valid response
			}
		}
		
		if (M != 0 && play == 'n') // End game due to gambler declining to continue play
		{
			cout << "The gambler's ending account balance is $" << M << "." << endl;
			cout << "Thanks for playing!" << endl;
		}

		if (M == 0) // End game due to account balance being zero
		{
			cout << "Sorry, gambler busts. Better luck next time." << endl;
			play = 'n';
		}
	}

}