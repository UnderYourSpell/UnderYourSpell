#include <iostream>

using namespace std;

void ChangeReturn(int x, int& q, int& d, int& n, int& p)
{
	q = x / 25; // Update referenced quarter count
	d = (x % 25) / 10; // Update referenced dime count
	n = ((x % 25) % 10) / 5; // Update referenced nickel count
	p = ((x % 25) % 10) % 5; // Update referenced penny count
}


int main()
{
	int amount, quarter, dime, nickel, penny;

	// Test ChangeReturn with amount 66

	amount = 23;
	ChangeReturn(amount, quarter, dime, nickel, penny);

	cout << "Return change is " << amount << " cents." << endl;
	cout << endl;
	cout << "You will need to return " << quarter << " quarter(s), " << dime << " dime(s), " << nickel << " nickel(s), and ";
	cout << penny << " pennies." << endl;
	cout << endl;

	// Test ChangeReturn with amount 99

	amount = 99;
	ChangeReturn(amount, quarter, dime, nickel, penny);

	cout << "Return change is " << amount << " cents." << endl;
	cout << endl;
	cout << "You will need to return " << quarter << " quarter(s), " << dime << " dime(s), " << nickel << " nickel(s), and ";
	cout << penny << " pennies." << endl;

	return 0;
}