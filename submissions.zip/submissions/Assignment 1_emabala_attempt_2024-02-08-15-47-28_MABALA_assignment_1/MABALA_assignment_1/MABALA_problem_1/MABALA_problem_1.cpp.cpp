#include <iostream>

using namespace std;

int main()
{
	const int ARSIZE = 3296;
	int numbers[ARSIZE];
	int count = 0;

	cout << "Enter numbers to be looked at using Benford's Law: ";

	for (int i = 0; i < ARSIZE; i++)
	{
		cin >> numbers[i];
	}
	cout << endl;

	for (int i = 1; i < 10; i++)
	{
		for (int j = 0; j < ARSIZE; j++)
		{
			int temp = numbers[j];
			while (temp >= 10)
			{
				temp /= 10;
			}

			if (temp == i)
			{
				count++;
			}
		}
		cout << i << " is the leading digit " << count << " times." << endl;
		count = 0;
	}

	return 0;
}
