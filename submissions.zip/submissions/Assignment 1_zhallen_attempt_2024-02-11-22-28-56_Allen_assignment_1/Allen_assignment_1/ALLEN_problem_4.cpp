#include <iostream>
using namespace std;

void changeToDisp(int x) {
	cout << "Change to dispense: " << x << endl;
}

void quarters(int& x) {
	int quart = x/25;
	cout << "Quarters dispensed: " << quart << endl;
	x = x - (quart * 25);
}

void dimes(int& x){
	int dime = x/10;
	cout << "Dimes dispensed: " << dime << endl;
	x = x - (dime * 10);
}

void nickels(int& x) {
	int nickel = x/5;
	cout << "Nickels dispensed: " << nickel << endl;
	x = x - (nickel * 5);
}

void pennies(int& x) {
	cout << "Pennies dispensed: " << x << endl;
}

int main() {
	int change[3] = {87, 23, 96};
	for (int i=0;i<3;i++) {
		changeToDisp(change[i]);
		quarters(change[i]);
		dimes(change[i]);
		nickels(change[i]);
		pennies(change[i]);
		cout << endl;
	}
}
