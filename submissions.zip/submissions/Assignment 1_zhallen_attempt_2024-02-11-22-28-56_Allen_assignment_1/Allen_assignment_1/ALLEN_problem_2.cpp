#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int rollDice() {
	int roll = (rand()%6)+1;
	return roll;
}

bool isMatch(int userGuess, int userRoll, int wager, int& totFunds) {
	if (userGuess == userRoll) {
		totFunds+= wager;
		return true;
	}
	else {
		return false;
	}
}

void placingBet(int& wager, int& totFunds) {
	cin >> wager;
	while (totFunds<wager) {
		cout << "Your requested wager is more money than you currently have. You have $" << totFunds << "." << endl;
		cout << "Enter a wager: ";
		cin >> wager;
	}
	totFunds-=wager;
}

int main() {
	int roll, userInput=4;
	int userGuess, wager, totFunds=100;
	bool match=false;
	srand(time(0));


	cout << "Welcome to a simulator of Chuck-a-Luck!" << endl;


	while(userInput != 0) {
	cout << "Try to guess what your roll might be. To start, input a wager! You currently have $" << totFunds << "." << endl;
	placingBet(wager, totFunds);

	cout << "Select a number you think the dice might roll: ";
	cin >> userGuess;
	while (userGuess < 1 || userGuess > 6) {
		cout << "The guess must be between 1-6. Please enter it as a digit as well." << endl;
		cout << "Select a number you think the dice might roll: ";
		cin >> userGuess;
	}

	for (int i=0; i<3; i++) {
		match = false;
		cout << "Enter a \"1\" to roll: ";
		cin >> userInput;
		roll = rollDice();
		cout << "You rolled a " << roll << "! ";
		match = isMatch(userGuess, roll, wager, totFunds);

		if (match == true) {
			cout << "You guessed right! You made back $" << wager << "!" << endl;
		}
		else {
			cout << "You did not guess correctly." << endl;
		}
	}

	cout << "You currently have $" << totFunds << "!"  << endl;

	if (totFunds == 0) {
		cout << "You have run out of funds. Thanks for playing!";
		return 0;
	}

	cout << "Enter a \"0\" to quit or \"1\" to continue." << endl;

	cin >> userInput;
	}
	return 0;
}
