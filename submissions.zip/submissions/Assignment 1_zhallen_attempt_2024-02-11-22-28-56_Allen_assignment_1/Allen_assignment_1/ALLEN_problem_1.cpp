#include <iostream>
using namespace std;

int main() {
//establishing counter for numbers 1-9, set all to 0 to begin with
int counters[9] = {0};

//amount of numbers being evaluated
int SIZE = 3295;

int userNum;

for (int i=0; i<SIZE; i++) {
	cin >> userNum;
	while (userNum > 9) { //dividing userNum by 10 if greater than 9 in order to get first digit
		userNum /= 10;
	}
	for (int j=1; j<10; j++) {
		if (userNum == j) {
			counters[j-1] += 1;
		}
	}
}

for (int i=0; i<9; i++) {
	cout << "Numbers starting with " << i+1 << ": " << counters[i];
	cout << " (" << ((float)counters[i]/SIZE)*100 << "%)" << endl;
}
}

