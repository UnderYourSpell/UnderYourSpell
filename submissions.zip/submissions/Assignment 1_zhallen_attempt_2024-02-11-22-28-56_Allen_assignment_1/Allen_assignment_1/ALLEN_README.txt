Problem 1:
Run by using ./a.out < enrollments.txt if using a Linux system
No issues found, program outputs both the count of how many respective leading digits it recorded as well as a percentage of its overall results.

Problem 2:
Program runs fine, has error handling for if wager is more than the user currently has and if dice guess is not between 1-6. If user enters a char instead of an int, program crashes.

Problem 3:
No issues found, program displays all necessary information.