#pragma once
#include <string>
using namespace std;

class Movie
{
private:
	string name;
	string rating;
public:
	Movie();
	Movie(string name, string rating);
	string getname();
	string getrating();
};

