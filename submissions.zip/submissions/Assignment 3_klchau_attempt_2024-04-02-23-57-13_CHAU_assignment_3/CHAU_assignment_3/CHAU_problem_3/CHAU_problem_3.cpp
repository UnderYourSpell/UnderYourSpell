#include <iostream>
#include <string>
#include "Movie.h"
using namespace std;

void movieSort(Movie movies[], int leng)
{
	Movie temp;
	if (leng == 1)
	{
		return;
	}
	for (int i = 0; i < leng-1; i++)
	{
		if (movies[i + 1].getname() < movies[i].getname())
		{
			temp = movies[i];
			movies[i] = movies[i + 1];
			movies[i + 1] = temp;
		}
	}
	movieSort(movies, leng - 1);
}

int main() 
{
    const int NUM_MOVIES = 6;
    Movie movies[NUM_MOVIES] = 
    {
        Movie("Black Panther", "PG-13"),
        Movie("Avengers: Infinity War", "PG-13"),
        Movie("A Wrinkle In Time", "PG"),
        Movie("Ready Player One", "PG"),
        Movie("Red Sparrow", "R"),
        Movie("The Incredibles 2", "G")
    };


    movieSort(movies, NUM_MOVIES);

    cout << endl << "Movies Alphabetical Order: " << endl;
    for (int i = 0; i < NUM_MOVIES; i++) {
        cout << movies[i].getname() << ", " << movies[i].getrating() << endl;
    }

    return 0;
}
