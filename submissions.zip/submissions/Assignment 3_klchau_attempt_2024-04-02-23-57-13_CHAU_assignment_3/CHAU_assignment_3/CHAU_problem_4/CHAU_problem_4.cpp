//Question 3-1 Benford's Law re-do - 10 pts

#include <iostream>
#include <array>
#include <cmath>
#include <fstream> 

using namespace std;

double CalcPercentage(int count, int total) {
    if (total == 0) return 0.0;
    double percentage = 100 * count / total;
    return round(percentage * 10) / 10; 
}

int main() {
    const int MAX = 3295;
    int count = 0;
    int zeros= 0, ones = 0, twos = 0, three = 0, fours = 0, fives = 0, sixes = 0, sevens = 0, eights = 0, nines = 0;

    ifstream inFile("enrollments.txt"); // Open the file

    if (!inFile) {
        cerr << "Unable to open file enrollments.txt" << endl;
        return 1; 
    }

    while (count < MAX && inFile) { 
        int num = 0;
        inFile >> num; 

        if (num == 0) continue; 

        while (num >= 10) { 
            num = num / 10;
        }
        
        switch (num) {
            case 1:
                ones += 1; 
                break; 
            case 2:
                twos += 1; 
                break;
            case 3:
                three += 1; 
                break;
            case 4:
                fours += 1; 
                break; 
            case 5:
                fives += 1; 
                break; 
            case 6:
                sixes += 1; 
                break; 
            case 7:
                sevens += 1; 
                break; 
            case 8:
                eights += 1; 
                break; 
            case 9:
                nines += 1; 
                break; 
            default:
                break;
        }
        count += 1;
    }

    inFile.close(); // Close the file

    cout << "There are " << ones << " ones. Its percentage is " << CalcPercentage(ones, count) << "%" << endl;
    cout << "There are " << twos << " twos. Its percentage is " << CalcPercentage(twos, count) << "%" << endl;
    cout << "There are " << three << " threes. Its percentage is " << CalcPercentage(three, count) << "%" << endl;
    cout << "There are " << fours << " fours. Its percentage is " << CalcPercentage(fours, count) << "%" << endl;
    cout << "There are " << fives << " fives. Its percentage is " << CalcPercentage(fives, count) << "%" << endl;
    cout << "There are " << sixes << " sixes. Its percentage is " << CalcPercentage(sixes, count) << "%" << endl;
    cout << "There are " << sevens << " sevens. Its percentage is " << CalcPercentage(sevens, count) << "%" << endl;
    cout << "There are " << eights << " eights. Its percentage is " << CalcPercentage(eights, count) << "%" << endl;
    cout << "There are " << nines << " nines. Its percentage is " << CalcPercentage(nines, count) << "%" << endl;

    return 0;
}
