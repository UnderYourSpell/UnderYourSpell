1. Run the program as normal on the IDE. Make sure all header files are present. 

2. 

3. Run the program as normal on the IDE. Make sure all header files are present. 


4. Run the program as normal on the IDE. Make sure all enrollments.txt file is present. 

5. Run the program as normal on the IDE. Make sure all header files are present. Might have to try and run a few times because it may process for too long. 
