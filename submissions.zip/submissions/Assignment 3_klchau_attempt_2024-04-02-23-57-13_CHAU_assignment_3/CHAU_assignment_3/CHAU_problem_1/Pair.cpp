#include "Pair.h"

Pair::Pair() : num1(0), num2(0)
{
}

Pair::Pair(int num1, int num2) : num1(num1), num2(num2)
{
}

int Pair::get1()
{
	return num1;
}

int Pair::get2()
{
	return num2;
}

// Return a new pair that adds the corresponding numbers
Pair Pair::operator+(const Pair& other)
{
	Pair newPair(this->num1, this->num2);
	newPair.num1 += other.num1;
	newPair.num2 += other.num2;
	return newPair;
}

// Return a new pair that adds otherNum to num1 and num2
Pair Pair::operator+(int otherNum)
{
	Pair newPair(this->num1, this->num2);
	newPair.num1 += otherNum;
	newPair.num2 += otherNum;
	return newPair;
}


/*

// Add the code after this into main. It is messing up on VS Code //



#include <iostream>
#include "Pair.h"

using namespace std;

Pair operator+(int num, Pair& pair)
{
	Pair temp(pair.num1, pair.num2);
	temp.num1 += num;
	temp.num2 += num;
	return temp;
}

Pair operator+(Pair& pair1, Pair& pair2)
{
	Pair temp(0, 0);
	temp.num1 = pair1.num1 + pair2.num1;
	temp.num2 = pair1.num2 + pair2.num2;
	return temp;
}

int main()
{
	Pair p1(5, 10);
	Pair p2(1, 2);

	// Outputs 5 and 10
	cout << p1.get1() << " " << p1.get2() << endl;
	// Outputs 1 and 2
	cout << p2.get1() << " " << p2.get2() << endl;

	Pair p3 = p2 + p1;
	// Outputs 6 and 12
	cout << p3.get1() << " " << p3.get2() << endl;

	p3 = 2 + p3; // This doesn't work originally because in the pair.cpp file, there is only established operation where p3 is before the integer. It looks like this "p3 = p3.operator+(2)". 
				 // But because we are using a 2 in that place, it looks like th is, p3 = 2.operator+(pair3), which is not right. To fix this problem, we need to impliment a global operator overload that can access the 
				 // Pair class. This allows the class to accept an argument presented in any order. 
	// Outputs 8 and 14
	cout << p3.get1() << " " << p3.get2() << endl;
}

*/