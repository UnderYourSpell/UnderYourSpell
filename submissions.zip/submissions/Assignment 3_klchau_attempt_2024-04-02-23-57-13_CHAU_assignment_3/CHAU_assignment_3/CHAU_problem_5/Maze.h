#pragma once
const int HEIGHT = 20;
const int WIDTH = 20;

class Maze 
{
private:
	char maze[HEIGHT][WIDTH];
	bool visited[HEIGHT][WIDTH];
public:
	Maze();
	void printMaze(int curx, int cury);
	void setVisited(int y, int x, bool newVal);
	char getXY(int y, int x);
	bool getVisited(int y, int x);
};