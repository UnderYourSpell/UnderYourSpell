#ifndef SOLVER_H
#define SOLVER_H

#include "maze.h"

class Solver {
private:
    Maze maze;
    int solutionX[(Maze::HEIGHT - 2) * (Maze::WIDTH - 2)];
    int solutionY[(Maze::HEIGHT - 2) * (Maze::WIDTH - 2)];
    int numPoints;

public:
    Solver();
    void search(int x, int y);
    void solve();
    void printSolution();
};

#endif // SOLVER_H
