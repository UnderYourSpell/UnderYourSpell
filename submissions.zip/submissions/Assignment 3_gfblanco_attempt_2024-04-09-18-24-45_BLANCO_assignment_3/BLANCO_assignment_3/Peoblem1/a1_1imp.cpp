#include "a3_1.h"

Pair::Pair() : num1(0), num2(0) {}

Pair::Pair(int num1, int num2) : num1(num1), num2(num2) {}

int Pair::get1() {
    return num1;
}

int Pair::get2() {
    return num2;
}

Pair operator+(const Pair& p, int num) {
    return Pair(p.num1 + num, p.num2 + num);
}

Pair operator+(int num, const Pair& p) {
    return Pair(num + p.num1, num + p.num2);
}

Pair Pair::operator+(const Pair& other) {
    return Pair(num1 + other.num1, num2 + other.num2);
}

Pair Pair::operator+(int otherNum) {
    return Pair(num1 + otherNum, num2 + otherNum);
}