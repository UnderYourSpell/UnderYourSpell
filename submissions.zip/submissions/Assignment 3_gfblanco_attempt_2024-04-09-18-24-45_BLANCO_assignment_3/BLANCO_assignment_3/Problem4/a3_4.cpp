#include <iostream>
#include <fstream>

int main() {
    int digitCounts[9] = {0};


    std::ifstream file("enrollments.txt");
    if (!file.is_open()) {
        std::cerr << "Error opening file" << std::endl;
        return 1;
    }


    int num;
    while (file >> num) {
        int firstDigit = num;
        while (firstDigit >= 10) {
            firstDigit /= 10;
        }


        if (firstDigit >= 1 && firstDigit <= 9) {
            digitCounts[firstDigit - 1]++;
        }
    }

    file.close();

    for (int i = 0; i < 9; ++i) {
        std::cout << "Number of numbers starting with " << (i + 1) << ": " << digitCounts[i] << std::endl;
    }

    return 0;
}
