#ifndef MOVIE_HPP
#define MOVIE_HPP

#include <string>

namespace MovieNamespace {
    class Movie {
    private:
        std::string name;
        std::string rating;

    public:
        Movie();
        Movie(const std::string& name, const std::string& rating);
        void setName(const std::string& name);
        std::string getName() const;
        void setRating(const std::string& rating);
        std::string getRating() const;
        static void sortMovies(Movie movies[], int numMovies);
    };
}

#endif // MOVIE_HPP




