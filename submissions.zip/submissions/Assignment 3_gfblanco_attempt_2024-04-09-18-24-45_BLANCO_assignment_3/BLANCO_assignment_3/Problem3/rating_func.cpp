#include "movie.h"
#include <algorithm>

namespace MovieNamespace {


    Movie::Movie() {}
    Movie::Movie(const std::string& name, const std::string& rating)
        : name(name), rating(rating) {}

  
    void Movie::setName(const std::string& name) {
        this->name = name;
    }

 
    std::string Movie::getName() const {
        return name;
    }


    void Movie::setRating(const std::string& rating) {
        this->rating = rating;
    }

    std::string Movie::getRating() const {
        return rating;
    }

    void Movie::sortMovies(Movie movies[], int numMovies) {
        std::sort(movies, movies + numMovies, [](const Movie& a, const Movie& b) {
            return a.getName() < b.getName();
        });
    }

}



