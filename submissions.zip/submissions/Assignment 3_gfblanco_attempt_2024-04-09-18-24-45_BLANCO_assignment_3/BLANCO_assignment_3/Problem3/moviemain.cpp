#include <iostream>
#include "movie.h" 

int main() {
    const int numMovies = 6; // number of movies

    MovieNamespace::Movie movies[numMovies] = {     // Create an array of Movie objects and initialize with specific movie information
        MovieNamespace::Movie("Black Panther", "PG-13"),
        MovieNamespace::Movie("Avengers: Infinity War", "PG-13"),
        MovieNamespace::Movie("A Wrinkle In Time", "PG"),
        MovieNamespace::Movie("Ready Player One", "PG-13"),
        MovieNamespace::Movie("Red Sparrow", "R"),
        MovieNamespace::Movie("The Incredibles 2", "G")
    };
    MovieNamespace::Movie::sortMovies(movies, numMovies);
    for (int i = 0; i < numMovies; ++i) {
        std::cout << i+1 << ". " << movies[i].getName() << ", " << movies[i].getRating() << std::endl;
    }

    return 0;
}

