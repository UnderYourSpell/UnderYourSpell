#include "a3_2.h"
#include <iostream>

int main() {
    using namespace std;
    using namespace ZipCodeNamespace;

    ZipCode zip1(99504);
    ZipCode zip2("110100101000101011000010011");

    int decodedZip = zip2.getZip(); // Call a public member function to get the decoded zip code
    cout << "Decoded Zip code for barcode " << zip2.getBarcode() << ": " << decodedZip << endl;

    return 0;
}