#include "a3_2.h"
#include <iostream>

namespace ZipCodeNamespace {

    // Default constructor
    ZipCode::ZipCode() : m_zip(0), m_barcode("1000000000000000000000000") {}

    // Constructor with zip code input
    ZipCode::ZipCode(int zip) : m_zip(zip) {
        m_barcode = "1000000000000000000000000"; // Placeholder
    }

    // Constructor with barcode input
    ZipCode::ZipCode(const std::string& barcode) : m_barcode(barcode) {
        // Decode barcode and initialize zip
        m_zip = decodeBarcode(barcode);
    }

    int ZipCode::getZip() const {
        return m_zip;
    }

    std::string ZipCode::getBarcode() const {
        return m_barcode;
    }

int ZipCode::decodeBarcode(const std::string& barcode) {
    int zip = 0;
    int key[] = {7, 4, 2, 1, 0};

    for (size_t i = 1; i < barcode.length() - 1; i += 5) {
        int encodedDigit = 0;
        int sum = 0; 
        
        std::string group = barcode.substr(i, 5);
        std::cout << "Group: " << group << std::endl;
        
        for (size_t j = 0; j < 5; ++j) {
            encodedDigit += (barcode[i + j] - '0') * key[j];
            sum += (barcode[i + j] - '0') * key[j];
        }
        
        std::cout << "Encoded digit for group " << (i / 5) + 1 << ": " << encodedDigit << std::endl;
        
        if (encodedDigit == 11) {
            encodedDigit = 0;
        }
        
        zip = zip * 10 + encodedDigit;
        
        std::cout << "Sum of products for group " << (i / 5) + 1 << ": " << sum << std::endl;
    }
    
    return zip;
}



}
