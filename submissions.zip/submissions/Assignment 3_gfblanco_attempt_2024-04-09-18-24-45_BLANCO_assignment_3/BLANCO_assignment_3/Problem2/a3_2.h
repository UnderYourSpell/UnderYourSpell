#pragma once
#include <string>

namespace ZipCodeNamespace {
    class ZipCode {
    public:
        ZipCode(); 
        ZipCode(int zip); 
        ZipCode(const std::string& barcode); 

        int getZip() const; 
        std::string getBarcode() const; 

    private:
        int decodeBarcode(const std::string& barcode); 
        std::string encode(int zip); 

        int m_zip;
        std::string m_barcode; 
    };
}
