#include <iostream>
#include "Movie.h"

void sort(Movie movies[], int size) {
    for (int i = 0; i < (size - 1); i++)
    {
        for (int j = (i+1); j < size; j++)
        {
            if (movies[i].getName() > movies[j].getName())
            {
                Movie temp = movies[i];
                movies[i] = movies[j];
                movies[j] = temp;
            }
        }
    }
}

int main() {
    Movie movies[6];
    movies[0] = Movie("Black Panther", "PG-13");
    movies[1] = Movie("Avengers: Infinity War", "PG-13");
    movies[2] = Movie("A Wrinkle In Time", "PG");
    movies[3] = Movie("Ready Player One", "PG-13");
    movies[4] = Movie("Red Sparrow", "R");
    movies[5] = Movie("The Incredibles 2", "G");

    sort(movies, 6);

    for (int i = 0; i < 6; i++) {
        std::cout << movies[i].getName() << " " << movies[i].getRating() << std::endl;
    }
}
