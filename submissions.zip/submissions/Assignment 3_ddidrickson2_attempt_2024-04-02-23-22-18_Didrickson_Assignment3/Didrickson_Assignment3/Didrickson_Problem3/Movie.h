#pragma once
#include  <string>

class Movie
{
private:
    std::string name, mpaaRating;
public:
    Movie();
    Movie(std::string name, std::string mpaaRating);
    std::string getName();
    std::string getRating();
};