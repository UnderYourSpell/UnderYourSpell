#include "Movie.h"
#include  <string>

Movie::Movie() : name(""), mpaaRating("")
{
}

Movie::Movie(std::string name, std::string mpaaRating) : name(name), mpaaRating(mpaaRating)
{
}

std::string Movie::getName()
{
    return name;
}

std::string Movie::getRating()
{
    return mpaaRating;
}