//
//  Assignment 3
//  Dylan Didrickson
//

There are 4 folders, with each containing the problem as labeled.

Problem 1 can be compiled using 
"g++ pair.cpp pair.h pairCalculations.cpp" 
on a unix system.

Problem 2 can be compiled using 
"g++ display.cpp ZIP.h ZIP.cpp" 
on a unix system.

Problem 3 can be compiled using 
"g++ contentView.cpp Movie.h Movie.cpp" 
on a unix system.

Problem 4 can be compiled using 
"g++ BenfordsLaw.cpp" 
on a unix system. Please make sure a file titled "enrollments.txt" in within the same folder as "a.out".