#include <iostream>
#include "ZIP.h"

int main() {
    Zip zip(99504);
    std::cout << "The ZIP code used is: " << zip.getInt() << std::endl;
    std::cout << "The POSTNET barcode is: " << zip.getPostnet() << "\n\n";
    Zip zip2("100101001101001000110100101");
    std::cout << "The ZIP code used is: " << zip2.getInt() << std::endl;
    std::cout << "The POSTNET barcode is: " << zip2.getPostnet() << "\n\n";
    return 0;
}
