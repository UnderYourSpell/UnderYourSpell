#include <iostream>
#include "ZIP.h"
#include <sstream>

std::string Zip::intToPostnet(int barcodeDigits[], int zipCode) {
    for (int i = 21; i > 0; i-=5) {
        int singleInt = zipCode % 10;
        zipCode = zipCode / 10;
        if (singleInt == 0) {
            barcodeDigits[i] = 1;
            barcodeDigits[i+1] = 1;
            barcodeDigits[i+2] = 0;
            barcodeDigits[i+3] = 0;
            barcodeDigits[i+4] = 0;
        } else if (singleInt == 1) {
            barcodeDigits[i] = 0;
            barcodeDigits[i+1] = 0;
            barcodeDigits[i+2] = 0;
            barcodeDigits[i+3] = 1;
            barcodeDigits[i+4] = 1;
        } else if (singleInt == 2) {
            barcodeDigits[i] = 0;
            barcodeDigits[i+1] = 0;
            barcodeDigits[i+2] = 1;
            barcodeDigits[i+3] = 0;
            barcodeDigits[i+4] = 1;
        } else if (singleInt == 3) {
            barcodeDigits[i] = 0;
            barcodeDigits[i+1] = 0;
            barcodeDigits[i+2] = 1;
            barcodeDigits[i+3] = 1;
            barcodeDigits[i+4] = 0;
        } else if (singleInt == 4) {
            barcodeDigits[i] = 0;
            barcodeDigits[i+1] = 1;
            barcodeDigits[i+2] = 0;
            barcodeDigits[i+3] = 0;
            barcodeDigits[i+4] = 1;
        } else if (singleInt == 5) {
            barcodeDigits[i] = 0;
            barcodeDigits[i+1] = 1;
            barcodeDigits[i+2] = 0;
            barcodeDigits[i+3] = 1;
            barcodeDigits[i+4] = 0;
        } else if (singleInt == 6) {
            barcodeDigits[i] = 0;
            barcodeDigits[i+1] = 1;
            barcodeDigits[i+2] = 1;
            barcodeDigits[i+3] = 0;
            barcodeDigits[i+4] = 0;
        } else if (singleInt == 7) {
            barcodeDigits[i] = 1;
            barcodeDigits[i+1] = 0;
            barcodeDigits[i+2] = 0;
            barcodeDigits[i+3] = 0;
            barcodeDigits[i+4] = 1;
        } else if (singleInt == 8) {
            barcodeDigits[i] = 1;
            barcodeDigits[i+1] = 0;
            barcodeDigits[i+2] = 0;
            barcodeDigits[i+3] = 1;
            barcodeDigits[i+4] = 0;
        } else {
            barcodeDigits[i] = 1;
            barcodeDigits[i+1] = 0;
            barcodeDigits[i+2] = 1;
            barcodeDigits[i+3] = 0;
            barcodeDigits[i+4] = 0;
        }
    }

    std::stringstream fullCode;
    for (int k = 0; k < 27; k++) {
        fullCode << barcodeDigits[k];
    }
    std::string postNet;
    fullCode >> postNet;
    return postNet;
}

int Zip::postnetToInt(std::string barCode) {
    int tempArr[27]; //Holds string to int conversion
    int finalZip[5]; //Holds final Zip digits
    for(int i=0; i < 27; i++) {
        tempArr[i] = barCode[i] - 48; // 0 is 48 and 1 is 49 so -48 makes the ints 0 or 1 instead of 48 or 49.
    }
    for(int i=1; i < 27; i+=5) {
        int calcArr[5];
        // Selects the 5 digits to be multiplied.
        for(int j = 0; j < 5; j++) {
            calcArr[j] = tempArr[i+j];
        }
        calcArr[0] = calcArr[0] * 7;
        calcArr[1] = calcArr[1] * 4;
        calcArr[2] = calcArr[2] * 2;
        calcArr[3] = calcArr[3] * 1;
        calcArr[4] = calcArr[4] * 0;
        int digit = 0;
        for(int j : calcArr) {
            digit += j;
        }
        if (digit == 11) {
            digit = 0;
        }
        finalZip[i/5] = digit;
    }
    std::stringstream fullZip;
    for (int k = 0; k < 5; k++) {
        fullZip << finalZip[k];
    }
    int completeZip;
    fullZip >> completeZip;
    return completeZip;
}

Zip::Zip(std::string barCode) : zipCode(postnetToInt(barCode))
{
}

Zip::Zip(int zipCode) : zipCode(zipCode)
{
}

int Zip::getInt() const {
    return zipCode;
}

std::string Zip::getPostnet() {
    int barcodeDigits[27];
    for (int i = 0; i < 27; i++) {
        barcodeDigits[i] = 0;
    }
    barcodeDigits[0] = 1;
    barcodeDigits[26] = 1;
    return intToPostnet(barcodeDigits, zipCode);
}
