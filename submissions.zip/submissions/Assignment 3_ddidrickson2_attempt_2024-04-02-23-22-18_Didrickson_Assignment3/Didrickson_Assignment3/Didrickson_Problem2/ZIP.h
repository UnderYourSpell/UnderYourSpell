#include <string>

class Zip {
private:
    int zipCode;
    std::string intToPostnet(int barcodeDigits[], int zipCode);
    int postnetToInt(std::string barCode);
public:
    Zip(std::string barCode);
    Zip(int zipCode);
    int getInt() const;
    std::string getPostnet();

};
