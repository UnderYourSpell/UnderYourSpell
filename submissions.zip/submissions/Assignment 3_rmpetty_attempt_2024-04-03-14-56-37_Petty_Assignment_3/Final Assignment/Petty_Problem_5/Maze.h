#ifndef MAZE_H
#define MAZE_H


class Maze
{
    public:
        Maze();
        virtual ~Maze();


    //protected:

    private:
        const int HEIGHT=10;
        const int WIDTH=10;

        bool foundExit = false;
        int x=1, y=1;

        bool validMove(char maze[][WIDTH], bool visited[][WIDTH], int newX, int newY);
        bool search(char maze[][WIDTH], bool visited[][WIDTH], int x, int y);
        void printMaze(char maze[][WIDTH], int curx, int cury);

        char maze[HEIGHT][WIDTH];
        bool visited[HEIGHT][WIDTH];

};

#endif // MAZE_H
