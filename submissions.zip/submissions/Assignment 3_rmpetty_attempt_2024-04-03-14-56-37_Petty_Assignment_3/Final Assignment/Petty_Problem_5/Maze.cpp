#include "Maze.h"

Maze::Maze()
{
    maze = {
		   {'X','X','X','X','X','X','X','X','X','X'},
		   {'X',' ',' ',' ',' ',' ','X',' ',' ','X'},
		   {'X',' ','X',' ',' ',' ','X',' ',' ','X'},
		   {'X',' ','X','X','X',' ','X',' ',' ','X'},
		   {'X',' ',' ',' ','X',' ','X',' ',' ','X'},
		   {'X',' ',' ',' ','X',' ',' ',' ','X','X'},
		   {'X',' ','X','X','X',' ',' ',' ',' ','X'},
		   {'X',' ','X',' ',' ',' ','X',' ',' ','X'},
		   {'X',' ',' ',' ',' ',' ','X',' ','E','X'},
		   {'X','X','X','X','X','X','X','X','X','X'}
	};

	//initializes visited locations to false
	for (int x = 0; x < WIDTH; x++)
		for (int y = 0; y < HEIGHT; y++)
			visited[y][x] = false;
	visited[y][x] = true;

	search(maze, visited, x, y);
}


Maze::~Maze()
{
    //dtor
}


bool Maze::validMove(char maze[][WIDTH], bool visited[][WIDTH], int newX, int newY)
{
    // Check for going off the maze edges
	if (newX < 0 || newX >= WIDTH)
		return false;
	if (newY < 0 || newY >= HEIGHT)
		return false;
	// Check if target is a wall
	if (maze[newY][newX] == 'X')
		return false;
	// Check if visited
	if (visited[newY][newX])
		return false;
	return true;
}


bool Maze::search(char maze[][WIDTH], bool visited[][WIDTH], int x, int y)
{
    if (maze[y][x] == 'E')
		return true;

	bool foundExit = false;
	visited[y][x] = true;
	if (validMove(maze, visited, x, y - 1))
		foundExit = search(maze, visited, x, y - 1);
	if (!foundExit && (validMove(maze, visited, x, y + 1)))
		foundExit = search(maze, visited, x, y + 1);
	if (!foundExit && (validMove(maze, visited, x - 1, y)))
		foundExit = search(maze, visited, x - 1, y);
	if (!foundExit && (validMove(maze, visited, x + 1, y)))
		foundExit = search(maze, visited, x + 1, y);

	if (foundExit)
	{
		printMaze(maze, x, y);
		cout << endl;
		return true;
	}
	return false;
}


void Maze::printMaze(char maze[][WIDTH], int curx, int cury)
{
    for (int y = 0; y < HEIGHT; y++)
	{
		for (int x = 0; x < WIDTH; x++)
		{
			if ((x == curx) && (y == cury))
				cout << "@";
			else
				cout << maze[y][x];
		}
		cout << endl;
	}
}
