#pragma once

#include <string>
#include <iostream>
#include <string>

using namespace std;

class ZipCode
{
public:
	ZipCode(int zipInt);
	ZipCode(string zipBar);

	int GetInt(string barcode);
	string GetBar(int zipcode);
	string NumForm(string barPart);

private:
	int zipInt;
	string zipBar="1";

	string Encode(int zipcode);
	int Decode(string barcode);

};

