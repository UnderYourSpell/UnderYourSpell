#include <iostream>
#include "ZipCode.h"
#include <string>

using namespace std;

int main()
{
    int userInput; //takes in 1 or 2 for barcode or zipcode, respectively
    string barcode;
    int zipcode;
    
    //asking whether entering barcode or zip
    cout << "Enter (1) to enter the barcode and (2) to enter the zipcode: ";
    cin >> userInput;
    
    //makes sure user enters 1 or 2
    while (userInput != 1 && userInput != 2) {
        cout << "Enter (1) to enter the barcode and (2) to enter the zipcode: ";
        cin >> userInput;
    }

    //is userInput == 1, treats as string barcode
    if (userInput == 1) {
        cout << "Enter the 27 digit barcode: ";
        cin >> barcode;

        //verifies barcode is 27 digits
        while (barcode.length() != 27) {
            cout << "The barcode must be 27 digits (include beginning and end 1's): ";
            cin >> barcode;
        }

        ZipCode zipBar(barcode);
        cout << "\nZip Code: " << zipBar.GetInt(barcode) << endl;
    }


    //if userInput == 2, treats as int zip code
    else if (userInput == 2) {
        cout << "Enter the 5 digit zipcode: ";
        cin >> zipcode;

        while (to_string(zipcode).length() != 5) {
            cout << "The zipcode must be 5 digits: ";
            cin >> zipcode;
        }

        ZipCode zipInt(zipcode);
        cout << "Bar code: " << zipInt.GetBar(zipcode) << endl;
    }

	return 0;
}