#include "ZipCode.h"
#include <string>
using namespace std;

ZipCode::ZipCode(int zipInt) : zipInt(zipInt)
{
}

ZipCode::ZipCode(string zipBar) : zipBar(zipBar)
{
}

string ZipCode::GetBar(int zipcode)
{
    Encode(zipcode);
    return zipBar;
}

int ZipCode::GetInt(string barcode)
{
    Decode(barcode);
    return zipInt;
}

string ZipCode::Encode(int zipcode)
{
    string zip_str;
    
    //setting values for 0-9
    string digit_1 = "00011", digit_2 = "00101", digit_3 = "00110", digit_4 = "01001",
        digit_5 = "01010", digit_6 = "01100", digit_7 = "10001", digit_8 = "10010", 
        digit_9 = "10100", digit_0="11000";

    //converting int zipcode to a string
    zip_str = to_string(zipcode);

    for (int i = 0; i < 5; i++) {
        
        if (zip_str[i] == '0') {
            zipBar += digit_0;
        }

        else if (zip_str[i] == '1') {
            zipBar += digit_1;
        }

        else if (zip_str[i] == '2') {
            zipBar += digit_2;
        }

        else if (zip_str[i] == '3') {
            zipBar += digit_3;
        }

        else if (zip_str[i] == '4') {
            zipBar += digit_4;
        }

        else if (zip_str[i] == '5') {
            zipBar += digit_5;
        }

        else if (zip_str[i] == '6') {
            zipBar += digit_6;
        }

        else if (zip_str[i] == '7') {
            zipBar += digit_7;
        }

        else if (zip_str[i] == '8') {
            zipBar += digit_8;
        }

        else if (zip_str[i] == '9') {
            zipBar += digit_9;
        }
    }
    
    //adding ending '1'
    zipBar += "1";
    
    return zipBar;
}

int ZipCode::Decode(string barcode)
{
    
    string newBar = "";
    string p1="", p2="", p3="", p4="", p5="";
    string zipStr = "";
    
    //removes beginning and end 1's
    for (int i = 1; i < 26; i++) {
        newBar += barcode[i];
    }

    //cuts barcode string into 5 separate strings
    for (int i = 0; i < 5; i++) {
        p1 += newBar[i];
    }

    for (int i = 5; i < 10; i++) {
        p2 += newBar[i];
    }

    for (int i = 10; i < 15; i++) {
        p3 += newBar[i];
    }

    for (int i = 15; i < 20; i++) {
        p4 += newBar[i];
    }

    for (int i = 20; i < 25; i++) {
        p5 += newBar[i];
    }

    //concats individual numbers to one string
    zipStr = NumForm(p1) + NumForm(p2) + NumForm(p3) + NumForm(p4) + NumForm(p5);
    
    //converts zipStr to an integer zipInt
    zipInt = stoi(zipStr);

    return zipInt;
  
}

//does 7 4 2 1 0 math with respective elements
string ZipCode::NumForm(string barPart)
{
    int sum;
    int int1, int2, int3, int4, int5;
    string num;
    
    //converts each element to an int
    int1 = barPart[0] - '0';
    int2 = barPart[1] - '0';
    int3 = barPart[2] - '0';
    int4 = barPart[3] - '0';
    int5 = barPart[4] - '0';

    //add respective multiples
    sum = int1*7 + int2*4 + int3*2 + int4*1 + int5*0;

    //updates num to 0 if sum is 11
    if (sum == 11) {
        num = "0";
    }
    
    //otherwises, converts back to string
    else {
        num = to_string(sum);
    }

    return num;
}