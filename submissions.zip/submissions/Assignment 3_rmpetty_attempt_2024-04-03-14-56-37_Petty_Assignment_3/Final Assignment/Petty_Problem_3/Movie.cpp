#include "Movie.h"
#include <string>
using namespace std;

Movie::Movie()
{
	name = "Unknown";
	rating = "Unrated";
}

Movie::Movie(string name, string rating) : name(name), rating(rating)
{
	//name = name_mov;
	//rating = rating_mov;
}

void Movie::SetName(string name)
{
	name = name;
}

void Movie::SetRating(string rating)
{
	rating = rating;
}

string Movie::GetName()
{
	return name;
}

string Movie::GetRating()
{
	return rating;
}
