#pragma once

#include <string>
#include <iostream>
#include <cstdlib>
#include <string>
using namespace std;

class Movie
{
private:
	string name;
	string rating;

public:
	Movie();
	Movie(string name, string rating);

	void SetName(string name);
	void SetRating(string rating);
	string GetName();
	string GetRating();
	
};

