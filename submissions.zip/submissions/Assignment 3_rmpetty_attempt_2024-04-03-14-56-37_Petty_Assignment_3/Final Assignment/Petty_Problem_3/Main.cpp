#include <iostream>
#include <string>
#include "Movie.h"

using namespace std;

void swap(Movie& a, Movie& b)
{
	Movie temp = a;
	a = b;
	b = temp;
}

void bubbleSort(Movie movie_info[], int n)
{
	for (int i = 0; i < n - 1; i++)
	{
		for (int j = 0; j < n - 1 - i; j++)
		{
			if (movie_info[j].GetName() > movie_info[j + 1].GetName())
				swap(movie_info[j], movie_info[j + 1]);
		}
	}
}

int main()
{
	Movie movie1("Black Panther", "PG-13");
	Movie movie2("Avengers: Infinity War", "PG-13");
	Movie movie3("A Wrinkle In Time", "PG");
	Movie movie4("Ready Player One", "PG-13");
	Movie movie5("Red Sparrow", "R");
	Movie movie6("The Incredibles 2", "G");
	
	Movie movie_info[6] = {movie1, movie2, movie3, movie4, movie5, movie6 };

	bubbleSort(movie_info, 6);

	for (int i = 0; i < 6; i++) {
		cout << i+1 << ". " << movie_info[i].GetName() << ", " << movie_info[i].GetRating() << endl;
	}
	
	return 0;
}