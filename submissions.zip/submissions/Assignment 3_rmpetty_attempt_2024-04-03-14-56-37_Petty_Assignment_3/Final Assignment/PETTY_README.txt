Q1: added lines of code are commented out, as they are my best guess at how it could be written.
Q2: runs accordingly
Q3: runs accordingly
Q4: runs accordingly
Q5: completed to the best of my ability, however program is non-functional