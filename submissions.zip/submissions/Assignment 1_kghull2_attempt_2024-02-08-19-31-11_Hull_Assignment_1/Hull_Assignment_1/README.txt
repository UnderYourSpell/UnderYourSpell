Question 1: Works fine, run using "./a.out < enrollments.txt"

Question 2: Works fine, was also a lot of fun to test (I won 100,000 dollars!)

Question 4: Works fine with the test code, but was not updated to recieve change amount from user input. (I wasn't sure if I was supposed to or just leave the two test cases.)
