#include <iostream>

using namespace::std;

int main(void){
	int numArray[3295];
	int ones, twos, threes, fours, fives, sixes, sevens, eights, nines;
	ones = twos = threes = fours = fives = sixes = sevens = eights = nines = 0;
	int currentNum;

	for(int i = 0; i < 3295; i++){
		cin >> numArray[i];
		if(numArray[i] >= 1000){
			currentNum = numArray[i] / 1000;
		}
		else if(numArray[i] >= 100){
			currentNum = numArray[i] / 100;
		}
		else if(numArray[i] >= 10){
			currentNum = numArray[i] / 10;
		}
		else{
			currentNum = numArray[i];
		}
			switch(currentNum) {
				case 1:
					ones += 1;
					break;
				case 2:
					twos += 1;
					break;
				case 3:
					threes += 1;
					break;
				case 4:
					fours += 1;
					break;
				case 5:
					fives += 1;
					break;
				case 6:
					sixes += 1;
					break;
				case 7:
					sevens += 1;
					break;
				case 8:
					eights += 1;
					break;
				case 9:
					nines += 1;
					break;
				default:
					cout << "You shouldn't see this message, an error occured if you do." << endl;
					break;
			}
		}
	cout << ones << " numbers begin with a 1. " << twos << " numbers begin with a 2. " << threes << " numbers begin with a 3. " << fours << " numbers begin with a 4. "
	<< fives << " numbers begin with a 5. " << sixes << " numbers begin with a 6. " << sevens << " numbers begin with a 7. " << eights << " numbers begin with a 8. "
	<< nines << " numbers begin with a 9." << endl;
}
