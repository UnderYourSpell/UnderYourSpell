#include <iostream>
#include <ctime>

using namespace::std;

void chuckaLuck(int &money, int bet, int playerNum){
	int winCount = 0;
	int roll = 0;
	money -= bet;
	for(int i = 0; i < 3; i++){
		roll = rand() % 6 + 1;
		cout << "The die rolls a " << roll << endl;
		if(roll == playerNum){
			winCount += 1;
		}
	}
	if(winCount > 0){
		money += (bet * winCount);
		cout << "You won $" << (bet * winCount) << "!" << endl;
	}
	else {
		cout << "You lost!" << endl;
	}
}

int main(void){
	int money = 100;
	int playerNum;
	int bet;
	bool keepPlaying = true;
	char cont;
	srand(time(0));

	while(keepPlaying == true){
		cout << "You currently have: $" << money << ".\nSelect your number (1-6):";
		cin >> playerNum;
		if(playerNum > 6 || playerNum < 1){
			while(playerNum > 6 || playerNum < 1){
				cout << "Invalid number. Enter a value between 1 and 6:";
				cin >> playerNum;
			}
		}
		cout << "How much do you want to bet?: ";
		cin >> bet;
		if(bet > money || bet < 1){
			while(bet > money || bet < 1){
				cout << "Invalid bet. You have $" << money << ". How much would you like to bet?";
				cin >> bet;
			}
		}
		chuckaLuck(money, bet, playerNum);

		cout << "Do you want to keep playing? (y/n): ";
		cin >> cont;
		cont = tolower(cont);
		if(cont != 'y' && cont != 'n'){
			while(cont != 'y' && cont != 'n'){
				cout << "Invalid response, please respond with y or n: ";
				cin >> cont;
				cont = tolower(cont);
			}
		}
		else if(cont == 'y'){
			if(money <= 0){
				keepPlaying = false;
				cout << "You're out of money." << endl;
			}
			else{
				keepPlaying = true;
			}
		}
		else if(cont == 'n'){
			keepPlaying = false;
			cout << "Your final money is $" << money << endl;
		}
}
}
