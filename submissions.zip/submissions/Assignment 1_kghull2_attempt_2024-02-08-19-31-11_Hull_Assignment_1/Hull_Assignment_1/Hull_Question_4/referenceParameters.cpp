#include <iostream>

using namespace::std;

void change(int amount, int &quarters, int &dimes, int &nickels, int &pennies){
	while (amount > 0) {
		if (amount >= 25){
			quarters += 1;
			amount -= 25;
		}
		else if (amount >= 10) {
			dimes += 1;
			amount -= 10;
		}
		else if (amount >= 5){
			nickels += 1;
			amount -= 5;
		}
		else {
			pennies += 1;
			amount -= 1;
		}
	}
}

int main(void){
	int amount = 0, quarters = 0, dimes = 0, nickels = 0, pennies = 0;
	for(int i = 0; i <= 1; i++){
		if (i == 0) {
		amount = 67;
		}
		else {
		amount = 24;
		}
		cout << "You need " << amount << " cents in change." << endl;
		change(amount, quarters, dimes, nickels, pennies);
		cout << "To correct change for your amount is: " << quarters << " quarters, " << dimes << " dimes, " <<
		nickels << " nickels, and " << pennies << " pennies." << endl;
		quarters = 0;
		dimes = 0;
		nickels = 0;
		pennies = 0;
	}
}

