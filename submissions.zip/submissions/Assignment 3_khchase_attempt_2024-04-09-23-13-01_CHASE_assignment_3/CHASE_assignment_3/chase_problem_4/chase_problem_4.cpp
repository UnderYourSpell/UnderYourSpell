#include <fstream>
#include <iomanip>
#include <iostream>

using namespace std;

// Finds the leading digit of an integer.
// Uses recursion.
int firstDigit(int x)
{
    if (x / 10 >= 1) {
        return firstDigit(x / 10);
    }
    else {
        return x;
    }
}

int main() {
    ifstream dataFS;
    int num, first, total = 0;
    int digits[10] = {0};
    
    // Opens data file
    dataFS.open("enrollments.txt");
    
    // Count number of each leading digit
    while (!dataFS.fail()) {
        dataFS >> num;
        first = firstDigit(num);
        
        digits[first] += 1;
        total += 1;
    }
    
    // Closes data.txt file
    dataFS.close();
    
    // Print distribution of digits
    for (int i = 1; i < 10; i++) {
        cout << fixed << setprecision(3) << digits[i] / (total * 1.0) << endl;
    }
    
}

