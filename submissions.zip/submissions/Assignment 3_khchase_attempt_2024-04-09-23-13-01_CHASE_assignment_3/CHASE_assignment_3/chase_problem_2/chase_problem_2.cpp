#include <iostream>
#include <string>

using namespace std;


class ZipCode
{
private:
    string code;
    int nums[5] = {7, 4, 2, 1, 0};
    string digitToStr(int digit);
    string intToStr(int intCode);
    int strToDigit(string str);
public:
    void setCodeInt(int newCode);
    void setCodeStr(string newCode);
    int getCodeInt();
    string getCodeStr();
};


// Set code using an int input.
// Uses private ZipCode function intToStr.
void ZipCode::setCodeInt(int newCode)
{
    code = intToStr(newCode);
}

// Set code using a string input.
void ZipCode::setCodeStr(string newCode)
{
    code = newCode;
}

// Return code as a string.
string ZipCode::getCodeStr()
{
    return code;
}

// Converts an int digit to a five-char string.
string ZipCode::digitToStr(int digit)
{
    string str = "";
    int count = 0;
    
    for (int num : nums) {
        if ((count < 2) && (digit >= num))
        {
            str += '1';
            count += 1;
        }
        else
            str += '0';
        
        digit = digit % num;
    }
    
    // Check for when digit is zero
    if (str == "00000")
        str = "11000";
    
    return str;
}

// Converts an int code to a string code.
// Uses private Zipcode function digitToStr.
string ZipCode::intToStr(int intCode)
{
    string strCode = "1";
    
    // Convert each digit to a five digit code string
    strCode += digitToStr(intCode / 10000);
    strCode += digitToStr((intCode / 1000) % 10);
    strCode += digitToStr((intCode / 100) % 10);
    strCode += digitToStr((intCode / 10) % 10);
    strCode += digitToStr(intCode % 10);
    
    strCode += '1';
    
    return strCode;
}

// Returns a digit of the code after converting from a string.
int ZipCode::strToDigit(string str)
{
    int digit = 0;
    
    for (int i = 0; i < 5; i++)
    {
        if (str[i] == '1')
            digit += nums[i];
    }
    
    if (digit == 11)
        digit = 0;
    
    return digit;
}

// Return code as an int after converting from a string.
// Uses private Zipcode function strToDigit.
int ZipCode::getCodeInt()
{
    int intCode = 0;
    
    intCode += 10000 * strToDigit(code.substr(1, 5));
    intCode += 1000 * strToDigit(code.substr(6, 5));
    intCode += 100 * strToDigit(code.substr(11, 5));
    intCode += 10 * strToDigit(code.substr(16, 5));
    intCode += strToDigit(code.substr(21, 5));
    
    return intCode;
}

int main()
{
    ZipCode c1, c2;
    
    c1.setCodeInt(12080);
    cout << c1.getCodeStr() << endl;
    cout << c1.getCodeInt() << endl;
    
    c2.setCodeStr("110100101000101011000010011");
    cout << c2.getCodeStr() << endl;
    cout << c2.getCodeInt() << endl;
}
