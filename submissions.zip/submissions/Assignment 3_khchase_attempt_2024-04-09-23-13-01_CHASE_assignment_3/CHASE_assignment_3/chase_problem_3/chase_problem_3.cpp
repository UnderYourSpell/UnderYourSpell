#include <iostream>
#include <string>

using namespace std;


class Movie
{
private:
    string name;
    string rating;
public:
    void initialize(string newName, string newRating);
    string getName();
    string getRating();
};

void Movie::initialize(string newName, string newRating)
{
    name = newName;
    rating = newRating;
}

string Movie::getName()
{
    return name;
}

string Movie::getRating()
{
    return rating;
}

// Sorts an array of Movies by their names in alphabetical order.
void sort(Movie m[], int size = 6)
{
    int index;
    Movie temp;
    
    for (int i = 0; i < size; i++)
    {
        index = i;
        
        // Find most alphabetical element
        for (int j = i; j < size; j++)
        {
            if (m[j].getName() <= m[index].getName())
                index = j;
        }
        
        // Swap elements so most alphabetical element is earlier
        temp = m[index];
        m[index] = m[i];
        m[i] = temp;
        
        cout << m[i].getName() << ", " << m[i].getRating() << endl;
    }
}


int main()
{
    Movie movies[6];
    
    movies[0].initialize("Black Panther", "PG-13");
    movies[1].initialize("Avengers: Infinity War", "PG-13");
    movies[2].initialize("A Wrinkle in Time", "PG");
    movies[3].initialize("Ready Player One", "PG-13");
    movies[4].initialize("Red Sparrow", "R");
    movies[5].initialize("The Incredibles 2", "G");
    
    sort(movies);
}
