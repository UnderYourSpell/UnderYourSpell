Assignment 3 README
Kiera Chase
CSCE A211
Dr. Sebastian Neumayer
April 6, 2026


Problem 1:

p3 = 2 + p3 doesn't work because the compiler does not recognize it as the overload operator, and does not know how to add p3 and an integer without instructions.

No code.


Problem 2:

In folder chase_problem_2 named chase_problem_2.cpp

Stores zip codes as Zipcode class members. Accepts both integer and string zip code inputs, and prints integer and string zip codes. Zipcode class tested in main() with two zip codes, input as an integer and a string respectively.

This program should run in any IDE that works for C++.

No known issues.


Problem 3:

In folder chase_problem_3 named chase_problem_3.cpp

Stores information of six movies using a Movie class, then sorts them alphabetically by title.

This program should run in any IDE that works for C++.

No known issues.


Problem 4:

In folder chase_problem_4 named chase_problem_4.cpp with file enrollments.txt

This program should run in any IDE that works for C++. When using Xcode, "enrollments.txt" in line 25 must be changed to the absolute path to enrollments.txt

As I wrote this in Xcode, it has been tested to work with the full path on my computer to enrollments.txt and has not been tested with the relative path version.


Problem 5:

In folder chase_problem_5 named chase_problem_5.cpp

Creates a maze and allows the user to try to solve it before automatically solving it.

No known problems.