#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;


const int WIDTH = 30;
const int HEIGHT = 30;


class Maze
{
private:
    // Variables
    char maze[HEIGHT][WIDTH];
    bool visited[HEIGHT][WIDTH];
    int curX, curY, numEntries;
    
    // Functions
    void printMaze(int curx, int cury);
    bool validMove(int newX, int newY);
    // *** search has new parameters to remember the coordinates of the solution we find
    bool search(int x, int y, int solutionX[], int solutionY[]);
    // *** New function, see below
    void addToArrays(int x[], int y[], int xVal, int yVal);
    void resetPath();
public:
    Maze();
    void autoSolve();
    void manualSolve();
    
};

// Creates a random maze with start and end positions.
// Uses private Maze functions resetPath and printMaze.
Maze::Maze()
{
    /****************
     Programmatically fill out the maze with ***'s on the borders and spaces in the middle
     ****************/
    // All blank
    for (int x = 0; x < WIDTH; x++)
     for (int y = 0; y < HEIGHT; y++)
       maze[y][x] = ' ';
    // Borders with X
    for (int x = 0; x < WIDTH; x++)
    {
       maze[0][x] = 'X';
       maze[HEIGHT-1][x] = 'X';
    }
    for (int y = 0; y < HEIGHT; y++)
    {
       maze[y][0] = 'X';
       maze[y][WIDTH-1] = 'X';
    }

    // ***** Randomly fill in 25% of the middle
    int numCells = static_cast<int>((HEIGHT-2)*(WIDTH-2)*0.25);
    int count = 0;
    while (count < numCells)
    {
       int x = (rand() % (WIDTH-2)) +1;
       int y = (rand() % (HEIGHT-2)) +1;
       if (maze[y][x]==' ')
       {
           maze[y][x]='X';
           count++;
       }
    }

    // ***** Pick a random start and end that is not a wall *****
    do {
      curX = (rand() % (WIDTH-2)) +1;
      curY = (rand() % (HEIGHT-2)) +1;
    } while (maze[curY][curX] == 'X');
    // At this point, (x,y) contains our start position
    // ***** Pick a random end position that is not a wall *******
    int exitX = (rand() % (WIDTH-2)) +1;
    int exitY = (rand() % (HEIGHT-2)) +1;
    while (maze[exitY][exitX]=='X')
    {
      exitX = (rand() % (WIDTH-2)) +1;
      exitY = (rand() % (HEIGHT-2)) +1;
    }
    maze[exitY][exitX]='E';

    resetPath();
    printMaze(curX, curY);
}

//
// Does not use other functions
void Maze::addToArrays(int x[], int y[], int xVal, int yVal)
{
   x[numEntries] = xVal;
   y[numEntries] = yVal;
   numEntries++;
}

// Checks if a potential move is valid.
// Does not use other functions
bool Maze::validMove(int newX, int newY)
{
 // Check for going off the maze edges
 if (newX < 0 || newX >= WIDTH)
    return false;
 if (newY < 0 || newY >= HEIGHT)
    return false;
 // Check if target is a wall
 if (maze[newY][newX]=='X')
    return false;
 // Check if visited
 if (visited[newY][newX])
    return false;
 return true;
}

// Prints the maze.
// Does not use other functions
void Maze::printMaze(int curx, int cury)
{
  for (int y=0; y < HEIGHT;y++)
  {
    for (int x=0; x < WIDTH; x++)
    {
    if ((x==curx) && (y==cury))
        cout << "@";
    else
        cout << maze[y][x];
    }
    cout << endl;
  }
}

bool Maze::search(int x, int y, int solutionX[], int solutionY[])
{
   bool foundExit = false;

   if (maze[y][x]=='E')
    return true;
   visited[y][x]=true;
   if (validMove(x,y-1))
    foundExit = search(x,y-1,solutionX,solutionY);
   if (!foundExit && (validMove(x,y+1)))
    foundExit = search(x,y+1,solutionX,solutionY);
   if (!foundExit && (validMove(x-1,y)))
    foundExit = search(x-1,y,solutionX,solutionY);
   if (!foundExit && (validMove(x+1,y)))
    foundExit = search(x+1,y,solutionX,solutionY);

   if (foundExit)
   {
    // Remember coordinates we found the exit in the solution arrays
    addToArrays(solutionX, solutionY, x, y);
    return true;
   }
   return false;
}

// Sets all of visited to false.
// Does not use other functions.
void Maze::resetPath()
{
    // Initialize visited locations to false
    for (int x = 0; x < WIDTH; x++)
     for (int y = 0; y < HEIGHT; y++)
           visited[y][x] = false;
}

// Finds the maze solution and prints, or prints "No solution found".
//
void Maze::autoSolve() // maybe make solutions their own class *hint hint*
{
    // Here I created arrays to store the x/y coordinates for the path of our solution.
    // The array is of size [HEIGHT-2]*[WIDTH-2] since we'll never exceed that size.
    // I also made a variable to count how many entries we make..
    // It would probably be more convenient to make a class to store this data rather than
    // have two separate arrays!
    int solutionX[(HEIGHT-2)*(WIDTH-2)], solutionY[(HEIGHT-2)*(WIDTH-2)];
    numEntries = 0;
    
    bool found = search(curX,curY,solutionX,solutionY);
    int numPoints = numEntries;

    if (!found)
        cout << "No solution found." << endl;
    else
    {
       cout << "Solution found!  Here is the path from the start." << endl;
       for (int i = numPoints-1; i >= 0; i--)
       {
           printMaze(solutionX[i], solutionY[i]);
           cout << endl;
        }
    }
}

// Allows user to manually solve maze, does not affect visited.
// Uses private Maze functions validMove and printMaze.
void Maze::manualSolve()
{
    cout << "Enter w to go up, s to go down, a to go left, and d to go right." << endl;
    cout << "Enter any other character to exit." << endl;
    
    char c;
    bool solve = true;
    
    while (solve) {
        cin >> c;
        
        if ((c == 'w') && validMove(curX, curY - 1))
            curY -= 1;
        else if ((c == 's') && validMove(curX, curY + 1))
            curY += 1;
        else if ((c == 'a') && validMove(curX - 1, curY))
            curX -= 1;
        else if ((c == 'd') && validMove(curX + 1, curY))
            curX += 1;
        else
        {
            solve = false;
            break;
        }
        
        if (maze[curY][curX] == 'E')
        {
            cout << "Solution found!" << endl;
            solve = false;
        }
        else
            printMaze(curX, curY);
    }
}

int main()
{
    // Seed random number generator with clock time
    srand(time(NULL));
    
    Maze m;
    m.manualSolve();
    m.autoSolve();
}
