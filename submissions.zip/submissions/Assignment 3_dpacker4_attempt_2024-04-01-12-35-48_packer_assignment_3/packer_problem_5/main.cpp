// maze-solver.cpp
//
// This program fills in a maze with random positions and then runs the solver to solve it.
// The moves are saved in two arrays, which store the X/Y coordinates we are moving to.
// They are output in main in forward order.
//
#include <iostream>
#include <ctime>
#include <cstdlib>

#include "Maze.h"


int main() {

    Maze maze;


    bool found = maze.solve();
    if (!found) std::cout << "No solution found\n";
    else {
        std::cout << "Solution found! Here is the path from the start to the finish:\n";
        maze.printHistory();
    }

    return 0;
}