#pragma once
#include <iostream>

#include "PastSolutions.h"

const int WIDTH = 20;
const int HEIGHT = 20;

class Maze {
    private:

        // int HEIGHT, WIDTH;

        char layout[HEIGHT][WIDTH];
        bool visited[HEIGHT][WIDTH];

        int startX, startY, endX, endY;

        // int xHistory[(HEIGHT-2)*(WIDTH-2)], 
        //     yHistory[(HEIGHT-2)*(WIDTH-2)];
        // int numPoints;
        PastSolutions* ps;

        void generateMaze();
        // void addToArrays(int x[], int y[], int &numEntries, int xVal, int yVal);
        bool validMove(int newX, int newY);
        bool search(int x, int y);

    public:
        Maze();

        void printMaze(int curx, int cury);

        bool solve();

        void printHistory();
};