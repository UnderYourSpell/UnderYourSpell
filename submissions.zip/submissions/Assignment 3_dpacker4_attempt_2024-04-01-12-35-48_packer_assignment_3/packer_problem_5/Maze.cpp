#include "Maze.h"

Maze::Maze() {

    generateMaze();

    ps = new PastSolutions();
}

void Maze::generateMaze() {
    for (int x = 0; x < WIDTH; x++) {
        for (int y = 0; y < HEIGHT; y++) {
            layout[y][x] = ' ';
        }
    }

    for (int x = 0; x < WIDTH; x++) {
        layout[0][x] = 'X';
        layout[HEIGHT-1][x] = 'X';
    }

    for (int y = 0; y < HEIGHT; y++) {
        layout[y][0] = 'X';
        layout[y][WIDTH-1] = 'X';
    }

    int numCells = static_cast<int>((HEIGHT-2)*(WIDTH-2)*0.25);
    int count = 0;
    while (count < numCells) {
        int x = (rand() % (WIDTH-2)) + 1;
        int y = (rand() % (HEIGHT-2)) + 1;
        if (layout[y][x] == ' ') {
            layout[y][x] = 'X';
            count++;
        }
    }

    startX = (rand() % (WIDTH-2)) + 1;
    startY = (rand() % (HEIGHT-2)) + 1;
    while (layout[startY][startX] == 'X') {
        startX = (rand() % (WIDTH-2)) + 1;
        startY = (rand() % (HEIGHT-2)) + 1;
    }

    endX = (rand() % (WIDTH-2)) + 1;
    endY = (rand() % (HEIGHT-2)) + 1;
    while (layout[endY][endX] == 'X') {
        endX = (rand() % (WIDTH-2)) + 1;
        endY = (rand() % (HEIGHT-2)) + 1;
    }
    layout[endY][endX] = 'E';

    for (int x = 0; x < WIDTH; x++)
        for (int y = 0; y < HEIGHT; y++)
            visited[y][x] = false;
    visited[startY][startX] = true;
}

// void Maze::addToArrays(int x[], int y[], int &numEntries, int xVal, int yVal) {
//     x[numEntries] = xVal;
//     y[numEntries] = yVal;
//     numEntries++;
// }

bool Maze::validMove(int newX, int newY) {

    if (newX < 0 || newX >= WIDTH) return false;
    if (newY < 0 || newY >= HEIGHT) return false;
    if (layout[newY][newX] == 'X') return false;
    if (visited[newY][newX]) return false;
    return true;
}

void Maze::printMaze(int curx, int cury) {
    for (int y = 0; y < HEIGHT; y++) {
        for (int x = 0; x < WIDTH; x++) {
        if ((x == curx) && (y == cury))
            std::cout << "@";
        else
            std::cout << layout[y][x];
        }
        std::cout << std::endl;
    }
}

bool Maze::search(int x, int y) {

    bool foundExit = false;

    if (layout[y][x] == 'E') return true;
    visited[y][x] = true;
    if (validMove(x, y-1))
        foundExit = search(x, y-1);
    if (!foundExit && (validMove(x, y+1)))
        foundExit = search(x, y+1);
    if (!foundExit && (validMove(x-1, y)))
        foundExit = search(x-1, y);
    if (!foundExit && (validMove(x+1, y)))
        foundExit = search(x+1, y);
    
    if (foundExit) {
        ps->addSolution(x, y);
        return true;
    }
    return false;
}

bool Maze::solve() {
    return search(startX, startY);
}

void Maze::printHistory() {
    for (int i = ps->getLength() - 1; i >= 0; i--) {
        printMaze(
            ps->getXFromIndex(i),
            ps->getYFromIndex(i)
        );
        std::cout << std::endl;
    }
}