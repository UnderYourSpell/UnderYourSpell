#include "PastSolutions.h"
#include <iostream>

PastSolutions::PastSolutions() {
    xHistory = new std::vector<int>;
    yHistory = new std::vector<int>;
    length = 0;
}

PastSolutions::~PastSolutions() {
    delete xHistory;
    delete yHistory;
}

void PastSolutions::addSolution(int x, int y) {
    xHistory->push_back(x);
    yHistory->push_back(y);
    length++;
}

int PastSolutions::getLength() { return length; }

int PastSolutions::getXFromIndex(int idx) { return xHistory->at(idx); }

int PastSolutions::getYFromIndex(int idx) { return yHistory->at(idx); }