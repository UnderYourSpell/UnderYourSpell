#pragma once
#include <vector>

class PastSolutions {
    private:
        std::vector<int>* xHistory;
        std::vector<int>* yHistory;
        int length;
    public:
        PastSolutions();
        ~PastSolutions();

        void addSolution(int x, int y);

        int getLength();

        int getXFromIndex(int idx);
        int getYFromIndex(int idx);
};