#include "Movie.h"

Movie::Movie(std::string s, MovieRating mr) : _name(s), _rating(mr) {}

Movie::Movie(MovieRating mr) : _name("null"), _rating(mr) {}

Movie::Movie(std::string s) : _name(s), _rating(NULLRATING) {}

Movie::Movie() : _name("null"), _rating(NULLRATING) {}

void Movie::setName(std::string s) { _name = s; }

std::string Movie::getName() { return _name; }

void Movie::setRating(MovieRating mr) { _rating = mr; }

MovieRating Movie::getRating() { return _rating; }

std::string Movie::movieRatingFromEnum(MovieRating mr) {
    std::string ratings[] = {
                            "G",
                            "PG",
                            "PG-13",
                            "R",
                            "NULLRATING"
    };

    return ratings[mr];
}

void Movie::printInfo() {
    std::cout << _name << ", " << movieRatingFromEnum(_rating) << '\n';
}