#include <iostream>
#include <vector>
#include "Movie.h"


// Bubble-sorts backwards
void sortMovies(Movie* vec, int size) {
    for (int i = 0; i < size; ++i) {
        for (int j = i; j < size - 1; ++j) {
            bool inPlace = false;
            int letter = 0;
            do {
                if (vec[j].getName()[letter] > vec[j+1].getName()[letter]) {
                    Movie tmpMovie = vec[j];
                    vec[j] = vec[j+1];
                    vec[j+1] = tmpMovie;
                }
                else {
                    inPlace = true;
                    break;
                }
                ++letter;
            } while (vec[j].getName()[letter] == vec[j+1].getName()[letter]);
            if (inPlace) break;
        }
    }
}

int main() {

    Movie movies[6];
    movies[0] = Movie("Black Panther", PG_13);
    movies[1] = Movie("Avengers: Infinity War", PG_13);
    movies[2] = Movie("A Wrinkle in Time", PG);
    movies[3] = Movie("Ready Player One", PG_13);
    movies[4] = Movie("Red Sparrow", R);
    movies[5] = Movie("The Incredibles 2", G);

    std::cout << "Movies in original order: \n";
    for (Movie movie : movies) {
        movie.printInfo();
    }
    std::cout << '\n';
    sortMovies(movies, 6);

    std::cout << "\nMovies in sorted order: \n";
    for (Movie movie : movies) {
        movie.printInfo();
    }
    std::cout << '\n';

    return 0;
}