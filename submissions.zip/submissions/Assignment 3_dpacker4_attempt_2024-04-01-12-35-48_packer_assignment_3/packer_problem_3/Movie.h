#pragma once
#include <iostream>
#include <string>

enum MovieRating {G, PG, PG_13, R, NULLRATING};

class Movie {

    private:
        std::string _name;
        MovieRating _rating;

        // Used only for printing info
        static std::string movieRatingFromEnum(MovieRating mr);
    
    public:
        Movie(std::string s, MovieRating mr);
        Movie(MovieRating mr);
        Movie(std::string s);
        Movie();

        void setName(std::string s);
        std::string getName();

        void setRating(MovieRating mr);
        MovieRating getRating();

        void printInfo();
};