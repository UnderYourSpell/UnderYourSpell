# Problem 1 - Dawson Packer

For Part (ii) see Line 20 in `main.cpp`.

To compile this program, run

    g++ .\main.cpp .\Pair.cpp -I/