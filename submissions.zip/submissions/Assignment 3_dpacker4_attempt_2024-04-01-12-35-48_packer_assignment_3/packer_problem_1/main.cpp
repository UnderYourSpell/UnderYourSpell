#include <iostream>
#include "Pair.h"

using namespace std;

int main()
{
	Pair p1(5, 10);
	Pair p2(1, 2);

	// Outputs 5 and 10
	p1.print();
	// Outputs 1 and 2
	p2.print();

	Pair p3 = p2 + p1;
	// Outputs 6 and 12
	p3.print();

    /*--[ PROBLEM 1 part ii ]----------------------------------------------------------------------.
    | Executing this line originally doesn't work because the operator is defined by the first     |
    | operand. Putting 2 in front means it uses the integer addition-overloaded operator, which    |
    | doesn't know how to add the custom Pair class to it.										   |
    '---------------------------------------------------------------------------------------------*/
	p3 = 2 + p3;
	// Outputs 8 and 14
	p3.print();

	p3 = p3 + 2;
	// Outputs 10 and 16
	p3.print();

	p3 = p1 + p2;
	// Outputs 6 and 12
	p3.print();
}