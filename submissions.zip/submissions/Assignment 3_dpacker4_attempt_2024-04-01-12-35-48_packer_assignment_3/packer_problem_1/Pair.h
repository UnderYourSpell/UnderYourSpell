#pragma once
#include <iostream>

class Pair
{
private:
	int num1, num2;
public:
	Pair();
	Pair(int num1, int num2);
	int get1();
	int get2();
	friend Pair operator+(Pair& lhs, Pair& rhs);
	friend Pair operator+(int lhs, Pair& rhs);
	friend Pair operator+(Pair& lhs, int rhs);
	void print();
};