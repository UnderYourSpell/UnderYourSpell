#include "Pair.h"

Pair::Pair() : num1(0), num2(0)
{
}

Pair::Pair(int num1, int num2) : num1(num1), num2(num2)
{
}

int Pair::get1()
{
	return num1;
}

int Pair::get2()
{
	return num2;
}

Pair operator+(Pair &lhs, Pair &rhs)
{
    return Pair(lhs.num1 + rhs.num1, lhs.num2 + rhs.num2);
}

Pair operator+(int lhs, Pair &rhs)
{
    return Pair(rhs.num1 + lhs, rhs.num2 + lhs);
}

Pair operator+(Pair &lhs, int rhs)
{
    return Pair(lhs.num1 + rhs, lhs.num2 + rhs);
}

void Pair::print() { std::cout << "Pair: (" << num1 << ", " << num2 << ")\n"; }