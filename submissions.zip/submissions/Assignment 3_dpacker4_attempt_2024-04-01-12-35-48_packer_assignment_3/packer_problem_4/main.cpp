#include <iostream>
#include <fstream>
#include <string>

int main() {

	int histogram[] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
	int curr_num, magnitude, first_num;

    std::ifstream text_file;
    text_file.open("enrollments.txt");
    if (!text_file.is_open()) {
        std::cout << "File failed to open. Aborting...\n";
        return -1;
    }

	std::cout << "Enter 3295 numbers:\n";
	for (int i = 0; i < 3295; ++i) {
        text_file >> curr_num;

		magnitude = 10;
		while (magnitude < curr_num) magnitude *= 10;
		first_num = (curr_num / (magnitude / 10)) % 10;
		if (first_num == 0) first_num = 9;
		histogram[first_num - 1] += 1;
	}

	for (int i = 0; i < sizeof(histogram) / 4; ++i) {
		std::cout << "Number of elements starting with " << i + 1 << ": " << histogram[i] << ", " << 100*histogram[i]/3295.0 << "%" << '\n';
	}
	return 0;
}
