#include <iostream>
#include <string>
#include <stdexcept>

class POSTNET {
    private:
        int code;
        std::string decode_digit(std::string s);

        std::string encode_digit(int i);
    public:
        POSTNET(int code);
        POSTNET(std::string barcode);

        int get_integer_form();

        std::string get_barcode_form();

        int decode(std::string s);

        std::string encode(int i);
};
