#include "POSTNET.h"

POSTNET::POSTNET(int code) : code(code) {}

POSTNET::POSTNET(std::string barcode) : code(decode(barcode)) {}

std::string POSTNET::decode_digit(std::string s) {
            int sum = 0;
            sum += (s[0] - '0') * 7;
            sum += (s[1] - '0') * 4;
            sum += (s[2] - '0') * 2;
            sum += (s[3] - '0') * 1;
            sum += (s[4] - '0') * 0;
            if (sum == 11) sum = 0;
            return std::to_string(sum);
}

std::string POSTNET::encode_digit(int i) {
            if (i == 0) i = 11;
            std::string digit = "";
            int num_ones = 0;
            if (i >= 7) {
                i -= 7;
                digit += '1';
                num_ones++;
            }
            else digit += '0';
            if (i >= 4) {
                i -= 4;
                digit += '1';
                num_ones++;
            }
            else digit += '0';
            if (i >= 2) {
                i -= 2;
                digit += '1';
                num_ones++;
            }
            else digit += '0';
            if (i >= 1) {
                i -= 1;
                digit += '1';
                num_ones++;
            }
            else digit += '0';
            if (num_ones < 2) digit += '1';
            else digit += '0';

            return digit;
}

int POSTNET::get_integer_form() { return code; }

std::string POSTNET::get_barcode_form() { return encode(code); }

int POSTNET::decode(std::string s) {
            if (s.length() < 27) throw std::invalid_argument("Code is too short!");
            std::string first_digit = s.substr(1, 5);
            std::string second_digit = s.substr(6, 5);
            std::string third_digit = s.substr(11, 5);
            std::string fourth_digit = s.substr(16, 5);
            std::string fifth_digit = s.substr(21, 5);
            std::string result = decode_digit(first_digit) + decode_digit(second_digit) +
                decode_digit(third_digit) + decode_digit(fourth_digit) + decode_digit(fifth_digit);

            return (result[4] - '0') * 1 +
                   (result[3] - '0') * 10 +
                   (result[2] - '0') * 100 +
                   (result[1] - '0') * 1000 +
                   (result[0] - '0') * 10000;

}

std::string POSTNET::encode(int i) {
            int first_digit = (i / 10000) % 10;
            int second_digit = (i / 1000) % 10;
            int third_digit = (i / 100) % 10;
            int fourth_digit = (i / 10) % 10;
            int fifth_digit = (i / 1) % 10;
            
            return "1" + encode_digit(first_digit) + encode_digit(second_digit)
                + encode_digit(third_digit) + encode_digit(fourth_digit) + encode_digit(fifth_digit)
                + "1";
}