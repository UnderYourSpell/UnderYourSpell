#include <iostream>
#include "POSTNET.h"

int main(void) {

    POSTNET barcode("110100101000101011000010011");
    std::cout << "--[ Constructor passed with barcode from example ]------------------\n";
    std::cout << "Encoded: " << barcode.get_barcode_form() << '\n';
    std::cout << "Decoded: " << barcode.get_integer_form() << '\n';
    std::cout << std::endl;

    POSTNET integer_code(10560);
    std::cout << "--[ Constructor passed with integer (10560) ]------------------\n";
    std::cout << "Encoded: " << integer_code.get_barcode_form() << '\n';
    std::cout << "Decoded: " << integer_code.get_integer_form() << '\n';

    return 0;
}