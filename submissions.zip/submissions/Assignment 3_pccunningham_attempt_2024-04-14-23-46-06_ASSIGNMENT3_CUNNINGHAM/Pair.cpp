#include "Pair.h"

Pair::Pair() : num1(0), num2(0) {}

Pair::Pair(int num1, int num2) : num1(num1), num2(num2) {}

int Pair::get1() {
    return num1;
}

int Pair::get2() {
    return num2;
}

Pair operator+(int num, const Pair& pair) {
    Pair newPair(pair.num1 + num, pair.num2 + num);
    return newPair;
}

Pair operator+(const Pair& pair, int num) {
    Pair newPair(pair.num1 + num, pair.num2 + num);
    return newPair;
}

Pair operator+(const Pair& pair1, const Pair& pair2) {
    Pair newPair(pair1.num1 + pair2.num1, pair1.num2 + pair2.num2);
    return newPair;
}
