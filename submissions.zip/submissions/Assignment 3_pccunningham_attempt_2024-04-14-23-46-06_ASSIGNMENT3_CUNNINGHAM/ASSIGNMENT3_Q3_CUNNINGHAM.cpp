#include <iostream>
#include <string>
#include <algorithm>

class Movie {
private:
    std::string name;
    std::string rating;

public:
    Movie() {}

    Movie(std::string name, std::string rating) : name(name), rating(rating) {}

    std::string getName() const {
        return name;
    }

    std::string getRating() const {
        return rating;
    }

    void setName(std::string name) {
        this->name = name;
    }

    void setRating(std::string rating) {
        this->rating = rating;
    }
};

void sortMovies(Movie movies[], int size) {
    for (int i = 0; i < size - 1; ++i) {
        for (int j = 0; j < size - i - 1; ++j) {
            if (movies[j].getName() > movies[j + 1].getName()) {
                std::swap(movies[j], movies[j + 1]);
            }
        }
    }
}

int main() {
    Movie movies[] = {
        {"Black Panther", "PG-13"},
        {"Avengers: Infinity War", "PG-13"},
        {"A Wrinkle In Time", "PG"},
        {"Ready Player One", "PG-13"},
        {"Red Sparrow", "R"},
        {"The Incredibles 2", "G"}
    };

    int size = sizeof(movies) / sizeof(movies[0]);

    sortMovies(movies, size);

    std::cout << "Movies sorted by name:" << std::endl;
    for (int i = 0; i < size; ++i) {
        std::cout << movies[i].getName() << ", " << movies[i].getRating() << std::endl;
    }

    return 0;
}
