#include <iostream>
#include <string>

class ZipCode {
private:
    std::string barcode;
    int zipcode;

public:
    // Constructor to initialize ZipCode from integer
    ZipCode(int zip) {
        zipcode = zip;
        barcode = encode(zip);
    }

    // Constructor to initialize ZipCode from barcode string
    ZipCode(std::string barcode) {
        this->barcode = barcode;
        zipcode = decode(barcode);
    }

    // Function to return the zip code as an integer
    int getZipCode() {
        return zipcode;
    }

    // Function to return the zip code in barcode format as a string
    std::string getBarcode() {
        return barcode;
    }

private:
    // Helper function to encode zip code to barcode
    std::string encode(int zip) {
        std::string encoded;
        zip %= 100000; // Ensure zip code is only 5 digits
        int sum = 0;
        for (int i = 0; i < 5; ++i) {
            int digit = zip % 10;
            zip /= 10;
            sum += digit;
            std::string bar;
            for (int j = 0; j < 5; ++j) {
                if (digit & (1 << j)) {
                    bar = '1' + bar;
                }
                else {
                    bar = '0' + bar;
                }
            }
            encoded = bar + encoded;
        }
        if (sum == 11) {
            encoded = '0' + encoded;
        }
        return '1' + encoded + '1'; // Add starting and ending 1s
    }

    // Helper function to decode barcode to zip code
    int decode(std::string barcode) {
        std::string digits = barcode.substr(1, barcode.length() - 2); // Remove starting and ending 1s
        int zip = 0;
        for (int i = 0; i < 25; i += 5) {
            int sum = 0;
            for (int j = 0; j < 5; ++j) {
                sum += (digits[i + j] - '0') * (7 - j);
            }
            if (sum == 11) {
                zip *= 10;
                zip += 0;
            }
            else {
                zip *= 10;
                zip += sum;
            }
        }
        return zip;
    }
};

int main() {
    // Test the ZipCode class
    ZipCode zipcode1(99504);
    std::cout << "Encoded barcode: " << zipcode1.getBarcode() << std::endl;
    std::cout << "Decoded zip code: " << zipcode1.getZipCode() << std::endl;

    ZipCode zipcode2("110100101000101011000010011");
    std::cout << "Decoded zip code: " << zipcode2.getZipCode() << std::endl;

    return 0;
}

