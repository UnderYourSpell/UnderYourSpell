#include <iostream>
#include <fstream>
#include <cmath>
#include <unordered_map>

int leadingDigit(int number) {
    while (number >= 10) {
        number /= 10;
    }
    return number;
}

std::unordered_map<int, double> benfordsLaw(std::ifstream& file) {
    std::unordered_map<int, int> counts;
    int totalCount = 0;

    int number;
    while (file >> number) {
        int digit = leadingDigit(std::abs(number));
        counts[digit]++;
        totalCount++;
    }

    std::unordered_map<int, double> percentages;
    for (const auto& pair : counts) {
        percentages[pair.first] = static_cast<double>(pair.second) / totalCount * 100.0;
    }

    return percentages;
}

int main() {
    std::ifstream file("Enrollments.txt");
    if (!file.is_open()) {
        std::cerr << "Error: Unable to open the file." << std::endl;
        return 1;
    }

    std::unordered_map<int, double> benfordPercentages = benfordsLaw(file);

    std::cout << "Benford's Law Predicted Distribution:" << std::endl;
    for (int i = 1; i <= 9; ++i) {
        std::cout << "Digit " << i << ": " << benfordPercentages[i] << "%" << std::endl;
    }

    return 0;
}

