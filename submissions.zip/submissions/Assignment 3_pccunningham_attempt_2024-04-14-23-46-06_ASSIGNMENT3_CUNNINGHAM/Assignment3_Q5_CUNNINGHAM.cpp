#include <iostream>

using namespace std;

const int HEIGHT = 10;
const int WIDTH = 10;

class Maze {
private:
    char maze[HEIGHT][WIDTH];
    bool visited[HEIGHT][WIDTH];
   
public:

    Maze(); 
    void printMaze();
    bool validMove(int newX, int newY);
    bool move(int newX, int newY);
    bool search(int x, int y, int solutionX[], int solutionY[], int& numEntries); 
    int startX, startY, endX, endY;
};

Maze::Maze() {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            if (i == 0 || i == HEIGHT - 1 || j == 0 || j == WIDTH - 1) {
                maze[i][j] = '#';
            }
            else {
                maze[i][j] = ' ';
            }
            visited[i][j] = false;
        }
    }
    startX = 1;
    startY = 1;
    endX = HEIGHT - 2;
    endY = WIDTH - 2;
    maze[startX][startY] = 'S';
    maze[endX][endY] = 'E';

    srand(time(NULL));
    for (int i = 0; i < HEIGHT * WIDTH / 4; i++) {
        int x = rand() % (HEIGHT - 2) + 1;
        int y = rand() % (WIDTH - 2) + 1;
        if (maze[x][y] == ' ') {
            maze[x][y] = '#';
        }
    }
}


void Maze::printMaze() {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            cout << maze[i][j] << " ";
        }
        cout << endl;
    }
}

bool Maze::validMove(int newX, int newY) {
    if (newX < 0 || newX >= HEIGHT || newY < 0 || newY >= WIDTH) {
        return false;
    }
    if (maze[newX][newY] == '#' || visited[newX][newY]) {
        return false;
    }
    return true;
}

bool Maze::move(int newX, int newY) {
    if (!validMove(newX, newY)) {
        return false;
    }
    visited[newX][newY] = true;
    maze[newX][newY] = '*';
    maze[startX][startY] = ' ';
    startX = newX;
    startY = newY;
    return true;
}

bool Maze::search(int x, int y, int solutionX[], int solutionY[], int& numEntries) {
    if (x == endX && y == endY) {
        solutionX[numEntries] = x;
        solutionY[numEntries] = y;
        numEntries++;
        return true;
    }
    visited[x][y] = true;
    if (validMove(x - 1, y) && search(x - 1, y, solutionX, solutionY, numEntries)) {
        solutionX[numEntries] = x;
        solutionY[numEntries] = y;
        numEntries++;
        return true;
    }
    if (validMove(x, y + 1) && search(x, y + 1, solutionX, solutionY, numEntries)) {
        solutionX[numEntries] = x;
        solutionY[numEntries] = y;
        numEntries++;
        return true;
    }
    if (validMove(x + 1, y) && search(x + 1, y, solutionX, solutionY, numEntries)) {
        solutionX[numEntries] = x;
        solutionY[numEntries] = y;
        numEntries++;
        return true;
    }
    if (validMove(x, y - 1) && search(x, y - 1, solutionX, solutionY, numEntries)) {
        solutionX[numEntries] = x;
        solutionY[numEntries] = y;
        numEntries++;
        return true;
    }
    visited[x][y] = false;
    return false;
}

int main() {
    Maze maze;
    int solutionX[100], solutionY[100], numEntries = 0;
    maze.printMaze();

    if (maze.search(maze.startX, maze.startY, solutionX, solutionY, numEntries)) {
        cout << "Solution found: ";
        for (int i = numEntries - 1; i >= 0; i--) {
            cout << "(" << solutionX[i] << "," << solutionY[i] << ") ";
        }
        cout << endl;
    }
    else {
        cout << "No solution found." << endl;
    }

    return 0;
}
