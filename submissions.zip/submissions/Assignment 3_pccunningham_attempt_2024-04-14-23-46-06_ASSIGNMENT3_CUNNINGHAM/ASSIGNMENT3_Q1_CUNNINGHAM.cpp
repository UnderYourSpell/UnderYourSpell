#include <iostream>
#include "Pair.h"

using namespace std;

int main() {
    Pair p1(5, 10);
    Pair p2(1, 2);

    cout << p1.get1() << " " << p1.get2() << endl;
    cout << p2.get1() << " " << p2.get2() << endl;

    Pair p3 = p2 + p1;
    cout << p3.get1() << " " << p3.get2() << endl;

    // Change this line to test
    p3 = p3 + 2;
    cout << p3.get1() << " " << p3.get2() << endl;
}

/* In the expression p3 = 2 + p3;, 2 is an integer literal, not an object of type Pair.
In C++, when you define the operator+ member function, the compiler doesn't know how to handle a situation where the left operand is not of type Pair. 
In order to perform this operation, you need to define a non-member operator+ function (friend function) that takes an integer as the left operand and a Pair object as the right operand. */