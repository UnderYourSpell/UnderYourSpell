#pragma once

class Pair {
private:
    int num1, num2;

public:
    Pair();
    Pair(int num1, int num2);
    int get1();
    int get2();
    friend Pair operator+(int num, const Pair& pair);
    friend Pair operator+(const Pair& pair, int num);
    friend Pair operator+(const Pair& pair1, const Pair& pair2);
};
