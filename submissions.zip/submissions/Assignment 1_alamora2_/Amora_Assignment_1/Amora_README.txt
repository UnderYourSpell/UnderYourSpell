Problem 1: 
		In order to run this program on a unix system, compile it
		using the g++ command. Then use I/O redirection to use the
		enrollments.txt file as an input for the program. --> "./a.out < enrollments.txt"

Program 2: 	
		No special instructions. Just use "./a.out" on a unix system.

Program 3: 

		No code to run lol. Please read txt file.

Program 4: 

		No special instructions. Just use "./a.out" on a unix system.