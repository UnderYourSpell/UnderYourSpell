#include <iostream>

using namespace std;

void calcChange(int amount, int &quarters, int &dimes, int &nickels, int &pennies)
{
    quarters = amount / 25;
    amount %= 25;
    dimes = amount / 10;
    amount %= 10;
    nickels = amount / 5;
    amount %= 5;
    pennies = amount;
}

int main()
{
    int amount, quarters, dimes, nickels, pennies;

    // Test 1
    amount = 73;
    calcChange(amount, quarters, dimes, nickels, pennies);

    cout << "To make " << amount << " cents, you need: " << endl;
    cout << "Quarters: " << quarters << endl;
    cout << "Dimes: " << dimes << endl;
    cout << "Nickels: " << nickels << endl;
    cout << "Pennies: " << pennies << endl << endl;

    // Test 2

    amount = 39;
    calcChange(amount, quarters, dimes, nickels, pennies);

    cout << "To make " << amount << " cents, you need: " << endl;
    cout << "Quarters: " << quarters << endl;
    cout << "Dimes: " << dimes << endl;
    cout << "Nickels: " << nickels << endl;
    cout << "Pennies: " << pennies << endl;

    return 0;
}




