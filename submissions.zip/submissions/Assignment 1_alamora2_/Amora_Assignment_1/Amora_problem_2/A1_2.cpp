#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int calcMoneyWon(int matches, int wager)
{
    if (matches == 0)
        return -wager; // lose wager
    else if (matches == 1)
        return 0; // win none lose none
    else if (matches == 2)
        return wager * 2; // win twice the wager
    else
        return wager * 3; // win thrice the wager
}

int main()
{
    srand(time(0));
    
    int money = 100;
    int wager;
    int selectedNum;
    char playAgain;

    cout << "You are now playing Chuck-a-luck. Here's $100 to start." << endl;

    do {
        cout << "Enter your wager (0 to quit): $";
        cin >> wager;

        if (wager == 0)
        {
            cout << "Thank you for playing Chuck-a-luck! You have $" << money << endl;
            break;
        }

        do {
            
            if (wager > money)
            {
                cout << "You don't have enough money! Enter another wager: $";
                cin >> wager;
            }
            
        } while (wager > money); // make sure that wager is under current amount of money
        
        cout << "Choose a number from 1 to 6: ";
        cin >> selectedNum;
        
        do {
            
            if (selectedNum < 1 || selectedNum > 6)
            {
                cout << "Invalid number. Please choose a number from 1 to 6: ";
                cin >> selectedNum;
            }
            
        } while (selectedNum < 1 || selectedNum > 6); // make sure that the number picked is valid
        
        int roll1 = rand() % 6 + 1;
        int roll2 = rand() % 6 + 1;
        int roll3 = rand() % 6 + 1;

        cout << "Dice roll results: " << roll1 << ", " << roll2 << ", " << roll3 << endl;

        int matches = (selectedNum == roll1) + (selectedNum == roll2) + (selectedNum == roll3);
        int moneyWon = calcMoneyWon(matches, wager);

        if (moneyWon >= 0)
            cout << "Congrats! You win $" << moneyWon << endl;
        else
            cout << "Sorry, you lose $" << -moneyWon << endl;

        money += moneyWon;
        cout << "Current balance: $" << money << endl;

        if (money == 0)
        {
            cout << "You are out of money lol. Game over!" << endl;
            break;
        }

        cout << "Do you want to play again? (Y/N): ";
        cin >> playAgain;

    } while (playAgain == 'Y' || playAgain == 'y');

    return 0;
}

