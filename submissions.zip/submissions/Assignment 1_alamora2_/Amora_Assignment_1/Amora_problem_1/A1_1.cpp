#include <iostream>

using namespace std;

int main()
{
	
	int digit_count[9] = {0};

	for (int i = 0; i < 3295; i++)
	{
		int num;
		cin >> num;
		
		int first_digit = num;
        
		while (first_digit >= 10)
		{
			first_digit /= 10;
		}

		if (first_digit >= 1 && first_digit <= 9)
		{
			digit_count[first_digit - 1]++;
		}

	}

	for (int i = 0; i < 9; i++)
	{
		cout << "Number of Enrollments starting with " << (i + 1) << ": " << digit_count[i] << endl;
	}

	return 0;

}
