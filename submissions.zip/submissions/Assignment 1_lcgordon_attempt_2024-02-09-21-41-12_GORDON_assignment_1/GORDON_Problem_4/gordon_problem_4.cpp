#include <iostream>
using namespace std;

void makeChange(int change, int &quarters, int &dimes, int &nickels, int &pennies);

int main()
{
    int change, quarters, dimes, nickels, pennies;

    makeChange(66, quarters, dimes, nickels, pennies);
    cout << "Your change is: " << endl;
    cout << "Quarters: " << quarters << endl;
    cout << "Dimes: " << dimes << endl;
    cout << "Nickels: " << nickels << endl;
    cout << "Pennies: " << pennies << endl;

    makeChange(99, quarters, dimes, nickels, pennies);
    cout << "Your change is: " << endl;
    cout << "Quarters: " << quarters << endl;
    cout << "Dimes: " << dimes << endl;
    cout << "Nickels: " << nickels << endl;
    cout << "Pennies: " << pennies << endl;
    
}

void makeChange(int change, int &quarters, int &dimes, int &nickels, int &pennies) {
    quarters = change / 25;
    change = change%25;
    dimes = change / 10;
    change = change%10;
    nickels = change / 5;
    change = change%5;
    pennies = change;

    return;
}