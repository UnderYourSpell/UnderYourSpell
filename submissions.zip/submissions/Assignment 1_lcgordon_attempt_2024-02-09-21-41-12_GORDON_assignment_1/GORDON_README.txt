1) Run this program a Unix system using the commands:
g++ Gordon_Problem_1.cpp
sort -d < enrollments.txt | ./a.out


2) Run this program in a Unix system by using the commands:
g++ Gordon_Problem_2.cpp
./a.out