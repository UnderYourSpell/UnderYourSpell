// Chuck-a-luck game
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

// Return a random number from 1 to 6
int rollDice() {
    return (rand()%6) + 1;
}

// Roll dice 3 times and compare to the user's chosen number
// Returns the number of times the user wins in the round
int winOrLose(int n) {
    int wins = 0;
    int roll;
    srand(time(NULL));
    for (int i=0; i < 3; i++) {
        roll = rollDice();
        cout << "Rolling the dice... It's a " << roll << endl;
	    if (roll == n) {
		    wins++;
            cout << "You won!" << endl;
        }
        else {
            cout << "You lost." << endl;
        }
    }

    return wins;
}


int main()
{
    int wager, n, money = 100, wins;
    char yesOrNo = 'y';

    cout << "Let's play Chuck-A-Luck. You have $" << money << endl;

    // Allows user to play chuck-a-luck until they choose to stop or run out of money
    while (money > 0 && yesOrNo == 'y') {
        cout << "Enter a wager." << endl;
        cin >> wager;
        if (wager > money) {
            cout << "You don't have that much money. Enter a new wager." << endl;
            cin >> wager;
        }

        money -= wager;
        
        cout << "Pick a number from 1 to 6." << endl;
        cin >> n;
        if (n < 1 || n > 6) {
            cout << "Not a valid number. Pick a number from 1 to 6." << endl;
            cin >> n;
        }

        wins = winOrLose(n);
        if (wins == 1) {
            money += wager;
        }
        else if (wins == 2) {
            money = money + wager * 2;
        }
        else if (wins == 3) {
            money = money + wager * 3;
        }

        if (money <= 0) {
        cout << "You're out of money. You lose!" << endl;
        }
        else {
            cout << "Your total money is now $" << money << "." << endl;
            cout << "Do you want to keep playing? Enter 'y' for yes, enter 'n' for no." << endl;
            cin >> yesOrNo;
            if (yesOrNo == 'n') {
                cout << "Good game! Bye." << endl;
            }
        }

    }

    return 0;
}