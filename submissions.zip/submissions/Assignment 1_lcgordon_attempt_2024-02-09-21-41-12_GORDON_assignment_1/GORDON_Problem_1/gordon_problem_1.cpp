// This program will take 3295 enrollment numbers and count the frequency of each leading digit
#include <iostream>
#include <cstring>
using namespace std;

int main()
{
    string enrollment;
    int leadingDigit;
    int leadingDigitFrequency[9] = {0};
    int leadingDigitCounter = 0;

    // Take 3295 numbers as inputs
    for (int i = 0; i < 3295; i++) {
        // Place each number in the enrollment string
        cin >> enrollment;
        // Find the leading digit
        leadingDigit = enrollment[0] - 48;
        // For each number, checks what the leading number is
        for (int j = 0; j < 9; j++) {
            // Increases that leading digit's frequency by one
            if (leadingDigit == (j + 1)) {
                leadingDigitFrequency[j] += 1;
            }
        }
    }

    // Output leading digit frequencies as percentages
    cout << "Leading Digit Frequencies:" << endl;
    for (int j = 0; j < 9; j++) {
        cout << j + 1 << ": " << leadingDigitFrequency[j] * 100 / 3295 << "%" << endl;
    }

    return 0;
}