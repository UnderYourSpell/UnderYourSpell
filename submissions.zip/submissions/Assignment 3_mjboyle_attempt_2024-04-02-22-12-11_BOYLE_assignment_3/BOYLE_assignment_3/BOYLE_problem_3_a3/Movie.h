#pragma once
#include <string>
#include <iostream>

using namespace std;

class Movie
{
private:
	string name;
	string rating;

public:
	Movie();
	Movie(string n, string r);
	string getName();
	string getRating();
	void setName(string n);
	void setRating(string r);
	void print();

};

