#include <iostream>

#include "Movie.h"

using namespace std;


void swap(Movie &x, Movie &y);
void selectionSort(Movie a[], int startIndex, int endIndex);



void selectionSort(Movie a[], int startIndex, int endIndex)
{

	if (startIndex == endIndex)
		return;

	int indexOfMin = startIndex;


	for (int i = startIndex + 1; i <= endIndex; i++) {
		string temp1 = a[i].getName();
		string temp2 = a[indexOfMin].getName();
		int tempcount = 0;
		while (temp1[tempcount] == temp2[tempcount]) {
			tempcount += 1;
		}


		if (temp1[tempcount] < temp2[tempcount]) {
			indexOfMin = i;
		}
	}




	swap(a[indexOfMin], a[startIndex]);


	for (int i = 0; i < 6; i++) {
		a[i].print();
	}
}




void swap(Movie &x, Movie &y) {
	Movie temp = x;
	x = y;
	y = temp;
}



int main()
{
	Movie arr[6];
	Movie black_panther("Black Panther", "PG-13");
	Movie avengers("Avengers: Infinity War", "PG-13");
	Movie a_wrinkle_in_time("A Wrinkle In Time", "PG");
	Movie ready_player_one("Ready Player One", "PG-13");
	Movie red_sparrow("Red Sparrow", "R");
	Movie the_incredibles_2("The Incredibles 2", "G");


	arr[0] = black_panther;
	arr[1] = avengers;
	arr[2] = a_wrinkle_in_time;
	arr[3] = ready_player_one;
	arr[4] = red_sparrow;
	arr[5] = the_incredibles_2;

	selectionSort(arr, 0, 5);


}

