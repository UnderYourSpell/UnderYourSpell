#include "Movie.h"

Movie::Movie()
{
	name = "";
	rating = "";
}

Movie::Movie(string n, string r)
{
	name = n;
	rating = r;
}

string Movie::getName()
{
	return name;
}

string Movie::getRating()
{
	return rating;
}

void Movie::setName(string n)
{
	name = n;
}

void Movie::setRating(string r)
{
	rating = r;
}

void Movie::print()
{
	cout << name << ", Rated " << rating << endl;
}
