1 Run program Assignment 3 Problem 1.cpp with an IDE. Developed in visual studios. The class methods expect an object of that class as a parameter, the method need to be overloaded as a friend/made global in order to take two parameters with a non object parameter first.

2 Run program Assignment 3 Question 2.cpp with an IDE. Developed in visual studios. Everything works correctly other than that it prints out a bunch of nonsense after the bar code if it was constructed with an int.

3 Run program Assignment 3 Problem 3.cpp with an IDE. Developed in visual studios. Everything works as intended.

4 Run program Assignment 3 Problem 4.cpp with an IDE. Developed in visual studios. Everything runs as intended.


5 Run program Assignment 3 Problem 5.cpp with an IDE. Developed in visual studios. Everything runs as intended. Prints a start maze and prints when it finds the exit.
