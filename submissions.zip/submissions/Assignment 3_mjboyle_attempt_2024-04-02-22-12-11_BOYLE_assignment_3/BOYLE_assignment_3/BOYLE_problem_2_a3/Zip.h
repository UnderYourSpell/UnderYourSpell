#pragma once
#include <string>
#include <iostream>

using namespace std;

class Zip
{
private:
	string num;


public:
	Zip(int z);
	Zip(string z);
	int getZipCode();
	string getBarCode();
};

