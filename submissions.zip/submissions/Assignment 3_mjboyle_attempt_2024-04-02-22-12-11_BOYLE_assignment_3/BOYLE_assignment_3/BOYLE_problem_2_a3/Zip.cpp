#include "Zip.h"

Zip::Zip(int z) {
	char numString[28];
	numString[0] = '1';
	int temp;
	temp = z / 10000;

	if (temp == 0) {
		numString[1] = '1';
		numString[2] = '1';
		numString[3] = '0';
		numString[4] = '0';
	}
	else {
		if (temp >= 7) {
			numString[1] = '1';
			temp -= 7;
		}
		else {
			numString[1] = '0';
		}
		if (temp >= 4) {
			numString[2] = '1';
			temp -= 4;
		}
		else {
			numString[2] = '0';
		}
		if (temp >= 2) {
			numString[3] = '1';
			temp -= 2;
		}
		else {
			numString[3] = '0';
		}
		if (temp >= 1) {
			numString[4] = '1';
			temp -= 1;
		}
		else {
			numString[4] = '0';
		}
	}
	numString[5] = '0';

	temp = (z%10000) / 1000;
	if (temp == 0) {
		numString[6] = '1';
		numString[7] = '1';
		numString[8] = '0';
		numString[9] = '0';
	}
	else {
		if (temp >= 7) {
			numString[6] = '1';
			temp -= 7;
		}
		else {
			numString[6] = '0';
		}
		if (temp >= 4) {
			numString[7] = '1';
			temp -= 4;
		}
		else {
			numString[7] = '0';
		}
		if (temp >= 2) {
			numString[8] = '1';
			temp -= 2;
		}
		else {
			numString[8] = '0';
		}
		if (temp >= 1) {
			numString[9] = '1';
			temp -= 1;
		}
		else {
			numString[9] = '0';
		}
	}
	numString[10] = '0';


	temp = (z%1000) / 100;
	if (temp == 0) {
		numString[11] = '1';
		numString[12] = '1';
		numString[13] = '0';
		numString[14] = '0';
	}
	else {

		if (temp >= 7) {
			numString[11] = '1';
			temp -= 7;
		}
		else {
			numString[11] = '0';
		}
		if (temp >= 4) {
			numString[12] = '1';
			temp -= 4;
		}
		else {
			numString[12] = '0';
		}
		if (temp >= 2) {
			numString[13] = '1';
			temp -= 2;
		}
		else {
			numString[13] = '0';
		}
		if (temp >= 1) {
			numString[14] = '1';
			temp -= 1;
		}
		else {
			numString[14] = '0';
		}
	}
	numString[15] = '0';


	temp = (z % 100) / 10;

	if (temp == 0) {
		numString[16] = '1';
		numString[17] = '1';
		numString[18] = '0';
		numString[19] = '0';
	}
	else {
		if (temp >= 7) {
			numString[16] = '1';
			temp -= 7;
		}
		else {
			numString[16] = '0';
		}
		if (temp >= 4) {
			numString[17] = '1';
			temp -= 4;
		}
		else {
			numString[17] = '0';
		}
		if (temp >= 2) {
			numString[18] = '1';
			temp -= 2;
		}
		else {
			numString[18] = '0';
		}
		if (temp >= 1) {
			numString[19] = '1';
			temp -= 1;
		}
		else {
			numString[19] = '0';
		}
	}
	numString[20] = '0';


	temp = z % 10;

	if (temp == 0) {
		numString[21] = '1';
		numString[22] = '1';
		numString[23] = '0';
		numString[24] = '0';
	}
	else {
		if (temp >= 7) {
			numString[21] = '1';
			temp -= 7;
		}
		else {
			numString[21] = '0';
		}
		if (temp >= 4) {
			numString[22] = '1';
			temp -= 4;
		}
		else {
			numString[22] = '0';
		}
		if (temp >= 2) {
			numString[23] = '1';
			temp -= 2;
		}
		else {
			numString[23] = '0';
		}
		if (temp >= 1) {
			numString[24] = '1';
			temp -= 1;
		}
		else {
			numString[24] = '0';
		}
	}
	numString[25] = '1';
	numString[26] = '1';

	num = numString;

}

Zip::Zip(string z) : num(z) {}

int Zip::getZipCode()
{
	int first = 0;
	int second = 0;
	int third = 0;
	int fourth = 0;
	int fifth = 0;

	if (num[1] == '1')
		first += 7;
	if (num[2] == '1')
		first += 4;
	if (num[3] == '1')
		first += 2;
	if (num[4] == '1')
		first += 1;
	if (first == 11)
		first = 0;

	if (num
		[6] == '1')
		second += 7;
	if (num[7] == '1')
		second += 4;
	if (num[8] == '1')
		second += 2;
	if (num[9] == '1')
		second += 1;
	if (second == 11)
		second = 0;

	if (num[11] == '1')
		third += 7;
	if (num[12] == '1')
		third += 4;
	if (num[13] == '1')
		third += 2;
	if (num[14] == '1')
		third += 1;
	if (third == 11)
		third = 0;

	if (num[16] == '1')
		fourth += 7;
	if (num[17] == '1')
		fourth += 4;
	if (num[18] == '1')
		fourth += 2;
	if (num[19] == '1')
		fourth += 1;
	if (fourth == 11)
		fourth = 0;


	if (num[21] == '1')
		fifth += 7;
	if (num[22] == '1')
		fifth += 4;
	if (num[23] == '1')
		fifth += 2;
	if (num[24] == '1')
		fifth += 1;
	
	int total = first * 10000 + second * 1000 + third * 100 + fourth * 10 + fifth;

	return total;

}

string Zip::getBarCode()
{
	return num;
}
;


