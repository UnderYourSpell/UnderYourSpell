#include <iostream>
#include <string>
#include "Zip.h"

using namespace std;

int main()
{
	int intZip = 99504;
	string stringZip = "110100101000101011000010011";

	Zip intz(intZip);
	cout << intz.getBarCode() << endl;
	cout << intz.getZipCode() << endl;

	Zip stringz(stringZip);
	cout << stringz.getBarCode() << endl;
	cout << stringz.getZipCode();

}