#pragma once
#include <iostream>

using namespace std;
class Maze
{
private:
	Maze();

	char maze_array[20][20];
	bool visited_array[20][20];
	bool validMove(char maze[][20], bool visited[][20], int newX, int newY);

	int x;
	int y;
	int count;
	int reversex[100];
	int reversey[100];


public:
	Maze(char arr[][20], bool visited[][20], int x1, int y1, int& count1, int reversex1[], int reversey1[]);
	bool search(char maze[][20], bool visited[][20], int x, int y, int& count, int reversex[], int reversey[]);
	//void drawMaze(char maze[][20]);
	//void drawVisited(bool visited[][20]);
	void printMaze(char maze[][20], int curx, int cury);
};

