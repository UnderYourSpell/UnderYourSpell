#include "Maze.h"




bool Maze::search(char maze[][20], bool visited[][20], int x, int y, int &count, int reversex[], int reversey[])
{
	if (maze[y][x] == 'E')
		printMaze(maze, x, y);

	bool foundExit = false;
	visited[y][x] = true;
	if (validMove(maze, visited, x, y - 1))
		foundExit = search(maze, visited, x, y - 1, count, reversex, reversey);
	if (!foundExit && (validMove(maze, visited, x, y + 1)))
		foundExit = search(maze, visited, x, y + 1, count, reversex, reversey);
	if (!foundExit && (validMove(maze, visited, x - 1, y)))
		foundExit = search(maze, visited, x - 1, y, count, reversex, reversey);
	if (!foundExit && (validMove(maze, visited, x + 1, y)))
		foundExit = search(maze, visited, x + 1, y, count, reversex, reversey);

	if (foundExit)
	{
		reversex[count] = x;
		reversey[count] = y;
		count++;
		printMaze(maze, x, y);
		cout << endl;
		return true;
	}
	return false;
}

void Maze::printMaze(char maze[][20], int curx, int cury)
{
	for (int y = 0; y < 20; y++)
	{
		for (int x = 0; x < 20; x++)
		{
			if ((x == curx) && (y == cury))
				cout << "@";
			else
				cout << maze[y][x];
		}
		cout << endl;
	}
}



Maze::Maze(char arr[][20], bool visited[][20], int x1, int y1, int & count1, int reversex1[], int reversey1[])
{
	for (int i = 0; i < 20; i++) {
		for (int k = 0; i < 20; i++) {
			maze_array[i][k] = arr[i][k];
		}
	}
	for (int i = 0; i < 20; i++) {
		for (int k = 0; i < 20; i++) {
			visited_array[i][k] = visited[i][k];
		}
	}
	for (int i = 0; i < 100; i++) {
		reversex[i] = reversex1[i];
	}

	for (int i = 0; i < 100; i++) {
		reversey[i] = reversey1[i];
	}
	x = x1;
	y = y1;
	count = count1;
	//reversex = reversex1;
	//reversey = reversey1;

}

/*bool Maze::search(char maze[][20], bool visited[][20], int x, int y, int& count, int reversex[], int reversey[])
{
	if (maze[y][x] == 'E')
		return true;

	bool foundExit = false;
	visited[y][x] = true;
	if (validMove(maze, visited, x, y - 1))
		foundExit = search(maze, visited, x, y - 1, count, reversex, reversey);
	if (!foundExit && (validMove(maze, visited, x, y + 1)))
		foundExit = search(maze, visited, x, y + 1, count, reversex, reversey);
	if (!foundExit && (validMove(maze, visited, x - 1, y)))
		foundExit = search(maze, visited, x - 1, y, count, reversex, reversey);
	if (!foundExit && (validMove(maze, visited, x + 1, y)))
		foundExit = search(maze, visited, x + 1, y, count, reversex, reversey);

	if (foundExit)
	{
		reversex[count] = x;
		reversey[count] = y;
		count++;
		printMaze(maze, x, y);
		cout << endl;
		return true;
	}
	return false;
}*/


bool Maze::validMove(char maze[][20], bool visited[][20], int newX, int newY)
{

		// Check for going off the maze edges
		if (newX < 0 || newX >= 20)
			return false;
		if (newY < 0 || newY >= 20)
			return false;
		// Check if target is a wall
		if (maze[newY][newX] == 'X')
			return false;
		// Check if visited
		if (visited[newY][newX])
			return false;
		return true;
	
}
