// Assignment 3 Problem 5.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <ctime>
#include <cstdlib>
#include "Maze.h"

using namespace std;

const int WIDTH = 20;
const int HEIGHT = 20;


int main()
{
	char maze[20][20] = {
		   {'X','X','X','X','X','X','X','X','X','X','X','X','X','X','X','X','X','X','X','X'},
		   {'X',' ',' ',' ',' ','X',' ',' ',' ',' ',' ',' ',' ',' ',' ','X',' ','X',' ','X'},
		   {'X',' ','X','X',' ','X',' ','X','X','X','X','X','X','X',' ','X',' ','X',' ','X'},
		   {'X',' ','X',' ',' ',' ',' ','X',' ',' ',' ','X',' ','X',' ',' ',' ','X',' ','X'},
		   {'X',' ','X',' ','X','X','X','X',' ','X','X','X',' ','X','X','X','X','X',' ','X'},
		   {'X',' ','X',' ',' ',' ',' ','X',' ','X',' ','X',' ',' ',' ','X',' ','X',' ','X'},
		   {'X','X','X','X','X','X',' ','X',' ','X','X','X',' ',' ',' ','X',' ','X',' ','X'},
		   {'X',' ',' ',' ',' ','X',' ','X',' ',' ',' ','X',' ','X','X','X',' ','X',' ','X'},
		   {'X','X','X','X',' ','X',' ',' ','X','X',' ','X',' ',' ',' ',' ',' ','X',' ','X'},
		   {'X',' ',' ','X',' ','X','X',' ',' ',' ',' ','X',' ',' ',' ','X',' ','X',' ','X'},
		   {'X',' ',' ','X',' ','X','X',' ','X','X','X','X','X','X',' ','X',' ',' ',' ','X'},
		   {'X','X',' ','X',' ','X',' ',' ','X',' ',' ',' ',' ',' ',' ','X','X','X','X','X'},
		   {'X',' ',' ','X',' ','X',' ','X','X',' ','X','X','X','X','X','X','X',' ',' ','X'},
		   {'X',' ',' ',' ',' ','X',' ',' ','X',' ',' ',' ',' ',' ',' ',' ','X',' ',' ','X'},
		   {'X',' ','X','X','X','X','X',' ','X',' ',' ','X',' ','X',' ',' ','X','X',' ','X'},
		   {'X',' ',' ',' ',' ',' ','X',' ','X',' ',' ','X',' ','X',' ',' ','X','X',' ','X'},
		   {'X',' ','X',' ','X',' ','X',' ','X',' ',' ','X',' ','X',' ',' ',' ',' ',' ','X'},
		   {'X',' ','X',' ','X','X','X',' ','X','X','X','X',' ','X','X','X','X','X','X','X'},
		   {'X',' ','X',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','X'},
		   {'X','X','X','X','X','X','X','X','X','X','X','X','X','X','X','X','X','X','X','X'}
	};
	bool visited[20][20];
	int reversex[100] = { 0 };
	int reversey[100] = { 0 };
	int count = 0;

	int x = 1, y = 1, a = 1, b = 1;
	bool foundExit = false;
	bool start = false;
	bool exit = false;
	srand(time(NULL));

	while (start == false) {
		x = rand() % 20;
		y = rand() % 20;
		if (maze[x][y] == ' ') {
			start = true;
		}
		else {
			start = false;
		}
	}

	while (exit == false) {
		a = rand() % 20;
		b = rand() % 20;
		if (maze[a][b] == ' ') {
			maze[a][b] = 'E';
			exit = true;
		}
		else {
			exit = false;
		}
	}

	// Initialize visited locations to false
	for (int x = 0; x < 20; x++)
		for (int y = 0; y < 20; y++)
			visited[y][x] = false;
	visited[y][x] = true;

	Maze my_maze(maze, visited, x, y, count, reversex, reversey);


	my_maze.printMaze(maze, x, y);
	my_maze.search(maze, visited, x, y, count, reversex, reversey);

}