# Problem 1 - Dawson Packer

To compile the program and test it in a bash shell, run

	g++ packer_problem_1.cpp
	./a.out < enrollments.txt

or in Powershell,

	g++ packer_problem_1.cpp
	Get-Content .\enrollments.txt | .\a.exe