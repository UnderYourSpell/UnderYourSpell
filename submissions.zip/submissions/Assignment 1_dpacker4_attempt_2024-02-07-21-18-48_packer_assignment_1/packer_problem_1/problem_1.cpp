#include <iostream>

int main() {

	int histogram[] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
	int curr_num, magnitude, first_num;

	std::cout << "Enter 3295 numbers:\n";
	for (int i = 0; i < 3295; ++i) {
		std::cin >> curr_num;
		magnitude = 10;
		while (magnitude < curr_num) magnitude *= 10;
		first_num = (curr_num / (magnitude / 10)) % 10;
		if (first_num == 0) first_num = 9;
		histogram[first_num - 1] += 1;
	}

	for (int i = 0; i < sizeof(histogram) / 4; ++i) {
		std::cout << "Number of elements starting with " << i + 1 << ": " << histogram[i] << '\n';
	}
	return 0;
}
