# Problem 2 - Dawson Packer

To compile the program and test it in a bash shell, run

	g++ packer_problem_2.cpp
	./a.out

or in Powershell,

	g++ packer_problem_2.cpp
	./a.exe

## Issues

- In the prompt to roll the dice, entering a value 3 characters or longer runs the input handling
	code more than once.