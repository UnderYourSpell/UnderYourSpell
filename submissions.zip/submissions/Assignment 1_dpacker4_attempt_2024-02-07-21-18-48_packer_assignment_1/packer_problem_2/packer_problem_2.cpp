#include <iostream>
#include <ctime>


int chuck_a_luck_rolls(int side_chosen) {
    int rolls[3] = {0};
    rolls[0] = rand() % 6 + 1;
    rolls[1] = rand() % 6 + 1;
    rolls[2] = rand() % 6 + 1;
    std::cout << "Rolls: " << rolls[0] << ", " << rolls[1] << ", " << rolls[2] << '\n';
    int win_count = 0;
    for (int roll : rolls) {
        if (roll == side_chosen) win_count++;
    }
    return win_count;
}

void play(int &bank) {
    int wager, side_chosen;
    std::cout << "You have $" << bank << ", enter a wager: ";
    std::cin >> wager;
    std::cin.clear();
    std::cin.ignore();
    while (wager > bank) {
        std::cout << "You don't have enough money!\nEnter a valid wager: ";
        std::cin >> wager;
        std::cin.clear();
        std::cin.ignore();
    }
    std::cout << "Enter a side number: ";
    std::cin >> side_chosen;
    std::cin.clear();
    std::cin.ignore();
    while (side_chosen < 1 || side_chosen > 6) {
        std::cout << "That's not a side!\nEnter a valid number: ";
        std::cin >> side_chosen;
        std::cin.clear();
        std::cin.ignore();
    }
    std::cout << "Ready to roll? [Y/n]: ";
    char input;
    std::cin >> input;
    std::cin.clear();
    std::cin.ignore();
    while (input != 'Y' && input != 'y') {
        std::cout << "Ready to roll? [Y/n]: ";
        std::cin >> input;
        std::cin.clear();
        std::cin.ignore();
    }
    int win_count = chuck_a_luck_rolls(side_chosen);
    if (win_count == 0) {
        std::cout << "I'm sorry, none of the rolls landed on " << side_chosen << ".\n";
        bank -= wager;
    }
    else if (win_count == 2) {
        std::cout << "Two rolls landed on " << side_chosen << "!\n";
        bank += wager;
    }
    else if (win_count == 3) {
        std::cout << "Three rolls landed on " << side_chosen << "!!\n";
        bank += 2 * wager;
    }
    else { std::cout << "You broke even!\n"; }
}

int main() {
    srand(time(NULL));
    std::cout << "Welcome to Chuck-a-luck!\n";
    int bank = 100;
    while (bank > 0) {
        play(bank);
    }
    std::cout << "You ran out of money! Thanks for playing!" << std::endl;
    std::cout << "Press ENTER to exit...\n";
    std::cin.get();
    return 0;
}