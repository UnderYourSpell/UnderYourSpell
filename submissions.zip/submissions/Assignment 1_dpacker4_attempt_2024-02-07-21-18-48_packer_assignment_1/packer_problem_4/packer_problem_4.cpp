#include <iostream>

void dispense_change(
    int amount,
    int &quarters,
    int &dimes,
    int &nickels,
    int &pennies
) {
    quarters = (amount - (amount % 25)) / 25;
    amount = amount % 25;
    dimes = (amount - (amount % 10)) / 10;
    amount = amount % 10;
    nickels = (amount - (amount % 5)) / 5;
    amount = amount % 5;
    pennies = amount;
}

void test_cases(int test_1, int test_2) {
    int num_quarters, num_dimes, num_nickels, num_pennies;

    std::cout << "Testing case for " << test_1 << " cents\n";

    dispense_change(test_1, num_quarters, num_dimes, num_nickels, num_pennies);

    std::cout << "Your change:\n";
    std::cout << num_quarters << " quarters\n";
    std::cout << num_dimes << " dimes\n";
    std::cout << num_nickels << " nickels\n";
    std::cout << num_pennies << " pennies\n";

    std::cout << "Testing case for " << test_2 << " cents\n";

    dispense_change(test_2, num_quarters, num_dimes, num_nickels, num_pennies);

    std::cout << "Your change:\n";
    std::cout << num_quarters << " quarters\n";
    std::cout << num_dimes << " dimes\n";
    std::cout << num_nickels << " nickels\n";
    std::cout << num_pennies << " pennies\n";
}

int main() {

    // Testing for 55 and 88 cents
    test_cases(55, 88);

    std::cout << "Press ENTER to exit...\n";
    std::cin.get();
    return 0;
}