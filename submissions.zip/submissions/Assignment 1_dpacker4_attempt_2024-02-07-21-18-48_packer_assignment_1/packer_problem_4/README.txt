# Problem 4 - Dawson Packer

To compile the program and test it in a bash shell, run

	g++ packer_problem_4.cpp
	./a.out

or in Powershell,

	g++ packer_problem_4.cpp
	./a.exe