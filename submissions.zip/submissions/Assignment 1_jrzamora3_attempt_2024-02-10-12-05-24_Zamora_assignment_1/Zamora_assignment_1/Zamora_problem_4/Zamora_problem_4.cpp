#include <iostream>
using namespace std;

void change(int amount, int& quarters, int& dimes, int& nickels, int& pennies) {
    quarters = amount / 25;
    amount %= 25;
    dimes = amount / 10;
    amount %= 10;
    nickels = amount / 5;
    pennies = amount % 5;
}

int main() {
    int amount, quarters, dimes, nickels, pennies;

    //#1
    amount = 39;
    change(amount, quarters, dimes, nickels, pennies);
    cout << "Amount: " << amount << endl;
    cout << "Quarters: " << quarters << endl;
    cout << "Dimes: " << dimes << endl;
    cout << "Nickels: " << nickels << endl;
    cout << "Pennies: " << pennies << endl;
    cout << endl;

    //#2
    amount = 50;
    change(amount, quarters, dimes, nickels, pennies);
    cout << "Amount: " << amount << endl;
    cout << "Quarters: " << quarters << endl;
    cout << "Dimes: " << dimes << endl;
    cout << "Nickels: " << nickels << endl;
    cout << "Pennies: " << pennies << endl;
    cout << endl;

    return 0;
}