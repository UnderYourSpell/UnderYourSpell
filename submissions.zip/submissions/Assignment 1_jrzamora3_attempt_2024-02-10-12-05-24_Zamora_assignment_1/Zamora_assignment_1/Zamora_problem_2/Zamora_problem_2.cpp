#include <iostream>
using namespace std;
#include <cstdlib>
#include <ctime>
//Chuch-a-luck

//roll dice function
int rollDice() {
    int randomNum;
    return randomNum = rand() % 6 + 1;
}

int main() {
    
   srand(time(nullptr));
   
   int cash = 100;
   bool play = true;
   char yn;

   while (cash > 0 && play == true) {
        cout << "Money: $" << cash << endl;
        cout << "Play? (y/n): ";
        cin >> yn;

        if (yn == 'y') {
            cout << "Wager(can't be more than the amount of money owned): ";
            int wager;
            cin >> wager;

            //wager has to be a number and have 3x the bet amount
            while (wager * 3 > cash) {
                cout << "Enter again: " ;
                cin >> wager;
            }

            cout << "Pick a number from 1 to 6 (Your number): ";
            int playerNum;
            cin >> playerNum;

            while (playerNum >= 7 && playerNum <= 0) {
                cout << "Pick a number again: ";
                cin >> playerNum;
            }

            int playerScore = 0;
            for (int i = 0; i < 3; i++) {
                int ranNum = rollDice();
                cout << "Roll " << i + 1 << ": " << ranNum << endl;
                if (ranNum == playerNum) {
                    playerScore++;
                }
            }
            cout << "You have won: " << playerScore << endl;
            if (playerScore > 1) {
                cash += wager * playerScore;
            }
            else {
                cash -= wager;
            }
        }
        else {
            break;
        }
   }
   cout << "The end. You have $" << cash << " remaining." << endl;


    return 0;
}
