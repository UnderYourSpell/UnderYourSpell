#include <iostream>
using namespace std;

int main() {
	const int ENROLL_NUM = 3300;
	int count[10] = {0};
	int num[ENROLL_NUM];

	for (int i = 0; i < ENROLL_NUM; i++) {
		cin >> num[i];
		int lead_num = num[i];
		if (lead_num > 10) {
			lead_num /= 10;
		}

		count[lead_num]++;
	}
	for (int i = 0; i < 10; i++) {
		cout << i << ": " << count[i] << endl;
	}



	return 0;
}
