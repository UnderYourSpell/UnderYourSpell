#include <iostream>

using namespace std;


void roll(int &w, int &n, int &bank) {
		int d1, d2, d3;
		int count = 0;
		char y_n;
                d1 = rand()%6+1;
                d2 = rand()%6+1;
                d3 = rand()%6+1;
                cout << "You rolled " << d1 << ", " << d2 << " and " << d3 << endl;
                if (d1 == n)
                        count++;
                if (d2 == n)
                        count++;
                if (d3 == n)
                        count++;
                bank += count*w;
                cout <<  "You won $" << count*w << "!!!" << endl << "You have $" << bank << endl;
                if ( bank == 0) {
                        cout << "You are all out of money. Better luck next time!!" << endl;
                                return;
                }
                cout << "Would you like to roll again? y to roll and n to quit: ";
                cin >> y_n;
                if  (y_n == 'n') {
                        cout << "Goodbye!" << endl;
			return;
                }
                cout << "Enter your wager: ";
                cin >> w;
                while (w > bank) {
                        cout << "Not enough money. You have $" << bank << ". Make a smaller wager: ";
                        cin >> w;
                }
                bank -= w;
                n = 0;
                while (n < 1 || n > 6) {
                        cout << "Choose a number between 1 and 6: ";
                        cin >> n;
                }
		roll(w, n, bank);
}

int main() {

	int w;
	int n= 0;
	int bank = 100;
	bool again = false;
	char y_n = 'n';

	srand(time(NULL));

	cout << "Enter your wager: ";
	cin >> w;
	while (w > bank) {
		cout << "Not enough money. You have $" << bank << ". Make a smaller wager: ";
		cin >> w;
		}
	bank -= w;

	while (n < 1 || n >6) {
		cout << "Choose a number between 1 and 6: ";
		cin >> n;
	}
	cout << "Roll the dice? y to roll and n to quit: ";
	cin >> y_n;
	if (y_n == 'y') {
		roll(w, n, bank);
	}
	if (y_n == 'n') {
		return 0;
	}
	return 0;


}
