#include <iostream>

using namespace std;

int main() {

	int arr[9] = {0};
	int curr_num;

	while(cin >> curr_num) {
		if (curr_num/10000 != 0) {
			for ( int i = 0; i < 9; i++) {
				if (curr_num/100000 == i+1) {
					arr[i]++;
				}
			}
		}
		else if (curr_num/10000 != 0) {
			for ( int i = 0; i < 9; i++){
				if (curr_num/10000 == i+1) {
					arr[i]++;
				}
			}
		}
		else if (curr_num/1000 != 0){
			for ( int i = 0; i < 9; i++) {
				if (curr_num/1000 == i+1){
					arr[i]++;
				}
			}
		}
		else if (curr_num/100 != 0) {
			for ( int i = 0; i < 9; i++) {
				if (curr_num/100 == i+1) {
					arr[i]++;
				}
			}
		}
		else if (curr_num/10 != 0) {
			for ( int i = 0; i < 9; i++) {
				if(curr_num/10 == i+1) {
					arr[i]++;
				}
			}
		}
		else if (curr_num%10 != 0) {
			for (int i = 0; i < 9; i++) {
				if (curr_num%10 == i+1) {
					arr[i]++;
				}
			}
		}
	}
	for( int i = 0; i < 9; i++) {
		cout << "There are " << arr[i] << " " << i+1 << "s" << endl;
		}
return 0;
}
