#include <iostream>

using namespace std;

void get_change(int c, int &q, int &d, int &n, int &p) {
	q = c/25;
	c = c % 25;
	d = c/10;
	c = c % 10;
	n = n/5;
	c = c % 5;
	p = c;

}

int main(){

	int change = 0;
	int quarters = 0;
	int dimes = 0;
	int nickels =0;
	int pennies = 0;
	//cout << "Enter amount of change from 1-99: ;
	//cin >> change;
	change = 99;
	get_change(change, quarters, dimes, nickels, pennies);
	cout << "Your change for " << change << " cents is: " << endl;
	cout << quarters << " quarters" << endl;
	cout << dimes << " dimes" << endl;
	cout << nickels << " nickels" << endl;
	cout << pennies << " pennies" << endl;
	change = 38;
	get_change(change, quarters, dimes, nickels, pennies);
	cout << "Your change for " << change << " cents is: " << endl;
	cout << quarters << " Quarters" << endl;
	cout << dimes << " Dimes" << endl;
	cout << nickels << " Nickels" << endl;
	cout << pennies << " Pennies" << endl;

	return 0;
}

