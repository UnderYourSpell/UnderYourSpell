Problem 1:
	Run program benfords_law.cpp with  ./a.out < enrollments.txt after compiling on unix system. There are no known issues with this program.

Problem 2:
	Run program chuck_a_luck.cpp with ./a.out chuck_a_luck.cpp after compiling on unix system. There are no known issues with this program.

Problem 3:
	1. If the size of the maze array is known, make a same sized array to track locations in the maze that you have already been. While the location is not equal to s, check the location to the up, if location up is not an x and has not been to entered previously then move current location up, else check the location to the right and if its not an x has not been to entered previously move current location to the right, else check the location to the left, if not an x and has not been to entered previously move current location to the left, else check location down, if not an x and has not been to entered previously move current location down. If none of the locations are open then have it go to first previously entered space. Have different functions that are called based on the previous move so that after each move forward is the first option given and reverse is the last option given.

	2. Start with a 2D array of all Xs. Use a random number generator to choose start and finish points around the edges or the array. Use a random number generator to randomly call up, down, left and right changing the array from Xs to blanks. Use different function calls based on the previous call to  add extra weight from the random number assignments to the previous direction to increase straight lines and to decrease turning around. Have the algorithm check that there are at least two Xs in front of the location in the array before moving forward.

Problem 4:
	Run program change.cpp with ./a.out change.cpp after compiling on unix system. There are no know issues with this program.