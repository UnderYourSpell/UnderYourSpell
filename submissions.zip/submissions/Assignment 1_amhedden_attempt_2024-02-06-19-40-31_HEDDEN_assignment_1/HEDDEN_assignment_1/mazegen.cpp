/*
1.
a. Initialize a stack 
b. Start from a random location within the maze and push it to the stack.
c. Mark the current cell as visited
d. Check if current cell is the exit 'S'
	- If yes, terminate program
	- If no, explore neighboring cells, randomly choosing a valid direction
e. If stuck in a dead end (no S, all neighboring cells are either visited or Xs), backtrack until you reach a decision location, and take the next possible turn.
f. Avoid circles by maintaining a set of visited cells

2.
Initialize a grid representing the maze, with walls and open spaces.
Start from a random cell and mark it as part of the maze.
While there are unexplored cells: Randomly choose a neighboring cell.
If the chosen cell is within the boundaries of the grid and has not been visited:
Break the wall between the current cell and the chosen cell.
Mark the chosen cell as part of the maze.
Recursively apply the algorithm to the chosen cell.
If all neighboring cells have been visited, backtrack to the previous cell.
*/