#include <iostream>

using namespace std;

int main() {

    const int arraySize = 3295;
    int numbers[arraySize];
    int i = 0;

    for (i = 0; i < arraySize; i++) {
        cin >> numbers[i];
    }

    int digitCount[10] = { 0 };

    for (i = 0; i < arraySize; i++) {
        while (numbers[i] >= 10) {
            numbers[i] /= 10;
        }
        int firstDigit = numbers[i];
        if (firstDigit >= 1 && firstDigit <= 9) {
            digitCount[firstDigit]++;
        }
    }

    cout << "Occurrences of numbers starting with 1-9:" << endl;

    for (i = 1; i <= 9; i++) {
        cout << "Digit " << i << ": " << digitCount[i] << " occurrences" << endl;
    }

    return 0;
}
