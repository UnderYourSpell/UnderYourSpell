#include <iostream>

using namespace std;

void calcChange(int amount, int& quarters, int& dimes, int& nickels, int& pennies) {
	quarters = amount / 25;
	amount %= 25;
    dimes = amount / 10;
    amount %= 10;
    nickels = amount / 5;
    pennies = amount % 5;
}


int main() {
    int test1 = 92;
    int test2 = 34;
    int q1, d1, n1, p1, q2, d2, n2, p2;

    calcChange(test1, q1, d1, n1, p1);
    cout << "Exact change for $0." << test1 << " requires: " << endl;
    cout << q1 << " quarters." << endl;
    cout << d1 << " dimes." << endl;
    cout << n1 << " nickels" << endl;
    cout << "And " << p1 << " pennies." << endl;
    cout << endl;

    calcChange(test2, q2, d2, n2, p2);
    cout << "Exact change for $0." << test2 << " requires: " << endl;
    cout << q2 << " quarters." << endl;
    cout << d2 << " dimes." << endl;
    cout << n2 << " nickels" << endl;
    cout << "And " << p2 << " pennies." << endl;
}