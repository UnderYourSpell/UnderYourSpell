- run benford's law on a unix system using "./a.out < enrollments.txt". Ensure that the file is in the same directory as your script
- run chuck a luck and reference_params as regular progrmas

