#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

int rollDice() {
	return rand() % 6 + 1;
}


int main() {
	srand(static_cast<unsigned int>(time(0)));

	
	int playerNum = 0;
	int wager = 0;

	int wallet = 100;
	char playAgain;


	cout << "   ____ _  _ _  _ ____ _  _    ____    _    _  _ ____ _  _" << endl;
	cout << "   |    |__| |  | |    |_/  __ |__| __ |    |  | |    |_/" << endl;
	cout << "   |___ |  | |__| |___ | \\_    |  |    |___ |__| |___ | \\_" << endl;
	cout << endl;

	cout << "Welcome to Chuck-a-luck!" << endl << endl;

	while (true) {

		int dice1 = rollDice();
		int dice2 = rollDice();
		int dice3 = rollDice();
		int matches = 0;


		cout << "----------------" << endl;
		cout << "  WALLET: $" << wallet << endl;
		cout << "----------------" << endl << endl;
		cout << "Pick a number between 1-6" << endl;
		cin >> playerNum;
		while (playerNum > 6 || playerNum < 1) {
			cout << "Please enter a valid number: ";
			cin >> playerNum;
		}
		cout << "How much would you like to wager?" << endl;
		cin >> wager;
		while (wager > wallet) {
			cout << "You cannot bet more money than you have. Please try again" << endl;
			cin >> wager;
		}
		wallet -= wager;

		char rollAnswer;
		cout << "You chose: " << playerNum << endl;
		cout << "Would you like to roll the dice? (y/n) ";
		cin >> rollAnswer;
		if (rollAnswer != 'y') {
			cout << "Goodbye." << endl;
			break;
		}
		cout << endl;
		cout << "Rolling dice..." << endl;
		cout << "You rolled a " << dice1 << ", " << dice2 << ", and a " << dice3 << endl;


	if (dice1 == playerNum) {
		matches++;
	}
	if (dice2 == playerNum) {
		matches++;
	}
	if (dice3 == playerNum) {
		matches++;
	}

	if (matches == 0) {
		cout << "Sorry, you lost your wager." << endl;
	} else if (matches == 1) {
		cout << "Great! You won your wager back!" << endl;
		wallet += wager;
	} else if (matches == 2) {
		cout << "Great! You won twice your wager!" << endl;
		wallet += 2 * wager;
	} else if (matches == 3) {
		cout << "Great! You won thrice your wager!" << endl;
		wallet += 3 * wager;
	}

	
	cout << "Current wallet: $" << wallet << endl;
	if (wallet <= 0) {
		cout << "You are out of money. Goodbye" << endl;
		break;
	}

	cout << "Do you want to play again? (y/n): ";
	cin >> playAgain;

	if (playAgain != 'y' && playAgain != 'Y') {
		cout << "Thanks for playing Chuck-a-luck! Goodbye!" << endl;
		break;
	}


	} 
}