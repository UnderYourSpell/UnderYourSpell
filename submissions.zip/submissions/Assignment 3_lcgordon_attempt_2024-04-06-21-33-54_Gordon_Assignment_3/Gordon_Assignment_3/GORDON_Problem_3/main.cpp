#include <iostream>
#include <string>
#include "Movie.h"
using namespace std;

// Sorts movies alphabetically by name
void sort(Movie list[]);

int main() {

    Movie movie1 = Movie("Black Panther", "PG-13");
    Movie movie2 = Movie("Avengers: Infinity War", "PG-13");
    Movie movie3 = Movie("A Wrinkle In Time", "PG");
    Movie movie4 = Movie("Ready Player One", "PG-13");
    Movie movie5 = Movie("Red Sparrow", "R");
    Movie movie6 = Movie("The Incredibles 2", "G");
    Movie movies[] = {movie1, movie2, movie3, movie4, movie5, movie6};

    sort(movies);

    cout << "Movies: " << endl;
    for (int i = 0; i < 6; i ++) {
        cout << i + 1 << ". " << movies[i].getMovieName() << ", " << movies[i].getRating() << endl;
    }

};

// Sorts movies alphabetically by name
void sort(Movie list[]) {

    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 6; j++) {
            if (list[j].getMovieName() > list[j+1].getMovieName()) {
                Movie temp = list[j];
                list[j] = list[j+1];
                list[j+1] = temp;
            }
        }
    }
}