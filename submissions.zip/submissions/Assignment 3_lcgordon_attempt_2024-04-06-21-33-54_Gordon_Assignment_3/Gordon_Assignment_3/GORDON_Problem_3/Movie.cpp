#include <iostream>
#include <string>
#include "Movie.h"
using namespace std;

Movie::Movie() : movieName(""), mpaaRating("")
{
}

Movie::Movie(string name, string rating)
{
    setMovieName(name);
    setRating(rating);
}

void Movie::setMovieName(string name)
{
    movieName = name;
}

void Movie::setRating(string rating)
{
    mpaaRating = rating;
}

string Movie::getMovieName()
{
    return movieName;
}

string Movie::getRating()
{
    return mpaaRating;
}
