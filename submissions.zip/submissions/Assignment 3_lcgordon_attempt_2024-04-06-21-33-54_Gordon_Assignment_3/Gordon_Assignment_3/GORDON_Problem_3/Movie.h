#pragma once
#include <string>
using namespace std;

class Movie {
private:
    string movieName;
    string mpaaRating;
public:
    Movie();
    Movie(string name, string rating);
    void setMovieName(string name);
    void setRating(string rating);
    string getMovieName();
    string getRating();
};