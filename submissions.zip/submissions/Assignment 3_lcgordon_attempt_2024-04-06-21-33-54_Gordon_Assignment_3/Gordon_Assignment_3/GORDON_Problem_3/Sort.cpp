#include <iostream>
#include <string>
#include "Movie.h"
using namespace std;

// Sorts movies alphabetically by name
void sort(Movie Movies[]) {

}