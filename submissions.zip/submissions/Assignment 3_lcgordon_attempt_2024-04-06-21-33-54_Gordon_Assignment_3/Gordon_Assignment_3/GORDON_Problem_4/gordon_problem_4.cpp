// This program will take 3295 enrollment numbers and count the frequency of each leading digit
#include <iostream>
#include <cstring>
#include <fstream>
using namespace std;

int main()
{
    string enrollment;
    ifstream inputFile;
    inputFile.open("enrollments.txt");
    int leadingDigit;
    int leadingDigitFrequency[9] = {0};
    int leadingDigitCounter = 0;


    if (!inputFile.is_open()) {
        cout << "Could not open file enrollments.txt" << endl;
    }

    // Take 3295 numbers as inputs
    while (!inputFile.eof()) {
        // Place each number in the enrollment string
        inputFile >> enrollment;
        // Find the leading digit
        leadingDigit = enrollment[0] - 48;
        // For each number, checks what the leading number is
        for (int j = 0; j < 9; j++) {
            // Increases that leading digit's frequency by one
            if (leadingDigit == (j + 1)) {
                leadingDigitFrequency[j] += 1;
            }
        }
    }

    // Output leading digit frequencies as percentages
    cout << "Leading Digit Frequencies:" << endl;
    for (int j = 0; j < 9; j++) {
        cout << j + 1 << ": " << leadingDigitFrequency[j] * 100 / 3295 << "%" << endl;
    }

    return 0;

    inputFile.close();
}