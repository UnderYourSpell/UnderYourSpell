#include <iostream>
#include <ctime>
#include <cstdlib>
#include "Maze.h"
using namespace std;

int main() {

    int h = 20;
    int w = 20;
    
    Maze myMaze(h, w);

    myMaze.solveMaze();

}