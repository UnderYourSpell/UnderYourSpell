#include <iostream>
#include <ctime>
#include <cstdlib>
#include "Maze.h"
using namespace std;

Maze::Maze(int h, int w) {

    HEIGHT = h;
    WIDTH = w;

    maze = new char*[HEIGHT];
    for (int i = 0; i < HEIGHT; ++i) {
            maze[i] = new char[WIDTH];
    }

    createMaze();

}

Maze::~Maze() {

   for (int i = 0; i < HEIGHT; ++i) {
            delete[] maze[i];
    }
    delete[] maze;
}

void Maze::printMaze(int thisX, int thisY) {
    for (int y=0; y < HEIGHT; y++)
    {
        for (int x=0; x < WIDTH; x++)
        {
	        if ((x==thisX) && (y==thisY)) {
		        cout << "@";
            }
	        else {
		        cout << maze[y][x];
            }
        }
        cout << endl;
    }
}

bool Maze::move(int newX, int newY)
{
    bool foundExit = false;
    if (maze[newY][newX]=='E'){ 	// Check for exit
	    foundExit = true;
    }
    
    curX = newX;			// Update location
    curY = newY;

    visited[curY][curX] = true;
 
    return foundExit;
}

bool Maze::validMove(int newX, int newY)
{
    // Check for going off the maze edges
    if (newX < 0 || newX >= WIDTH) {
	    return false;
    }
    if (newY < 0 || newY >= HEIGHT) {
	    return false;
    }
    // Check if target is a wall
    if (maze[newY][newX]=='X') {
	    return false;
    }
    // Check if visited
    if (visited[newY][newX]) {
	    return false;
    }

    return true;
}

void Maze::createMaze() {
    
    /****************
    Programmatically fill out the maze with ***'s on the borders and spaces in the middle
    ****************/
    // All blank
    for (int x = 0; x < WIDTH; x++) {
        for (int y = 0; y < HEIGHT; y++) {
            maze[y][x] = ' ';
        }
    }

    // Borders with X
    for (int x = 0; x < WIDTH; x++)
    {
	    maze[0][x] = 'X';
	    maze[HEIGHT-1][x] = 'X';
    }

    for (int y = 0; y < HEIGHT; y++)
    {
	    maze[y][0] = 'X';
	    maze[y][WIDTH-1] = 'X';
    }

    // ***** Randomly fill in 25% of the middle
    int numCells = static_cast<int>((HEIGHT-2)*(WIDTH-2)*0.25);
    int count = 0;
    while (count < numCells)
    {
        int x = (rand() % (WIDTH-2)) +1;
        int y = (rand() % (HEIGHT-2)) +1;

        if (maze[y][x]==' ')
        {
	        maze[y][x]='X';
	        count++;
        }
    }

    srand(time(NULL));

    // ***** Pick a random start and end that is not a wall *****
    startX = (rand() % (WIDTH-2)) +1;
    startY = (rand() % (HEIGHT-2)) +1;
    while (maze[startY][startX]=='X')
    {
        startX = (rand() % (WIDTH-2)) +1;
        startY = (rand() % (HEIGHT-2)) +1;
    }
    // At this point, (x,y) contains our start position
    // ***** Pick a random end position that is not a wall *******
    exitX = (rand() % (WIDTH-2)) +1;
    exitY = (rand() % (HEIGHT-2)) +1;
    while (maze[exitY][exitX]=='X')
    {
        exitX = (rand() % (WIDTH-2)) +1;
        exitY = (rand() % (HEIGHT-2)) +1;
    }
    maze[exitY][exitX]='E';

    curX = startY;
    curY = startX;

    printMaze(curX, curY);

}

void Maze::solveMaze() {

    visited = new bool*[HEIGHT];
    for (int i = 0; i < HEIGHT; ++i) {
            visited[i] = new bool[WIDTH];
    }
    
    // Initialize visited locations to false
    for (int x = 0; x < WIDTH; x++) {
        for (int y = 0; y < HEIGHT; y++) {
            visited[y][x] = false;
        }
    }
    visited[startY][startX] = true;

    int solutionX[(HEIGHT-2)*(WIDTH-2)];
    int solutionY[(HEIGHT-2)*(WIDTH-2)];
    int numPoints = 0;

    bool found = search(solutionX, solutionY, numPoints);
    if (!found) {
	    cout << "No solution found.";
    }
    else
    {
	    cout << "Solution found!  Here is the path from the start." << endl;
        for (int i = 0; i <= numPoints - 1; i++)
        {
		    printMaze(solutionX[i], solutionY[i]);
		    cout << endl;
 	    }
    }

    for (int i = 0; i < HEIGHT; ++i) {
        delete[] visited[i];
    }
    delete visited;

}


bool Maze::search(int solutionX[], int solutionY[], int &numEntries)
{
    bool foundExit = false;

    if (maze[curY][curX]==maze[exitY][exitX]) {
        return true;
    }

    solutionX[numEntries] = curX;
    solutionY[numEntries] = curY;
    numEntries++;

    visited[curY][curX]= true;

    if (validMove(curX, curY - 1)) {
        move(curX, curY - 1);
	    foundExit = search(solutionX,solutionY,numEntries);
    }
    if (!foundExit && validMove(curX, curY + 1)) {
        move(curX, curY + 1);
	    foundExit = search(solutionX,solutionY,numEntries);
    }
    if (!foundExit && validMove(curX - 1, curY)) {
        move(curX - 1, curY);
	    foundExit = search(solutionX,solutionY,numEntries);
    }
    if (!foundExit && validMove(curX + 1, curY)) {
        move(curX + 1, curY);
	    foundExit = search(solutionX,solutionY,numEntries);
    }

    if (foundExit)
    {
	    return true;
    }

    return false;

}