#pragma once

class Maze {

private:
    int WIDTH;
    int HEIGHT;
    char **maze;
    bool **visited;
    int startX;
    int startY;
    int exitX;
    int exitY;
    int curX;
    int curY;
    int numPoints;
    bool search(int solutionX[], int solutionY[], int &numEntries);
    bool move(int newX, int newY);
    bool validMove(int newX, int newY);


public:
    Maze(int h, int w);
    ~Maze();
    void createMaze();
    void printMaze(int thisX, int thisY);
    void solveMaze();

};