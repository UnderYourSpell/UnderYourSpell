#include <iostream>
#include <string>
#include <math.h>
#include "ZipCode.h"
using namespace std;

int main() {

    string zip1 = "110100101000101011000010011";
    int zip2 = 99508;
    
    ZipCode testZip(zip1);

    cout << testZip.getZip() << endl;
    cout << testZip.getBarCode() << endl;

    ZipCode uaaZip(zip2);

    cout << uaaZip.getZip() << endl;
    cout << uaaZip.getBarCode() << endl;
}