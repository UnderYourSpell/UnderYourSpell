#include "ZipCode.h"
#include <string>
#include <math.h>
using namespace std;

ZipCode::ZipCode(int zip) {

    for (int i = 4; i >= 0; i--) { 
        zipCode[i] = zip % 10;
        zip /= 10;
    }
}

// The zipcode is stored in 5-digit integer form, so barcode form must be decoded to be stored in the class
ZipCode::ZipCode(string barCode)
{
    decodeZip(barCode);
}

// Get five digits from the barcode string
void ZipCode::getFiveDigits(string barCode, int start)
{
    for (int i = 0; i < 5; i++) {
        fiveDigits[i] = barCode[i + start] - '0';
    }
}

// Decodes the zipcode from barcode form and returns an integer
void ZipCode::decodeZip(string barCode)
{
    int product;

    for (int i = 0; i < 5; i ++) {
        // Get a group of five digits from the barcode (skip the first digit)
        getFiveDigits(barCode, 1 + i * 5);
        for (int j = 0; j < 5; j++) {
            product = fiveDigits[j] * postnet[j];
            zipCode[i] += product;
        }
        
        if (zipCode[i] > 10) {
            zipCode[i] = 0;
        }
        // Repeat the decoding process for all five groups of five digits to get the five digit zip code     
    }
}

// Encodes the integer zip code into barcode form and returns it as a string
string ZipCode::encodeZip()
{
    int productSum;
    int productDigits[5] = {0};
    string barCode = "1";

    // Separate out each digit of the zip code and encode it into a 5 digit group
    for (int i = 0; i < 5; i++) {
        productSum = zipCode[i];
        
        if (productSum == 0) {
            productSum = 11;
        }

        // Find the products of the five digits and the postnet code
        for (int j = 0; j < 5; j++) {
            if (productSum >= postnet[j]) {
                productDigits[j] = postnet[j];
                productSum -= postnet[j];
            }
            else {
                productDigits[j] = 0;
            }
        }

        // Divide the product digits by the postnet code to find the original 5 digits.
        // The result will be the barcode digit, which can been concactenated to the barcode.
        int ones = 0;
        
        for (int j = 0; j < 5; j++) {
            if (productDigits[j] == postnet[j] && ones < 2) {
                barCode.push_back(1 + '0');
                ones += 1;
            }
            else {
                barCode.push_back(0 + '0');
            }
        }
    }

    barCode.push_back('1');
    
    return barCode;

}

// Returns the zip code as an integer
int ZipCode::getZip()
{

    int zip = 0;
    int temp = 10000;
    
    for (int i = 0; i < 5; i++) {
        zip += zipCode[i] * temp;
        temp /= 10;
    }
    
    return zip;
}

// Returns the zipcode in barcode form as a string
string ZipCode::getBarCode()
{
    return encodeZip();
}