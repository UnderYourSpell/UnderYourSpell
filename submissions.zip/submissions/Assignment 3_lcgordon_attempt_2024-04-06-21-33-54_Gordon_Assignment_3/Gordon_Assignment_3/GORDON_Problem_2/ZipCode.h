#pragma once
#include <string>
#include <math.h>
using namespace std;

class ZipCode
{
private:
    int zipCode[5];
    int fiveDigits[5];
    const int postnet[5] = {7, 4, 2, 1, 0};
    void getFiveDigits(string barCode, int start);
    void decodeZip(string barCode);
    string encodeZip();
    
public:
    ZipCode(int zip);
    ZipCode(string barCode);
    int getZip();
    string getBarCode();
};