I was having trouble with the memory deallocationg in the Maze class in problem 5. It was running the deconstructor twice and throwing an error. I think this has something to do with the way that I'm passing the maze object to the Player class. I solved this by getting rid of the Maze deconstructor and deallocating the memory in the Player class deconstructor.

for all problems just run main.cpp