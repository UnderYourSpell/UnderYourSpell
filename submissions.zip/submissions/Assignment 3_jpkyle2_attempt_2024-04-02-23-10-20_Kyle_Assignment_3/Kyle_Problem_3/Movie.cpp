#include "Movie.h"

Movie::Movie() : name("NoName"), rating("Unrated")
{
}

Movie::Movie(string name, string rating) : name(name), rating(rating)
{
}

void Movie::setName(string name)
{
	this->name = name;
}

void Movie::setRating(string rating)
{
	this->rating = rating;
}

string Movie::getName()
{
	return name;
}

string Movie::getRating()
{
	return rating;
}

bool Movie::operator<(Movie other)
{
	return name < other.getName();
}
