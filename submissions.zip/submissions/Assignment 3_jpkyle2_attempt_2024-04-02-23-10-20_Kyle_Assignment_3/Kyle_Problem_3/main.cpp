#include <iostream>
#include "Movie.h"
using namespace std;


void sort(Movie movies[], int length)
{
	if (length == 1)
		return;

	int minIndex = 0;
	for (int i = 0; i < length; i++)
	{
		if (movies[i] < movies[minIndex])
			minIndex = i;
	}
	
	Movie temp = movies[0];
	movies[0] = movies[minIndex];
	movies[minIndex] = temp;

	sort(&movies[1], length - 1);
}




int main()
{
	Movie movies[6] = 
	{
		Movie("Black Panther", "PG-13"), 
		Movie("Avengers: Infinity War", "PG_13"), 
		Movie("A Wrinkle In Time", "PG"), 
		Movie("Ready Player One", "PG-13"), 
		Movie("Red Sparrow", "R"),
		Movie("The Incredibles 2", "G")
	};

	sort(movies, 6);

	for (int i = 0; i < 6; i++)
	{
		cout << movies[i].getName() << " - " << movies[i].getRating() << endl;
	}
}