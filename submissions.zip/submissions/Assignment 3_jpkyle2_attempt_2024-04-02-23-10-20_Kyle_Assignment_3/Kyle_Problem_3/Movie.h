#pragma once
#include <string>
using namespace std;

class Movie
{
private:
	string name, rating;
public:
	Movie();
	Movie(string, string);

	void setName(string);
	void setRating(string);
	string getName();
	string getRating();

	bool operator<(Movie);
};