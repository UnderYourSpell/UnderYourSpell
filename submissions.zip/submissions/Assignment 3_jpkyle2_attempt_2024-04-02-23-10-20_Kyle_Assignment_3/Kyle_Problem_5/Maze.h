#pragma once

class Maze
{
private:
	int height, width;
	char** maze;

	void makeMaze();

public:
	Maze();
	Maze(int, int);
	
	void printMaze();
	char checkCoord(int, int);

	friend class Player;
};