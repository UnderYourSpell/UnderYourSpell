#pragma once
#include "Maze.h"

class Player
{
private:
	int curx, cury, numPoints = 0;
	bool** visited;
	int** solution;

	Maze maze;

	bool validMove(int, int);
	void addToArrays();

public:
	Player(Maze&);
	~Player();

	bool search();
	void printMaze();
	void printSolution();
};