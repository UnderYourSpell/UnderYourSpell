#include <iostream>
#include "Player.h"
using namespace std;

int main()
{
	Maze maze;
	Player player(maze);
	player.search();
	player.printSolution();
	return 0;
}