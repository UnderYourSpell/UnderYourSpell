#include "Maze.h"
#include <iostream>
using namespace std;

void Maze::makeMaze()
{
	srand(time(NULL));

	/****************
	 Programmatically fill out the maze with ***'s on the borders and spaces in the middle
	 ****************/
	 // All blank
	for (int x = 0; x < width; x++)
		for (int y = 0; y < height; y++)
			maze[y][x] = ' ';
	// Borders with X
	for (int x = 0; x < width; x++)
	{
		maze[0][x] = 'X';
		maze[height - 1][x] = 'X';
	}
	for (int y = 0; y < height; y++)
	{
		maze[y][0] = 'X';
		maze[y][width - 1] = 'X';
	}

	// ***** Randomly fill in 25% of the middle
	int numCells = static_cast<int>((height - 2) * (width - 2) * 0.25);
	int count = 0;
	while (count < numCells)
	{
		int x = (rand() % (width - 2)) + 1;
		int y = (rand() % (height - 2)) + 1;
		if (maze[y][x] == ' ')
		{
			maze[y][x] = 'X';
			count++;
		}
	}

	int exitX = (rand() % (width - 2)) + 1;
	int exitY = (rand() % (height - 2)) + 1;
	while (maze[exitY][exitX] == 'X')
	{
		exitX = (rand() % (width - 2)) + 1;
		exitY = (rand() % (height - 2)) + 1;
	}
	maze[exitY][exitX] = 'E';
}

Maze::Maze() : width(20), height(20)
{
	maze = new char* [height];

	for (int i = 0; i < height; ++i) 
		maze[i] = new char[width];

	makeMaze();
}

Maze::Maze(int height, int width) : height(height), width(width)
{
	maze = new char* [height];

	for (int i = 0; i < height; ++i) 
		maze[i] = new char[width];

	makeMaze();
}

void Maze::printMaze()
{
	for (int y = 0; y < height;y++)
	{
		for (int x = 0; x < width; x++)
		{
			cout << maze[y][x] << ' ';
		}
		cout << endl;
	}	
}

char Maze::checkCoord(int y, int x)
{
	return maze[y][x];
}
