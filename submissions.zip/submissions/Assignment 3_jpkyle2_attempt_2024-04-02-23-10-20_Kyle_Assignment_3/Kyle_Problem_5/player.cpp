#include "player.h"
#include <ctime>
#include <random>
#include <iostream>
using namespace std;

Player::Player(Maze& maze)
{
	//initialize maze
	this->maze = maze;
	
	//intialize array to store where player has visited
	visited = new bool* [maze.height];

	for (int i = 0; i < maze.height; ++i)
		visited[i] = new bool[maze.width];

	for (int i = 0; i < maze.height; i++)
	{
		for (int j = 0; j < maze.width; j++)
		{
			visited[i][j] = false;
		}
	}

	//create start location
	srand(time(NULL));

	curx = (rand() % (maze.width - 2)) + 1;
	cury = (rand() % (maze.height - 2)) + 1;
	while (maze.checkCoord(cury, curx) == 'X' || maze.checkCoord(cury, curx) == 'E')
	{
		curx = (rand() % (maze.width - 2)) + 1;
		cury = (rand() % (maze.height - 2)) + 1;
	}

	//initialize array to store the solution to the maze
	solution = new int* [(maze.height - 2) * (maze.width - 2)];

	for (int i = 0; i < (maze.height - 2) * (maze.width - 2); ++i)
		solution[i] = new int[2];

	for (int i = 0; i < (maze.height - 2) * (maze.width - 2); i++)
	{
		for (int j = 0; j < 2; j++)
		{
			solution[i][j] = -1;
		}
	}
}

Player::~Player()
{
	for (int i = 0; i < maze.height; i++)
		delete[] visited[i];
	delete[] visited;

	for (int i = 0; i < (maze.height - 2) * (maze.width - 2); i++)
		delete[] solution[i];
	delete[] solution;

	for (int i = 0; i < maze.height; i++)
		delete[] maze.maze[i];
	delete[] maze.maze;
}

bool Player::search()
{
	bool foundExit = false;

	if (maze.maze[cury][curx] == 'E')
		return true;

	visited[cury][curx] = true;
	if (validMove(curx, cury - 1))
	{
		cury--;
		foundExit = search();
		cury++;
	}
	if (validMove(curx, cury + 1))
	{
		cury++;
		foundExit = search();
		cury--;
	}
	if (validMove(curx - 1, cury))
	{
		curx--;
		foundExit = search();
		curx++;
	}
	if (validMove(curx + 1, cury))
	{
		curx++;
		foundExit = search();
		curx--;
	}

	if (foundExit)
	{
		// Remember coordinates we found the exit in the solution arrays
		addToArrays();
		return true;
	}
	return false;
}

bool Player::validMove(int newX, int newY)
{
	// Check for going off the maze edges
	if (newX < 0 || newX >= maze.width)
		return false;
	if (newY < 0 || newY >= maze.height)
		return false;
	// Check if target is a wall
	if (maze.checkCoord(newY, newX) == 'X')
		return false;
	// Check if visited
	if (visited[newY][newX])
		return false;
	return true;
}

void Player::printMaze()
{
	for (int y = 0; y < maze.height;y++)
	{
		for (int x = 0; x < maze.width; x++)
		{
			if (y == cury && x == curx)
				cout << '@' << ' ';
			else
				cout << maze.maze[y][x] << ' ';
		}
		cout << endl;
	}
}

void Player::printSolution()
{
	for (int i = numPoints - 1; i >= 0; i--)
	{
		cury = solution[i][0];
		curx = solution[i][1];
		printMaze();
		cout << endl;
	}
}

void Player::addToArrays()
{
	solution[numPoints][0] = cury;
	solution[numPoints][1] = curx;
	numPoints++;
}
