#pragma once
#include <string>

using namespace std;
class PostCode
{
public:
	PostCode(int zipCode);
	PostCode(string numCode);

	int getZipCode();
	string getPostCode();

private:
	string postCode;
};