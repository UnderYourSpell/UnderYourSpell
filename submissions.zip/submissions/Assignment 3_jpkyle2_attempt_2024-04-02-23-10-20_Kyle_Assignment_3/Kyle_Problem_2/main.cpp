#include <iostream>
#include "PostCode.h"
using namespace std;

int main()
{	
	PostCode code1(99504);
	cout << "for the Zip Code 99504, the Post Code is: " << code1.getPostCode() << endl;

	PostCode code2("110100101000101010001100011");
	cout << "for the Post Code 110100101000101010001100011, the Zip Code is: " << code2.getZipCode() << endl;
}