#include "PostCode.h"
#include <math.h>
#include <iostream>

PostCode::PostCode(int zipCode)
{
	int digit;
	int tempDigit;

	postCode += "1";

	for (int i = 10000; i > 0; i /= 10)
	{
		digit = (zipCode / i) % 10;
		tempDigit = digit;

		if (digit == 0)
			postCode += "11000";
		else
		{
			if (tempDigit >= 7) { postCode += "1"; tempDigit -= 7; }
			else postCode += "0";
			if (tempDigit >= 4) { postCode += "1"; tempDigit -= 4; }
			else postCode += "0";
			if (tempDigit >= 2) { postCode += "1"; tempDigit -= 2; }
			else postCode += "0";
			if (tempDigit >= 1) { postCode += "1"; tempDigit -= 1; }
			else postCode += "0";
			if (tempDigit == 1 || digit == 2 || digit == 4 || digit == 7) postCode += "1";
			else postCode += "0";
		}
	}

	postCode += "1";

}

PostCode::PostCode(string postCode) : postCode(postCode)
{
}

int PostCode::getZipCode()
{
	string tempString;
	int digit;
	int zipCode = 0;

	for (int i = 0; i < 5; i++)
	{
		tempString = postCode.substr(1 + (i * 5), 5);

		if (tempString == "11000") digit = 0;
		else 
		{
			digit = 0;
			if (tempString[0] == '1') digit += 7;
			if (tempString[1] == '1') digit += 4;
			if (tempString[2] == '1') digit += 2;
			if (tempString[3] == '1') digit += 1;
		}

		zipCode += digit * pow(10, 4 - i);
	}

	return zipCode;
}

string PostCode::getPostCode()
{
	return postCode;
}
