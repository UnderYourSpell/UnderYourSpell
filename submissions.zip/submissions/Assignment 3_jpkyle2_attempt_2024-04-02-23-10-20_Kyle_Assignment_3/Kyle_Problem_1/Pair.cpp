#include "Pair.h"

Pair::Pair() : num1(0), num2(0)
{
}

Pair::Pair(int num1, int num2) : num1(num1), num2(num2)
{
}

int Pair::get1()
{
	return num1;
}

int Pair::get2()
{
	return num2;
}

// Return a new pair that adds the corresponding numbers
Pair operator+(const Pair& p1, const Pair& p2)
{
	Pair newPair;
	newPair.num1 += p1.num1 + p2.num1;
	newPair.num2 += p1.num2 + p2.num2;
	return newPair;
}

// Return a new pair that adds otherNum to num1 and num2
Pair operator+(int a, const Pair& p2)
{
	Pair newPair;
	newPair.num1 += a + p2.num1;
	newPair.num2 += a + p2.num2;
	return newPair;
}

Pair operator+(const Pair& p1, int a)
{
	Pair newPair;
	newPair.num1 += a + p1.num1;
	newPair.num2 += a + p1.num2;
	return newPair;
}