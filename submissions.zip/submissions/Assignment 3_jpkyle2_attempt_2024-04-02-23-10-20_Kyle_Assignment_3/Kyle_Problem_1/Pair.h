#pragma once
class Pair
{
private:
	int num1, num2;
public:
	Pair();
	Pair(int num1, int num2);
	int get1();
	int get2();
	//Pair operator+(const Pair& other);
	//Pair operator+(int otherNum);

	friend Pair operator+(const Pair& p1, const Pair& p2);
	friend Pair operator+(int a, const Pair& p2);
	friend Pair operator+(const Pair& p1, int a);
};
