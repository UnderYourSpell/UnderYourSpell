#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
	ifstream inFile;

	inFile.open("enrollments.txt");
	if (!inFile.is_open())
	{
		cout << "File failed to open" << endl;
		return 1;
	}

	string tempLine;
	int leadNums[9] = {0};
	while (getline(inFile, tempLine))
	{
		leadNums[(int)(tempLine[0] - '0') - 1]++;
	}


	for (int i = 0; i < 9; i++)
	{
		cout << i + 1 << ": " << leadNums[i] << " - " << leadNums[i] / 3295.0 * 100 << "%" << endl;
	}


}