#include <iostream>
int rollDice() {
return (rand() % 6 + 1) + (rand() % 6 + 1) + (rand() % 6 + 1);
}
bool isValidNumber(int number) {
return (number >= 1 && number <= 6);
}
int main() {
unsigned int seed = static_cast<unsigned int>(time(nullptr));
srand(seed);

const int initialBalance = 100;
int balance = initialBalance;
int wager;

std::cout << "Welcome to Chuck-a-luck!" << std::endl;

while (balance > 0) {
std::cout << "\nYour current balance: $" << balance << std::endl;
do {
            std::cout << "Enter your wager (0 to quit): $";
            std::cin >> wager;

            if (wager == 0) {
                std::cout << "Thanks for playing! Your final balance is: $" << balance << std::endl;
                return 0;
            }

            if (wager > balance) {
                std::cout << "You cannot wager more than your current balance. Try again." << std::endl;
            }
        } while (wager > balance);

        int selectedNumber;
        do {
            std::cout << "Choose a number to bet on (1-6): ";
            std::cin >> selectedNumber;

            if (!isValidNumber(selectedNumber)) {
                std::cout << "Invalid number. Please enter a number between 1 and 6." << std::endl;
            }
        } while (!isValidNumber(selectedNumber));

       
        int diceSum = rollDice();

        std::cout << "You rolled: " << diceSum << std::endl;

       
        if (selectedNumber == diceSum) {
            balance += wager * 3; 
            std::cout << "Congratulations! You win $" << wager * 3 << "!" << std::endl;
        } else {
            balance -= wager; 
            std::cout << "sorry, you lose $" << wager << "." << std::endl;
        }
    }

    std::cout << "You're out of money. Thanks for playing!" << std::endl;

    return 0;
}
