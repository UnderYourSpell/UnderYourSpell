#include <iostream>

using namespace std;

int main(){
const int numberOfEnrollments = 3295;
int countByDigit[9] = {0};

for (int i = 0; i < numberOfEnrollments; ++i){
int enrollmentNum;
cin >> enrollmentNum;

if (enrollmentNum > 0){
int firstDigit = enrollmentNum;
while (firstDigit >=10){
firstDigit /= 10;
}

if (firstDigit >= 1 && firstDigit <= 9){
countByDigit[firstDigit -1]++;
}
}
}
for (int i = 0; i < 9; ++i){
cout << "Number of enrollments starting with " << (i +1) << ": " << countByDigit[i] << endl;
}
return 0;
}
