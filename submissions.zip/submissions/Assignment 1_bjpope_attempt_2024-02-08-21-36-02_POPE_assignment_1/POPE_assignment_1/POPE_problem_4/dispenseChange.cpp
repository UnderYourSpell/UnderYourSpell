//This Program converts a given amount of cents up to 99, and displays
//how many of a specific coin would be returned

#include <iostream>

using namespace std;

void changeLeft(int change, int &quarters, int &dimes, int &nickels, int &pennies) {
	quarters = change / 25;
	change -= (quarters * 25);

	dimes = change / 10;
	change -= (dimes * 10);

	nickels = change / 5;
	change -= (nickels * 5);

	pennies = change / 1;
}

int main() {
	int change, quarters = 0, dimes = 0, nickels = 0, pennies = 0;


	cout << "Please input an amount of cents between 1-99: ";
	cin >> change;
	while (change < 1 || change > 99) {
		cout << "Value out of range, try again: ";
		cin >> change;
	}

	changeLeft(change, quarters, dimes, nickels, pennies);
	cout << "Quarters: " << quarters << endl;
	cout << "Dimes: " << dimes << endl;
	cout << "Nickels: " << nickels << endl;
	cout << "Pennies: " << pennies << endl;
}
