//This program inputs a series of numbers from enrollments.txt and
//outputs how many numbers start with a specific number ranging 1-9
#include <iostream>
#include <string>
using namespace std;

int main() {
	int arr[9] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	int temp;
	while(cin >> temp) {
		while (temp >= 10) {
			temp /= 10;
		}
		for (int i = 0; i < 9; i++) {
			if (temp == i + 1) {
				arr[i] += 1;
			}
		}
	}
	for (int i = 0; i < 9; i++) {
		cout << i << ": " << arr[i] << endl;
	}
}
