//This program is a recreation of the game Chuck-a-luck using c++
#include <iostream>
#include <time.h>

using namespace std;

int rollNums(int num, int wager) {
	srand(time(NULL));
	
	int count = 0;
	int randNums[3] = { rand() % 5 + 1, rand() % 5 + 1, rand() % 5 + 1 };

	for (int i = 0; i < 3; i++) {
		cout << "Roll number " << i + 1 << ": " << randNums[i] << endl;
		if (num == randNums[i]) {
			count += 1;
		}
	}
	cout << "You matched " << count << " rolls, you get $" << wager * count << " back!" << endl;
	return count;
}

int main() {
	int W, n, wallet = 100;
	char again;

	cout << "Current balance: $" << wallet << endl;

	while (wallet != 0) {
		cout << "\nInput a wager: ";
		cin >> W;
		while (W > wallet) {
			cout << "You dont have enough money, re-input wager: ";
			cin >> W;
		}

		wallet -= W;

		cout << "Input a number 1-6: ";
		cin >> n;
		while (n > 6 || n < 1) {
			cout << "Number is out of range, re-input wager: ";
			cin >> W;
		}

		wallet = wallet + (W * rollNums(n, W));

		if (wallet == 0) {
			cout << "You are out of money, thank you for playing!" << endl;
		}
		else {
			cout << "Your current balance is: $" << wallet << ", continue playing?" << endl;
			cout << "Input Y to continue, N to quit (Y/N): ";
			while (cin >> again) {
				if (again == 'N') {
					cout << "Final total: $" << wallet << ", thanks for playing!" << endl;
					return 0;
				}
				else if (again == 'Y') {
					break;
				}
				else {
					cout << "Input incorrect try again. (Y/N): ";
				}
			}
		}
	}

	return 0;
}
