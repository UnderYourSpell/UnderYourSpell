Instructions for each Problem:
1. To run the program, type:
./BenfortSort < enrollments.txt

2. To run the program, type:
./ChuckALuck
Then just follow along

3. This folder includes two text files about how I might design an
algorithm solves mazes and another on how I might create a maze. One option
to display the contents is to type:
cat question1.txt
cat question2.txt

4. To run the program, type:
./DispenseChange
Then just follow along 


Issues:
I didn't run into any problems with any of the codes