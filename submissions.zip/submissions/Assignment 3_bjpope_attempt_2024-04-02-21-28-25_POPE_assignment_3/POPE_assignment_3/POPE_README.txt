Problem 1:
Comments are found within the code to solve the problem givin in the assignment 3 document.
Simply compile and run the program

Problem 2:
Simply compile and run the program and it will show you a zip code and bar code. If you wanted to use other examples, go into the cpp file
and change the barcode number within zip("") declared in int main(), and change the zip code in zipbar() declared in int main()

Problem 3:
Simply compile and run the program and it will show you the organised list of movies, alongside their ratings.

Problem 4:
Simply compile and run the program and it will show Benford's Law, using data from the external file "enrollments.txt"

Problem 5:
Simply compile and run the program and it will show a maze being created then solved, updating in console every time it moved
I used the maze generator/solver from the previous assignment that I worked on instead of the one provided in Assignment 3, I just knew it more

If you want to print the base maze without it being solved, you can insert maze.printBaseMaze() in the int main() and it will show it.
If you want to create more mazes, you can do so by creating a new class Maze, with another name. For example, Maze maze2
If you want to print the steps to solve (which is currently set up by default), maze.printMazeSteps() in int main() will do exactly that.