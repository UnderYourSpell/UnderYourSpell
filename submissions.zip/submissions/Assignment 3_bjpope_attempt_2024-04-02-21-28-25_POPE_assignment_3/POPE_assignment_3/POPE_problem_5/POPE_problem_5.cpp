// POPE_problem_5.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <ctime>
#include <algorithm>
#include <cstdlib>
using namespace std;



class Maze
{
private:
	static const int WIDTH = 20;
	static const int HEIGHT = 20;
	char maze[WIDTH][HEIGHT];
	bool visited[WIDTH][HEIGHT];
	bool foundExit;
	int row = 0;
	int path[100][2] = { 0 };  // Stores coordinates, could crash if amount of steps exceeds 100, just change to higher number
	int x = rand() % 18 + 1, y = rand() % 18 + 1;
public:
    Maze();
    bool validMove(int newX, int newY);
	void printBaseMaze();	//Prints Base Maze with start, walls, end
    void printMazeSteps();
    bool search(int x, int y); // Recursively search from x,y until we find the exit
    void genWalls();
	void updateLoc(int curx, int cury);
};

Maze::Maze()
{	
	// Generate Walls
	for (int i = 0; i < WIDTH; i++) {
		for (int j = 0; j < HEIGHT; j++) {
			if (i == 0 || i == 19 || j == 0 || j == 19) {
				maze[i][j] = 'X';
			}
			else {
				maze[i][j] = ' ';
			}
		}
	}

	foundExit = false;

	// Generate Start
	
	if (maze[x][y] == 'X') {
		while (maze[x][y] == 'X') {
			x = rand() % 18 + 1;
			y = rand() % 18 + 1;
		}
	}
	maze[y][x] = 'S'; // S = Start

	// Initialize visited locations to false
	for (int x = 0; x < WIDTH; x++)
		for (int y = 0; y < HEIGHT; y++)
			visited[y][x] = false;
	visited[y][x] = true;

	genWalls();
}

void Maze::printBaseMaze()	//Prints base maze, start, walls, end
{
	for (int i = 0; i < WIDTH; i++) {
		for (int j = 0; j < HEIGHT; j++) {
			cout << maze[i][j];
		}
		cout << endl;
	}
}

bool Maze::validMove(int newX, int newY)
{
	// Check for going off the maze edges
	if (newX < 0 || newX >= WIDTH)
		return false;
	if (newY < 0 || newY >= HEIGHT)
		return false;
	// Check if target is a wall
	if (maze[newY][newX] == 'X')
		return false;
	// Check if visited
	if (visited[newY][newX])
		return false;
	return true;
}

void Maze::printMazeSteps()
{
	search(x, y);

	for (int i = row - 2; i >= 0; i--) {
		updateLoc(path[i][0], path[i][1]);
		cout << endl;
	}
}

void Maze::updateLoc(int curx, int cury)
{
	for (int y = 0; y < HEIGHT; y++)
	{
		for (int x = 0; x < WIDTH; x++)
		{
			if ((x == curx) && (y == cury))
				cout << "@";
			else
				cout << maze[y][x];
		}
		cout << endl;
	}
}

bool Maze::search(int newx, int newy)
{
	if (maze[newy][newx] == 'E')
		return true;

	foundExit = false;
	visited[newy][newx] = true;
	if (validMove(newx, newy - 1))
		foundExit = search(newx, newy - 1);
	if (!foundExit && (validMove(newx, newy + 1)))
		foundExit = search(newx, newy + 1);
	if (!foundExit && (validMove(newx - 1, newy)))
		foundExit = search(newx - 1, newy);
	if (!foundExit && (validMove(newx + 1, newy)))
		foundExit = search(newx + 1, newy);

	if (foundExit)
	{
		// Grab coordinates of each step
		path[row][0] = newx;
		path[row][1] = newy;
		row += 1;
		return true;
	}
	return false;
}

void Maze::genWalls()
{
	srand(time(NULL));
	int x = rand() % 18 + 1;
	int y = rand() % 18 + 1;

	for (int i = 0; i < 81; i++) {
		x = rand() % 18 + 1;
		y = rand() % 18 + 1;
		if (maze[x][y] == 'X') {
			while (maze[x][y] == 'X') {
				x = rand() % 18 + 1;
				y = rand() % 18 + 1;
			}
			maze[x][y] = 'X';
		}
		else {
			maze[x][y] = 'X';
		}
	}
	if (maze[x][y] == 'X') {
		while (maze[x][y] == 'X') {
			x = rand() % 18 + 1;
			y = rand() % 18 + 1;
		}
	}
	maze[x][y] = 'E';
}

int main()
{
	srand(time(NULL));
	Maze maze;

	maze.printMazeSteps();
}
