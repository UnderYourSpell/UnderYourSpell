// POPE_problem_2.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
using namespace std;

class zipCode
{
private:
    int zipI;
    string barCode;
    int convertZip();
    string convertBar();
public:
    zipCode(int zip);
    zipCode(string bar);
    int getZip();
    string getBar();
};

zipCode::zipCode(int zip)
{
    zipI = zip;
}

zipCode::zipCode(string bar)
{
    barCode = bar;
}

int zipCode::getZip()
{
    zipI = convertZip();
    return zipI;
}

string zipCode::getBar()
{
    barCode = convertBar();
    return barCode;
}

int zipCode::convertZip()
{
    int sums[5];    // To hold 5 digit strings
    int sums2[5];   // To hold the single zip code digit
    int temp = 0, multi = 10000, zipcode = 0;
    for (int i = 1; i < 26; i += 5) {    // Sorts barCode into 5 digit strings and stores into array
        sums[temp] = stoi(barCode.substr(i, 5));


        int sum = 0, temp2 = 0;
        for (int j = 0; j < 5; j++) {   // Converts 5 digit strings into a zip code digit
            if (temp2 == 0) {
                sum += (sums[temp] / 10000 % 10) * 7;
                temp2 += 1;
            }
            else if (temp2 == 1) {
                sum += (sums[temp] / 1000 % 10) * 4;
                temp2 += 1;
            }
            else if (temp2 == 2) {
                sum += (sums[temp] / 100 % 10) * 2;
                temp2 += 1;
            }
            else if (temp2 == 3) {
                sum += (sums[temp] / 10 % 10) * 1;
                temp2 += 1;
            }
            else if (temp2 == 4) {
                sum += (sums[temp] % 10) * 0;
                temp2 += 1;
            }
        }
        if (sum == 11) {    // zip code digit can not be 11, therefore its 0
            sum = 0;
        }
        sums2[temp] = sum;
        temp += 1;
    }

    for (int i = 0; i < 5; i++) {   // Takes every zip code digit and combines into one zip code integer
        zipcode += (sums2[i] * multi);
        multi /= 10;
    }
    return zipcode;
}

string zipCode::convertBar()
{
    int temp = zipI, singleDigit, multi = 10000;
    string barcode = "1";
    for (int i = 0; i < 5; i++) {
        singleDigit = temp / multi; // assign binary numbers to the single digit zip code, found from POSTNET ciphers
        if (singleDigit == 0) {
            barcode += "11000";
        }
        else if (singleDigit == 1) {
            barcode += "00011";
        }
        else if (singleDigit == 2) {
            barcode += "00101";
        }
        else if (singleDigit == 3) {
            barcode += "00110";
        }
        else if (singleDigit == 4) {
            barcode += "01001";
        }
        else if (singleDigit == 5) {
            barcode += "01010";
        }
        else if (singleDigit == 6) {
            barcode += "01100";
        }
        else if (singleDigit == 7) {
            barcode += "10001";
        }
        else if (singleDigit == 8) {
            barcode += "10010";
        }
        else if (singleDigit == 9) {
            barcode += "10100";
        }
        temp = zipI % multi;
        multi /= 10;
    }
    barcode += "1";
    return barcode;
}

int main()
{
    zipCode zip("110100101000101011000010011");
    cout << "Zip Code: " << zip.getZip() << endl;

    zipCode zipbar(99504);
    cout << "Bar Code: " << zipbar.getBar();
}
