// POPE_problem_3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>
using namespace std;

class Movie
{
private:
    string movieTitle;
    string movieRating;
public:
    Movie();
    Movie(string title, string rating);
    string getTitle();
    string getRating();
};

Movie::Movie()
{
}

Movie::Movie(string title, string rating)
{
    movieTitle = title;
    movieRating = rating;
}

string Movie::getTitle()
{
    return movieTitle;
}

string Movie::getRating()
{
    return movieRating;
}

void sortName(string movies[][2])   //function to bubble sort and output the list
{
    string temp;
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 4 - i; j++) {
            if (movies[j][0] > movies[j + 1][0]) {
                temp = movies[j + 1][0];
                movies[j + 1][0] = movies[j][0];
                movies[j][0] = temp;
            }
        }
    }
    for (int i = 0; i < 6; i++) {
        cout << i + 1 << ". " << movies[i][0] << ", " << movies[i][1] << endl;
    }
}


int main()
{
    Movie movieList[6];
    string movies[6][2] = {
        { "Black Panther", "PG - 13" },
        { "Avengers: Infinity War", "PG - 13" },
        { "A Wrinkle In Time", "PG" },
        { "Ready Player One", "PG - 13" },
        { "Red Sparrow", "R" },
        { "The Incredibles 2", "G" },
    };

    for (int i = 0; i < 6; i++) {
        movieList[i] = Movie(movies[i][0], movies[i][1]);
    }
    
    sortName(movies);
}
