/*
 Assignment 1 Problem 2
 Kiera Chase
 CSCE A211
 Dr. Sebastian Neumayer
 February 8, 2023
 */

#include <iomanip>
#include <iostream>
#include <time.h>

using namespace std;

double validate(string name, double upper, double lower = 0) {
    /*
     Prompt user input and check that it falls within a specific range.
     
     Inputs:
        name: name of input to prompt user for
        upper: double of inclusive upper bound
        lower: double of exclusive lower bound
     
     Outputs:
        Print statements to prompt user. Returns a valid user input.
     */
    double user_input;
    
    do {
        cout << "Enter a " << name << ": ";
        cin >> user_input;
        
        if ((user_input <= lower) | (user_input > upper)) {
            cout << "Invalid " << name << ". Try again." << endl;
        }
    } while ((user_input <= lower) | (user_input > upper));
    
    return user_input;
}

int guessAndRoll() {
    /*
     Compares a guess with three simulated dice rolls
     
     Inputs:
        User input from validate()
     
     Outputs:
        Prints dice rolls. Returns number of rolls guessed correctly.
     */
    int guess, roll, success = 0;
    
    // User prompted, inputs variable guess
    guess = validate("number to guess", 7);
    
    // Simulate rolling dice
    cout << "Rolling dice";
    for (int i = 0; i < 3; i++) {
        roll = (rand() % 6) + 1;
        cout << " ... " << roll;
        
        // Check correct guess
        if (roll == guess) {
            success += 1;
        }
    }
    cout << endl;
    
    return success;
}

int main() {
    srand(time(0));
    bool play = true;
    char user_ans;
    double total_money = 100.00, wager;
    
    cout << "You have $" << fixed << setprecision(2) << total_money << endl;
    
    while (play) {
        // Player bets
        wager = validate("wager", total_money);
        
        // Dice rolled, results added to total money
        total_money += wager * (guessAndRoll() - 1);
        cout << "You currently have $" << fixed << setprecision(2) << total_money << endl;
        
        // Check to play again
        if (total_money <= 0) {
            play = false;
            break;
        }
        cout << "Would you like to play again (y/n)? ";
        cin >> user_ans;
        if ((user_ans == 'N') | (user_ans == 'n')) {
            play = false;
        }
    }
    
    cout << "You ended with $" << fixed << setprecision(2) << total_money << endl;
}
