Assignment 1 README 
Kiera Chase  
CSCE A211  
Dr. Sebastian Neumayer  
February 8, 2023 
 
 
Problem 1:  
 
In folder CHASE_problem_1 named CHASE_problem_1.cpp 
 
Reads in inputs from data file enrollments.txt and compares the distribution of leading digits with the distribution predicted in Bedford's Law. 
 
Run the program in Linux using "./a.out < enrollments.txt" to input the data. The file enrollments.txt can be found in ~sjneumayer/CSCE_A211 on ruminant.duckdns.org. Both CHASE_problem_1.cpp and enrollments.txt must be in the same folder to run. 
 
No known issues. 
 
 
Problem 2: 
 
In folder CHASE_problem_2 named CHASE_problem_2.cpp 
 
Simulates the game Chuck-a-luck, starting the user with $100. 
 
This program should run in any IDE that works for C++. The program requires input as the user plays along with the game. 
 
No known issues. 
 
 
Problem 3: 
 
In folder CHASE_problem_3 named CHASE_problem_3.txt 
 
Text file containing answers to questions about 2D mazes. 
 
No program to run. 
 
No known issues. 
 
 
Problem 3: 
 
In folder CHASE_problem_4 named CHASE_problem_4.cpp 
 
Generates three random amounts of cents, and converts it to amounts of coins. 
 
This program should run in any IDE that works for C++. 
 
No known issues. 
