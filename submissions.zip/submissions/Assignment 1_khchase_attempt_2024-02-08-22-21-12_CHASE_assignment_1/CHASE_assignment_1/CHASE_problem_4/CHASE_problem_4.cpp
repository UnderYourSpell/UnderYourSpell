/*
 Assignment 1 Problem 4
 Kiera Chase
 CSCE A211
 Dr. Sebastian Neumayer
 February 8, 2023
 */

#include <iostream>
#include <time.h>

using namespace std;

void toCoins(int change, int &quarters, int &dimes, int &nickels, int &pennies) {
    /*
     Converts an amount to change (1-99 cents) to specific coin counts.
     
     Inputs:
        change: int amount of change
        quarters: int number of quarters passed by reference
        dimes: int number of dimes passed by reference
        nickels: int number of nickels passed by reference
        pennies: int number of pennies passed by reference
     
     Outputs:
        Returns void. Inputs passed by reference are changed.
     */
    if ((change < 1) | (change > 99)) {
        cout << "Invalid amount of change: ";
        return;
    }
    
    quarters = change / 25;
    dimes = (change % 25) / 10;
    nickels = ((change % 25) % 10) / 5;
    pennies = ((change % 25) % 10) % 5;
}

int main() {
    srand(time(0));
    int change, quarters, dimes, nickels, pennies;
    
    for (int i = 0; i < 3; i++) {
        change = rand() % 99 + 1;
        toCoins(change, quarters, dimes, nickels, pennies);
        cout << change << " cents dispenses as " << quarters << " quarters, " << dimes << " dimes, " << nickels << " nickels, and " << pennies << " pennies." << endl;
    }
}
