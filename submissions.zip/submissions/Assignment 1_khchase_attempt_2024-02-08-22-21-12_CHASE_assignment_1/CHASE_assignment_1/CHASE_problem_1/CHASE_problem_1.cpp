/*
 Assignment 1 Problem 1
 Kiera Chase
 CSCE A211
 Dr. Sebastian Neumayer
 February 8, 2023
 */

#include <iomanip>
#include <iostream>

using namespace std;

int firstDigit(int x) {
    /*
     Finds the leading digit of an integer by recursively eliminating last digit.
     
     Inputs:
        x: int to find leading digit of
     
     Outputs:
        Ends recursion by returning the leading digit of input x.
        
     */
    if (x / 10 >= 1) {
        return firstDigit(x / 10);
    }
    else {
        return x;
    }
}

void benfordsLaw(int a[], int n) {
    /*
     Compares a distribution of digits to Bedford's Law.
     
     Inputs:
        a[]: int array of size 10 containing the number of each leading digit in a dataset at that index
        n: the total number of data points in the dataset
     
     Outputs:
        Prints the distributions of leading digits from Bedford's law and the input data.
     */
    cout << "Leading digit : Predicted distribution : Actual distribution" << endl;
    
    double b[] = {0, 0.301, 0.176, 0.125, 0.097, 0.079, 0.067, 0.058, 0.051, 0.046};
    
    for (int i = 1; i < 10; i++) {
        cout << i << " : " << b[i] << " : ";
        cout << fixed << setprecision(3) << a[i] / (n * 1.0) << endl;
    }
}

int main() {
    int num, first;
    int digits[10] = {0};
    
    // Count number of each leading digit
    for (int i = 0; i < 3295; i++) {
        cin >> num;
        first = firstDigit(num);
        
        digits[first] += 1;
    }
    
    // Print distribution of digits
    benfordsLaw(digits, 3295);
    
}
