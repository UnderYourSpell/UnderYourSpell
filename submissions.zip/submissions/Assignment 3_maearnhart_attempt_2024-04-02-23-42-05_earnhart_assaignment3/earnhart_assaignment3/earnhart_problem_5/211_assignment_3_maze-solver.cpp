// maze-solver.cpp
//
// This program fills in a maze with random positions and then runs the solver to solve it.
// The moves are saved in two arrays, which store the X/Y coordinates we are moving to.
// They are output in main in forward order.
//
#include <iostream>
#include <ctime>
#include <cstdlib>
#include "Maze.h"
using namespace std;



// Function prototypes
bool validMove(char maze[][WIDTH], bool visited[][WIDTH],
               int newX, int newY);
bool move(char maze[][WIDTH], bool visited[][WIDTH],
          int &curX, int &curY, int newX, int newY);
// *** New function, see below
void addToArrays(int x[], int y[], int &numEntries, int xVal, int yVal);



// This new function adds two numbers to the arrays and increments the count of how many
// numbers have been added. It assumes the arrays have been created big enough to not
// have overflow. It is used to remember the coordinates of our solution.
void addToArrays(int x[], int y[], int &numEntries, int xVal, int yVal)
{
   x[numEntries] = xVal;
   y[numEntries] = yVal;
   numEntries++;
}

// Return true or false if moving to the specified coordinate is valid
// Return false if we have been to this cell already
bool validMove(char maze[][WIDTH], bool visited[][WIDTH],
               int newX, int newY)
{
 // Check for going off the maze edges
 if (newX < 0 || newX >= WIDTH)
	return false;
 if (newY < 0 || newY >= HEIGHT)
	return false;
 // Check if target is a wall
 if (maze[newY][newX]=='X')
	return false;
 // Check if visited
 if (visited[newY][newX])
	return false;
 return true;
}

// Make the move on the maze to move to a new coordinate
// I passed curX and curY by reference so they are changed to
// the new coordinates.  Here we assume the move coordinates are valid.
// This returns true if we move onto the exit, false otherwise.
// Also update the visited array.
bool move(char maze[][WIDTH], bool visited[][WIDTH],
	  int &curX, int &curY, int newX, int newY)
{
  bool foundExit = false;
  if (maze[newY][newX]=='E') 	// Check for exit
	foundExit = true;
  curX = newX;			// Update location
  curY = newY;
  visited[curY][curX] = true;
 
  return foundExit;
}


int main()
{
	Maze M1;

	const int WIDTh = 20;
	const int HEIGHt = 20;
 

 // Here I created arrays to store the x/y coordinates for the path of our solution.
 // The array is of size [HEIGHT-2]*[WIDTH-2] since we'll never exceed that size.
 // I also made a variable to count how many entries we make..
 // It would probably be more convenient to make a class to store this data rather than
 // have two separate arrays!
 int solutionX[(HEIGHt-2)*(WIDTh-2)], solutionY[(HEIGHt-2)*(WIDTh-2)];
 int numPoints = 0;

 bool found = M1.solveMaze(M1.getStartX(), M1.getStartY(), solutionX, solutionY, numPoints);
 if (!found)
 {
	 cout << "No solution found.";
 }
 else
 {
	cout << "Solution found!  Here is the path from the start." << endl;
	for (int i = numPoints - 1; i >= 0; i--)
	{
		M1.printMaze(solutionX[i], solutionY[i]);
		cout << endl;
 	}
 }

 return 0;
}
