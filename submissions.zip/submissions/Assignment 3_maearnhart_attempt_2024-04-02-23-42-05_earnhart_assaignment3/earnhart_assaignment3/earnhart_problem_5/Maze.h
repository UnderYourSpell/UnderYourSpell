#pragma once
using namespace std;

const int HEIGHT = 20;
const int WIDTH = 20;

class Maze
{
private:
	char maze[HEIGHT][WIDTH];
	bool visited[HEIGHT][WIDTH];
	int exit_x, exit_y;
	int start_x, start_y;
public:
	Maze();
	int getStartX();
	int getStartY();
	void initializeMaze();
	void printMaze(int curx, int cury);
	bool solveMaze(int x, int y, int solutionX[], int solutionY[], int& numEntries);
};
