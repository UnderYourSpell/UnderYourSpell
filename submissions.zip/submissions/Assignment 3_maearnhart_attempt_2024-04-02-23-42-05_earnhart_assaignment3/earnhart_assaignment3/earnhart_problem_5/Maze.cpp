#include <iostream>
#include <ctime>
#include <cstdlib>
#include "Maze.h"

using namespace std;

Maze::Maze()
{
	initializeMaze();
}

void Maze::initializeMaze()
{
	// Seed random number generator with clock time
	srand(time(NULL));

	/****************
	 Programmatically fill out the maze with ***'s on the borders and spaces in the middle
	 ****************/
	 // All blank
	for (int x = 0; x < WIDTH; x++)
		for (int y = 0; y < HEIGHT; y++)
			maze[y][x] = ' ';
	// Borders with X
	for (int x = 0; x < WIDTH; x++)
	{
		maze[0][x] = 'X';
		maze[HEIGHT - 1][x] = 'X';
	}
	for (int y = 0; y < HEIGHT; y++)
	{
		maze[y][0] = 'X';
		maze[y][WIDTH - 1] = 'X';
	}

	// ***** Randomly fill in 25% of the middle
	int numCells = static_cast<int>((HEIGHT - 2) * (WIDTH - 2) * 0.25);
	int count = 0;
	while (count < numCells)
	{
		int x = (rand() % (WIDTH - 2)) + 1;
		int y = (rand() % (HEIGHT - 2)) + 1;
		if (maze[y][x] == ' ')
		{
			maze[y][x] = 'X';
			count++;
		}
	}

	// ***** Pick a random start and end that is not a wall *****
	int x = (rand() % (WIDTH - 2)) + 1;
	int y = (rand() % (HEIGHT - 2)) + 1;
	while (maze[y][x] == 'X')
	{
		start_x = (rand() % (WIDTH - 2)) + 1;
		start_y = (rand() % (HEIGHT - 2)) + 1;
	}
	// At this point, (x,y) contains our start position
	// ***** Pick a random end position that is not a wall *******
	int exitX = (rand() % (WIDTH - 2)) + 1;
	int exitY = (rand() % (HEIGHT - 2)) + 1;
	while (maze[exitY][exitX] == 'X')
	{
		exitX = (rand() % (WIDTH - 2)) + 1;
		exitY = (rand() % (HEIGHT - 2)) + 1;
	}
	maze[exitY][exitX] = 'E';

	bool visited[HEIGHT][WIDTH];

	// Initialize visited locations to false
	for (int x = 0; x < WIDTH; x++)
	{
		for (int y = 0; y < HEIGHT; y++)
		{
			visited[y][x] = false;
		}
	}
	visited[start_y][start_x] = true;

}

void Maze::printMaze(int curx, int cury)
{
	{
		for (int y = 0; y < HEIGHT; y++)
		{
			for (int x = 0; x < WIDTH; x++)
			{
				if ((x == curx) && (y == cury))
					cout << "@";
				else
					cout << maze[y][x];
			}
			cout << endl;
		}
	}
}

bool Maze::solveMaze(int x, int y, int solutionX[], int solutionY[], int& numEntries)
{
	int x, int y,
		int solutionX[], int solutionY[], int& numEntries)
		{
			bool foundExit = false;

			if (maze[y][x] == 'E')
				return true;
			visited[y][x] = true;
			if (validMove(maze, visited, x, y - 1))
				foundExit = search(maze, visited, x, y - 1, solutionX, solutionY, numEntries);
			if (!foundExit && (validMove(maze, visited, x, y + 1)))
				foundExit = search(maze, visited, x, y + 1, solutionX, solutionY, numEntries);
			if (!foundExit && (validMove(maze, visited, x - 1, y)))
				foundExit = search(maze, visited, x - 1, y, solutionX, solutionY, numEntries);
			if (!foundExit && (validMove(maze, visited, x + 1, y)))
				foundExit = search(maze, visited, x + 1, y, solutionX, solutionY, numEntries);

			if (foundExit)
			{
				// Remember coordinates we found the exit in the solution arrays
				addToArrays(solutionX, solutionY, numEntries, x, y);
				return true;
			}
			return false;
}

	int Maze::getStartX()
	{
		return start_x;
	}

	int Maze::getStartY()
	{
		return start_y;
	}