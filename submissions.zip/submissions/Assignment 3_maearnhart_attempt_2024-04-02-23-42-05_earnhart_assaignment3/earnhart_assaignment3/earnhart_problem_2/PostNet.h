#pragma once
#include <string>
using namespace std;
class Code
{
private:
	int zip;
public:
	int getInt();
	string getBar();
	int bar_conv(string bar);
	Code(int code);
	Code(string bar);
	string int_conv(int z);
};