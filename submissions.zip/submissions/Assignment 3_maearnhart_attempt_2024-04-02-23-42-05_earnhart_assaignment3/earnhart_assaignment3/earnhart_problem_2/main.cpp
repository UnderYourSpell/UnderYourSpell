#include <iostream>
#include "PostNet.h"

using namespace std;

int main()
{
	Code c1(99501);
	cout << c1.getInt() << endl;
	Code c2("110100101000101011000010011");
	cout << c2.getInt();
	cout << c2.getBar();
}