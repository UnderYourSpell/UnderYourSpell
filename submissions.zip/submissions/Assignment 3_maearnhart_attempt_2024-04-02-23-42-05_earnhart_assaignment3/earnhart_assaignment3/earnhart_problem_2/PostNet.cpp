#include <iostream>
#include <string>
#include "PostNet.h"

using namespace std;

int Code::getInt()
{
	return zip;
}

string Code::getBar()
{
	string bar = "1";
	bar = bar + int_conv(zip / 10000);
	bar = bar + int_conv((zip % 10000) / 1000);
	bar = bar + int_conv((zip % 1000) / 100);
	bar = bar + int_conv((zip % 100) / 10);
	bar = bar + int_conv(zip % 10);
	bar = bar + "1";
	return bar;
}

Code::Code(int code)
{
	zip = code;
}

Code::Code(string bar)
{
	zip = bar_conv(bar);
}

int Code::bar_conv(string bar)
{
	int zip = 0;
	string dummy;
	int k = 4;
	for (int i = 1; i < 22; i += 5)
	{
		dummy = bar.substr(i, 5);
		int x = 0;
		if (dummy == "11000")
		{
			x = 0;
		}
		else if (dummy == "00011")
		{
			x = 1;
		}
		else if (dummy == "00101")
		{
			x = 2;
		}
		else if (dummy == "00110")
		{
			x = 3;
		}
		else if (dummy == "01001")
		{
			x = 4;
		}
		else if (dummy == "01010")
		{
			x = 5;
		}
		else if (dummy == "01100")
		{
			x = 6;
		}
		else if (dummy == "10001")
		{
			x = 7;
		}
		else if (dummy == "10010")
		{
			x = 8;
		}
		else if (dummy == "10100")
		{
			x = 9;
		}

		zip += x * pow(10, k);
		k -= 1;
	}
	return zip;
}

string Code::int_conv(int z) 
{
	if (z == 0)
	{
		return "11000";
	}
	else if (z == 1)
	{
		return "00011";
	}
	else if (z == 2)
	{
		return "00101";
	}
	else if (z == 3)
	{
		return "00110";
	}
	else if (z == 4)
	{
		return "01001";
	}
	else if (z == 5)
	{
		return "01010";
	}
	else if (z == 6)
	{
		return "01100";
	}
	else if (z == 7)
	{
		return "10001";
	}
	else if (z == 8)
	{
		return "10010";
	}
	else if (z == 9)
	{
		return "10100";
	}
}

