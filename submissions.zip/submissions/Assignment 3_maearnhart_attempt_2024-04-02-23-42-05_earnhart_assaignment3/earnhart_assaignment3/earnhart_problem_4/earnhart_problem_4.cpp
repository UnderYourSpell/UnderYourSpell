#include <iostream>
#include <string>
#include <fstream>

using namespace std;

int main()
{
string test;
int data[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};

ifstream file("testNumbers.txt");

if (!file.is_open())
{
    cout << "failed to open file" << endl;
    return 1;
}

while(file >> test)
{
    int num = test.at(0) - '0';
    if(num >= 1 && num <= 9)
    {
        data[num - 1]++;
    }
}

for(int j = 1; j < 10; ++j)
{
    cout << j << ": " << data[j - 1] << endl;
}

file.close();

return 0;

}
