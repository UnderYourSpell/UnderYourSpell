#pragma once
#include <string>
using namespace std;
class Movie
{
private:
	string name;
	int rating;
public:
	Movie();
	Movie(string name, int r);
	string getRating();
	string getName();
};