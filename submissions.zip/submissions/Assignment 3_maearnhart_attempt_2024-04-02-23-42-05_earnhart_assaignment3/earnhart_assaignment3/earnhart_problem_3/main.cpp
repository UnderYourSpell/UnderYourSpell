#include "Movie.h"
#include <iostream>

using namespace std;

void Sort(Movie films[], int size)
{
	for (int i = 0; i < size - 1; ++i)
	{
		for (int j = 0; j < size - 1 - i; ++j)
		{
			if (films[j].getName() > films[j + 1].getName())
			{
				Movie dummy = films[j];
				films[j] = films[j + 1];
				films[j + 1] = dummy;
			}
		}
	}
}

int main()
{
	Movie films[] = { Movie("Black Panther", 2), Movie("Avengers: Infinity War", 2), Movie("A Wrinkle In Time", 1), Movie("Ready Player One", 2), Movie("Red Sparrow", 3), Movie("The Incredibles 2", 0) };

	cout << "Pre Sort:" << endl;

	for (int i = 0; i < 6; i++)
	{
		cout << films[i].getName() << ", " << films[i].getRating() << endl;
	}

	Sort(films, 6);

	cout << "Post Sort: " << endl;

	for (int i = 0; i < 6; i++)
	{
		cout << films[i].getName() << ", " << films[i].getRating() << endl;
	}
}