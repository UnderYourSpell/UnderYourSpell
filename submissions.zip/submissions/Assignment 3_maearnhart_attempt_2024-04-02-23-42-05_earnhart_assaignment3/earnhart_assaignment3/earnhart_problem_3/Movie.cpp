#include "Movie.h"

Movie::Movie()
{
	name = "Untitled";
	rating = 0;
}

Movie::Movie(string name, int r)
{
	this->name = name;
	rating = r;
}

string Movie::getName()
{
	return name;
}

string Movie::getRating()
{
	if (rating == 0)
	{
		return "G";
	}
	else if (rating == 1)
	{
		return "PG";
	}
	else if (rating == 2)
	{
		return "PG-13";
	}
	else if (rating == 3)
	{
		return "R";
	}
}