#include <iostream>
using namespace std;

void change(int money_amount, int& q, int& d, int& n, int& p);

int main() {
	int quarters = 0, dimes = 0, nickels = 0, pennies = 0; 


	//Test Case 1
	change(85, quarters, dimes, nickels, pennies);
	cout << "Change for: " << 85 << ", quarters: " << quarters << ", dimes: " << dimes << ", nickels: " << nickels << ", pennies: " << pennies << endl; 

	//Test Case 2
	change(99, quarters, dimes, nickels, pennies);
	cout << "Change for: " << 99 << ", quarters: " << quarters << ", dimes: " << dimes << ", nickels: " << nickels << ", pennies: " << pennies << endl;

	//Test Case 3
	change(1, quarters, dimes, nickels, pennies);
	cout << "Change for: " << 1 << ", quarters: " << quarters << ", dimes: " << dimes << ", nickels: " << nickels << ", pennies: " << pennies << endl;

	//Test Case 4
	change(41, quarters, dimes, nickels, pennies);
	cout << "Change for: " << 41 << ", quarters: " << quarters << ", dimes: " << dimes << ", nickels: " << nickels << ", pennies: " << pennies << endl;

}

void change(int money_amount, int &q, int &d, int &n, int &p) {
	q = money_amount / 25;
	money_amount %= 25; //updates the amount of money to show that the quarters have been subtracted
	d = money_amount / 10;
	money_amount %= 10;
	n = money_amount / 5;
	money_amount %= 5;
	p = money_amount / 1;
	return;
}