#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

void roll_dice(int &r, int &n);

int main() {

	int money = 100;
	
	while (money > 0) {
		
		
		int roll_match = 0;

		//initializes a wager
		int w;
		cout << "Currently you have " << money << " dollars. Enter a wager amount that does not surpass that amount of money you have." << endl; 
		cin >> w; 
		if (w > money) {
			cout << "Currently you have " << money << " dollars. Enter a wager amount that does not surpass that amount of money you have." << endl;
			cin >> w;
		}

		//initalizes a number 
		int n;
		cout << "Input a number between 1 - 6" << endl;
		cin >> n;

		//checks to see if n is inbetween 1 and 6
		if (n > 6 || n < 1) {
			cout << "Input a number between 1 - 6" << endl;
			cin >> n;
		}

		roll_dice(roll_match, n);

		//no matches, loses money
		if (roll_match == 0) {
			money -= w; 
		}

		//1 match, gambler wins wager back
		else if (roll_match == 1) {
			money = money + w; 
		}

		//2 matches, gambler wins twice the wager
		else if (roll_match == 2) {
			money = money + (w * 2); 
		}

		//3 matches, gambler wins three times the wager
		else
			money = money + (w * 3); 
		}
	cout << "You are now out of money and have lost the game :(" << endl;
	}	

void roll_dice(int &r, int &n) {
	//rolling the dice
	srand(time(NULL));
	int arr[3] = { 0 };
	for (int i = 0; i < 3; i++) {
		arr[i] = rand() % 7 + 1;
		
	}
	for (int i = 0; i < 3; i++) {
		if (arr[i] == n) {
			r++;
		}
	
	}
	cout << "The numbers you rolled were: " << arr[0] << " " << arr[1] << " " << arr[2] << endl;
}
