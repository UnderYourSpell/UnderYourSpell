#include <iostream>
using namespace std;

int main(){

int nums_count[10] = {0};
string strnum
;
for(int i = 0; i < 3295; i++){
	cin >> strnum; 
	int num = stoi(strnum[0]); 
	nums_count[num]++; 	
	
}

for(int i = 0; i < 10; i++){
	cout >> "There was" >> nums_count[i] >> "numbers starting with" >> i >> "in enrollments.txt" >> endl;
}
return 0; 
}
