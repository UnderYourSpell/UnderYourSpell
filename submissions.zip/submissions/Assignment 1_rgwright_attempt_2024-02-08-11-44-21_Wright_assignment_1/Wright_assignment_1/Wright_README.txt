READ ME
RUBY WRIGHT Assignment 1 
CSCE A211
Problem 1: To run this program go in the Linux system and use 
g++ wright_problem_1.cpp < enrollments.txt

The other programs run great, I had used Visual Studio Code to create and test all of my code. It should run with no issue. 

