﻿Hannah Trotter 
CSCE A211 
Assignment 1 
READ ME 
2/8/23


Problem 1 
* Instructions to run…
   * “g++ Trotter_problem_1.cpp” then “./a.out < enrollments.txt”
* Enrollments.txt is also in Trotter_problem_1 folder




Problem 2
* Instructions to run… 
   * “g++ Trotter_problem_2.cpp” then “./a.out”






Problem 3
* This problem did not require any code. Txt file in Trotter_problem_3 folder with answer.


Problem 4
* Instructions to run…
   * “g++ Trotter_problem_4.cpp” then “./a.out”
* Program is set to test (77) and (93)