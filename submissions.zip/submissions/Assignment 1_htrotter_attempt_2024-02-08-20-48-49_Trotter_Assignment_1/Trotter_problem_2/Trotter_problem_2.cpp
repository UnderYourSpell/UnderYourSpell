//
//  Trotter_problem_2.cpp
//  CSCE A211 Assignment 1
//
//  Created by Hannah Trotter on 2/7/24.
//

#include <iostream>
using namespace std;

int check(int w, int m);
int checkNum(int N);

int main(){
   
    // srand(time(0)) to make everything truly random
    srand(time(0));
    
    // create variables used in program
    int money = 100;
    int W;
    int n;
    char choice = 'Y';
    int roll1, roll2, roll3;
    int count = 0;
    
    
    while (choice == 'Y'){
        
        // display money, prompt and test wager
        cout << "You have $" << money << endl;
        cout << "Place your wager: ";
        cin >> W;
        W = check(W, money);
        money = money - W;
        
        // prompt and test number
        cout << "Pick your number (1 - 6): ";
        cin >> n;
        n = checkNum(n);
        
        // "rolls" three dice and displays rolls
        cout << "rolling... " << endl;;
        roll1 = rand() % 6 + 1;
        roll2 = rand() % 6 + 1;
        roll3 = rand() % 6 + 1;
        cout << roll1 << endl << roll2 << endl << roll3 << endl;
        
        // determines if gambler wins and displays and adds correct amount of money and gives gambler choice to keep playing (if money > 0)
        if (roll1 == n){
            count++;
        }
        if (roll2 == n){
            count++;
        }
        if (roll3 == n){
            count++;
        }
        
        // no matches
        if (count == 0){
            cout << "No matches... you loose" << endl;
            cout << "Money: " << money << endl;
            if (money == 0){
                choice = 'N';
                cout << "No more money... game over" << endl;
            }
            else {
                cout << "Play again (Y or N): ";
                cin >> choice;
            }
        }
        
        // one match
        if (count == 1){
            cout << "1 match... you break even" << endl;
            money = money + W;
            cout << "Money: " << money << endl;
            if (money == 0){
                choice = 'N';
                cout << "No more money... game over" << endl;
            }
            else {
                cout << "Play again (Y or N): ";
                cin >> choice;
            }
        }
        
        // two matches
        if (count == 2){
            cout << "2 matches... you win" << endl;
            money = money + (2 * W);
            cout << "Money: " << money << endl;
            if (money == 0){
                choice = 'N';
                cout << "No more money... game over" << endl;
            }
            else {
                cout << "Play again (Y or N): ";
                cin >> choice;
            }
        }
        
        // three matches
        if (count == 3){
            cout << "3 matches... you win big" << endl;
            money = money + (3 * W);
            cout << "Money: " << money << endl;
            if (money == 0){
                choice = 'N';
                cout << "No more money... game over" << endl;
            }
            else {
                cout << "Play again (Y or N): ";
                cin >> choice;
            }
        }
        
        // reset count to 0
        count =0;
        
    }
    
    // display ending money 
    cout << "You ened with $" << money << endl;
}

// tests to make sure gambler has enough money to wager
int check(int w, int m){
    
    if((w > 0) && (w <= m)){
        return w;
    }
    else {
        cout << "Invalid wager. Enter a new wager: ";
        cin >> w;
        check(w, m);
    }

    return w;
}

// checks to make sure n is a number 1-6
int checkNum(int N){
    
    if ((N > 0) && (N < 7)){
        return N;
    }
    else{
        cout << "Invalid number. Enter a new number (1 - 6): ";
        cin >> N;
        checkNum(N);
    }
    
    return N;
}

