//
//  Trotter_problem_1.cpp
//  CSCE A211 Assignment 1
//
//  Created by Hannah Trotter on 2/7/24.
//

#include <iostream>
using namespace std;

int main(){
  
    // array for starting digit
    int countArray[9] = {0};
    
    // gets 3295 inputs and adds into countArray based on starting digit
    for (int i = 0; i < 3295; i++){
    
        int num;
        cin >> num;
        
        // gets starting digit
        while (num > 10) {
            num = num / 10;
        }
        
        countArray[num - 1]++;
    }
    
    // outputs countArray values
    for (int i = 0; i < 9; i++){
        cout << "Being with " << i + 1 << " : "<< (double)countArray[i]/3295 * 100  << "%" << endl;
    }
    
}

