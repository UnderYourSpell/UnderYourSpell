//
//  Trotter_problem_4.cpp
//  CSCE A211 Assignment 1
//
//  Created by Hannah Trotter on 2/7/24.
//

#include <iostream>
using namespace std;


void change(int N, int& q, int& d, int& n, int& p);

int main(){
   
    // variables for first number
    int num1 = 77;
    int quarters1 = 0;
    int dimes1 = 0;
    int nickels1 = 0;
    int pennies1 = 0;
    
    // variables for second number
    int num2 = 93;
    int quarters2 = 0;
    int dimes2 = 0;
    int nickels2 = 0;
    int pennies2 = 0;
    
    // calling change for first number
    change(num1, quarters1, dimes1, nickels1, pennies1);
    
    // displaying change needed
    cout << "For $0." << num1 << " you will need: "  << endl << quarters1 << " quarters" << endl << dimes1 << " dimes" << endl << nickels1 << " nickels" << endl << pennies1 << " pennies" << endl;
    
    // calling change for second number
    change(num2, quarters2, dimes2, nickels2, pennies2);
    
    // displaying change needed
    cout << "For $0." << num2 << " you will need: "  << endl << quarters2 << " quarters" << endl << dimes2 << " dimes" << endl << nickels2 << " nickels" << endl << pennies2 << " pennies" << endl;
}

// calculated number of chnage needed for N (passed by reference)
void change(int N, int& q, int& d, int& n, int& p){
    
    int temp;
    // quarters
    q = N / 25;
    temp = N % 25;
    // dimes
    d = temp / 10;
    temp = temp % 10;
    // nickels
    n = temp / 5;
    temp = temp % 5;
    // pennies
    p = temp;
    
}

