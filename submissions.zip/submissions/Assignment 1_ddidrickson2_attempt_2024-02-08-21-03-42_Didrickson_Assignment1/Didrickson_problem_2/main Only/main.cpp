#include <iostream>
#include <cstdlib>
#include <time.h>

using namespace std;

int calculateRolls(int n) {
    int roll = 0;
    int matches = 0;
    for (int i = 0; i < 3; i++) {
        roll = ((rand() % 6) + 1);
        cout << "You rolled a " << roll << endl;
        if (roll == n) {
            matches++;
        }
    }
    return matches;
}

int calculateReward(int matches, int wager) {
    if (matches == 0) {
        cout << "No luck...\n";
        return 0;
    }
    else if (matches == 1) {
        cout << "You receive your wager back.\n";
        return wager;
    }
    else if (matches == 2) {
        cout << "You doubled your wager! Your reward is $" << (wager*2) << ".\n";
        return wager*2;
    }
    else if (matches == 3) {
        cout << "Big winner! You tripled your wager! Your reward is $" << (wager*3) << ".\n";
        return wager*3;
    } else {
        cout << "Something went wrong.\n";
        return 0;
    }
}

int main() {
    int money = 100;
    int wager = 1;
    bool stillPlaying = true;
    
    srand(time(0));
    
    while (money > 0 && stillPlaying) {
        int n = 0; // Gambler's number
        char playAgain = 'y';
        cout << "You have $" << money << " available.\nEnter your wager: $";
        cin >> wager;
        if (wager > money) {
            cout << "Sorry, you do not have enough money to make this bet. Enter a wager less then $" << money << ".\n";
            continue;
        }
        money -= wager;
        while (n < 1 || n > 6) {
            cout << "Enter a number from 1 to 6: ";
            cin >> n;
            if (n < 1 || n > 6) {
                cout << "Your bet must be between 1 and 6. Try again.\n";
            }
        }
        cout << "Rolling three dice..." << endl;
        int matches = calculateRolls(n);
        cout << matches << " matches.\n";
        money += calculateReward(matches, wager);
        if (money > 0) {
            cout << "Play again? Enter y/n >> ";
            cin >> playAgain;
            if (playAgain == 'n') {
                stillPlaying = false;
            }
        } else {
            cout << "You have no money remaining. Game over...";
        }
    }
    
    return 0;
}
