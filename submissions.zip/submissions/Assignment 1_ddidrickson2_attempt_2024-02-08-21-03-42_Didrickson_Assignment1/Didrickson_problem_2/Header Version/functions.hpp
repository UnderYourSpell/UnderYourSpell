int calculateRolls(int n);
int calculateReward(int matches, int wager);
