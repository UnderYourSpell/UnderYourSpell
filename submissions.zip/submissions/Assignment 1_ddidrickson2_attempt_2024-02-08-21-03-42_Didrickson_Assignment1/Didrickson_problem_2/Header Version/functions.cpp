#include <iostream>
#include <cstdlib>
#include <time.h>
#include "functions.hpp"

using namespace std;

int calculateRolls(int n) {
    int roll = 0;
    int matches = 0;
    for (int i = 0; i < 3; i++) {
        roll = ((rand() % 6) + 1);
        cout << "You rolled a " << roll << endl;
        if (roll == n) {
            matches++;
        }
    }
    return matches;
}

int calculateReward(int matches, int wager) {
    if (matches == 0) {
        cout << "No luck...\n";
        return 0;
    }
    else if (matches == 1) {
        cout << "You receive your wager back.\n";
        return wager;
    }
    else if (matches == 2) {
        cout << "You doubled your wager! Your reward is $" << (wager*2) << ".\n";
        return wager*2;
    }
    else if (matches == 3) {
        cout << "Big winner! You tripled your wager! Your reward is $" << (wager*3) << ".\n";
        return wager*3;
    } else {
        cout << "Something went wrong.\n";
        return 0;
    }
}
