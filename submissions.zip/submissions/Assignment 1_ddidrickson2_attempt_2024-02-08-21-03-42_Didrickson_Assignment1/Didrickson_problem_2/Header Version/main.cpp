#include <iostream>
#include <cstdlib>
#include <time.h>
#include "functions.hpp"

using namespace std;

int main() {
    int money = 100;
    int wager = 1;
    bool stillPlaying = true;
    
    srand(time(0));
    
    while (money > 0 && stillPlaying) {
        int n = 0; // Gambler's number
        char playAgain = 'y';
        cout << "You have $" << money << " available.\nEnter your wager: $";
        cin >> wager;
        if (wager > money) {
            cout << "Sorry, you do not have enough money to make this bet. Enter a wager less then $" << money << ".\n";
            continue;
        }
        money -= wager;
        while (n < 1 || n > 6) {
            cout << "Enter a number from 1 to 6: ";
            cin >> n;
            if (n < 1 || n > 6) {
                cout << "Your bet must be between 1 and 6. Try again.\n";
            }
        }
        cout << "Rolling three dice..." << endl;
        int matches = calculateRolls(n);
        cout << matches << " matches.\n";
        money += calculateReward(matches, wager);
        if (money > 0) {
            cout << "Play again? Enter y/n >> ";
            cin >> playAgain;
            if (playAgain == 'n') {
                stillPlaying = false;
            }
        } else {
            cout << "You have no money remaining. Game over...";
        }
    }
    
    return 0;
}
