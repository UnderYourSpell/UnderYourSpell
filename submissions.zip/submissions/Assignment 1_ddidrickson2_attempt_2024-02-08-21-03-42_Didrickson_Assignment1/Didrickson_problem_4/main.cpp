#include <iostream>

using namespace std;

void calculateChange(int change, int &quarters, int &dimes, int &nickels, int &pennies) {
    while (change > 0) {
        if (change >= 25) {
            quarters++;
            change -= 25;
        } else if (change >= 10) {
            dimes++;
            change -= 10;
        } else if (change >= 5) {
            nickels++;
            change -= 5;
        } else if (change >= 1) {
            pennies++;
            change--;
        }
    }
}

int main() {
    int change = 0;
    int quarters = 0;
    int dimes = 0;
    int nickels = 0;
    int pennies = 0;
    
    while (change > 99 || change < 1) {
        cout << "Enter change in cents to dispense: ";
        cin >> change;
        if (change > 99 || change < 1) {
            cout << "Please enter an integer from 1-99\n";
        }
    }
    calculateChange(change, quarters, dimes, nickels, pennies);
    cout << pennies << " pennies\n" << nickels << " nickels\n" << dimes << " dimes\n" << quarters << " quarters\n";
}
