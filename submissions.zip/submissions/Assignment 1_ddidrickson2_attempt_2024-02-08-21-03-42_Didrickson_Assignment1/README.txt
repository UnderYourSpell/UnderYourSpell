//
//  Assignment 1
//  Dylan Didrickson
//

There are 4 folders, with each containing the problem as labeled.

Problem 1 can be compiled using "g++ main.cpp" on a unix system
With the file you want to check in the same folder, type
"./a.out < enrollments.txt"
or insert your own file name.

Problem 2 can be compiled using the command
"g++ main.cpp functions.hpp functions.cpp" on a unix system.
The version without headers only needs "g++ main.cpp". As I had prior experience
with headers I elected to move functions out of main to keep things clean.
However, upon reading the submission instructions, it seemed like I was
only supposed to have .cpp files. So to solve any potential issues I
simply created both one with and without a header file.

To run on a unix system, use "./a.out".

To play, enter a wager that's higher than 1, but less or equal to your current money.
Then, enter a number to bet on. Three dice will roll. The payouts are as follows.

Matching Die  |  Payout
--------------------------
     0        |    0
     1        | 1x wager
     2        | 2x wager
     3        | 3x wager

After the dice roll, enter 'y' to keep playing, or 'n' to quit.

Problem 3 is a PDF only. Double click the text file to open in your
PDF viewer.

Problem 4 can be compiled using "g++ main.cpp" and run with "./a.out" on a unix system.
To use, enter a number from 1 to 99 that represents the change you need to dispense.

