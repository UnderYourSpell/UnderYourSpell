#include <iostream>
#include <string>

using namespace std;

int main() {
    string num;

    // n-1 = represented starting number
    int startingNumber[9] = {0,0,0,0,0,0,0,0,0};

    for (int i=1; i < 3295; i++) {
        cin >> num;
        if (num[0] == '1') {
            startingNumber[0]++;
        }
        if (num[0] == '2') {
            startingNumber[1]++;
        }
        if (num[0] == '3') {
            startingNumber[2]++;
        }
        if (num[0] == '4') {
            startingNumber[3]++;
        }
        if (num[0] == '5') {
            startingNumber[4]++;
        }
        if (num[0] == '6') {
            startingNumber[5]++;
        }
        if (num[0] == '7') {
            startingNumber[6]++;
        }
        if (num[0] == '8') {
            startingNumber[7]++;
        }
        if (num[0] == '9') {
            startingNumber[8]++;
        }
    }

    cout << "There are " << startingNumber[0] << " ones." << endl;
    cout << "There are " << startingNumber[1] << " twos." << endl;
    cout << "There are " << startingNumber[2] << " threes." << endl;
    cout << "There are " << startingNumber[3] << " fours." << endl;
    cout << "There are " << startingNumber[4] << " fives." << endl;
    cout << "There are " << startingNumber[5] << " sixes." << endl;
    cout << "There are " << startingNumber[6] << " sevens." << endl;
    cout << "There are " << startingNumber[7] << " eights." << endl;
    cout << "There are " << startingNumber[8] << " nines." << endl;
}