#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

// roll dice function
int rollDice()
{
    return rand() % 6 + 1;
}

// get wager function
int getWager(int balance)
{
    int wager;

    cout << "Enter your wager: ";
    cin >> wager;

    while (wager > balance)
    {
        cout << "You don't have enough balance. Enter a new wager: ";
        cin >> wager;
    }

    return wager;
}

// get number function
int getNumber()
{
    int number;

    cout << "Enter your number: ";
    cin >> number;

    while (number < 1 || number > 6)
    {
        cout << "Invalid number. Enter a new number: ";
        cin >> number;
    }

    return number;
}

int main()
{

    srand(time(0));
    int balance = 100;

    while (balance > 0)
    {
        int wager = getWager(balance);
        int number = getNumber();

        int dice1 = rollDice();
        int dice2 = rollDice();
        int dice3 = rollDice();

        cout << "The dice rolls are: " << dice1 << " " << dice2 << " " << dice3 << endl;

        if (dice1 == number && dice2 == number && dice3 == number)
        {
            cout << "You won 3 times your wager" << endl;
            balance += wager * 3;
        }

        else if (dice1 == number && dice2 == number || dice1 == number && dice3 == number || dice2 == number && dice3 == number)
        {
            cout << "You won 2 times your wager" << endl;
            balance += wager * 2;
        }

        else if (dice1 == number || dice2 == number || dice3 == number)
        {
            cout << "You won your wager" << endl;
            balance += wager;
        }

        else
        {
            cout << "You lost your wager" << endl;
            balance -= wager;
        }

        cout << "Your balance is: " << balance << endl;

        char choice;
        
        cout << "Do you want to play again? (y/n): ";
        cin >> choice;

        if (choice == 'n')
        {
            break;
        }
    }


    return 0;
}