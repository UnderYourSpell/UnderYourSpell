- Command to compile and run question 1 in a unix system like Putty:
	Compile it first using this command:
	g++ benfords_law.cpp -o benfords_law
	
	Run it with this command:
	./benfords_law.out < ~sjneumayer/CSCE_A211/enrollments.txt

- Command to compile and run question 2 in a unix system like Putty:
	Compile it first using this command:
	g++ q2.cpp -o q2.out

	Run it with this command:
	./q2.out

- Command to run question 3 in a unix system like Putty:
	less q3.txt
	(this might be a little difficult to read due to the way it is formatted)

- Command to compile and run question 4 in a unix system like Putty:
	Compile it first using this command:
	g++ q4.cpp -o q4.out

	Run it with this command:
	./q4.out


