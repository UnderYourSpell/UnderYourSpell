#include <iostream>
using namespace std;

// calculate change function
void calculateChange(int amount, int &quarters, int &dimes, int &nickels, int &pennies)
{
    if (amount < 1 || amount > 99) 
    {
        cout << "Invalid amount. Please enter a value between 1 and 99." << endl;
        return;
    }

    quarters = amount / 25;
    amount = amount % 25;

    dimes = amount / 10;
    amount = amount % 10;

    nickels = amount / 5;
    amount = amount % 5;

    pennies = amount;
}

int main()
{
    int quarters, dimes, nickels, pennies;

    calculateChange(75, quarters, dimes, nickels, pennies);
    cout << "Change for 75 cents: " << quarters << " quarters, " << dimes << " dimes, " << nickels << " nickels, " << pennies << " pennies\n";

    calculateChange(99, quarters, dimes, nickels, pennies);
    cout << "Change for 99 cents: " << quarters << " quarters, " << dimes << " dimes, " << nickels << " nickels, " << pennies << " pennies\n";
    

    return 0;
}