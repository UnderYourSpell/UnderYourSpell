#pragma once
#include <string>
using namespace std;

class Movie {
private:
    string movieName;
    string rating;

public:
    Movie(const string& name, const string& rating) : movieName(name), rating(rating) {}

    string getMovieName() const {}
    string getRating() const {}

    // Function to compare movies for sorting
    static bool compareMovies(const Movie& movie1, const Movie& movie2) {
        return movie1.movieName < movie2.movieName;
    }
};

