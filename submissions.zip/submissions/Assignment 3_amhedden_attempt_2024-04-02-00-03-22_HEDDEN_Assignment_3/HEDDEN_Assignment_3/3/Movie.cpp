#include <iostream>
#include <string>
using namespace std;

class Movie {
private:
    string movieName;
    string rating;

public:
    Movie(const string& name, const string& rating) : movieName(name), rating(rating) {}

    string getMovieName() const {
        return movieName;
    }

    string getRating() const {
        return rating;
    }

    static void swapMovies(Movie& movie1, Movie& movie2) {
        Movie temp = movie1;
        movie1 = movie2;
        movie2 = temp;
    }
};

void bubbleSort(Movie movies[], int size) {
    for (int i = 0; i < size - 1; ++i) {
        for (int j = 0; j < size - i - 1; ++j) {
            if (movies[j].getMovieName() > movies[j + 1].getMovieName()) {
                Movie::swapMovies(movies[j], movies[j + 1]);
            }
        }
    }
}

int main() {

    Movie movies[] = {
        Movie("Black Panther", "PG-13"),
        Movie("Avengers: Infinity War", "PG-13"),
        Movie("A Wrinkle In Time", "PG"),
        Movie("Ready Player One", "PG-13"),
        Movie("Red Sparrow", "R"),
        Movie("The Incredibles 2", "G")
    };

    int numMovies = sizeof(movies) / sizeof(movies[0]);

    bubbleSort(movies, numMovies);

    cout << "Movies sorted alphabetically by name:" << endl;
    for (int i = 0; i < numMovies; ++i) {
        cout << movies[i].getMovieName() << " - " << movies[i].getRating() << endl;
    }

    return 0;
}
