#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;

class PostCode {
public:
    PostCode(int zip);
    PostCode(string bar);

    int getZip();
    string getBar();
private:
    int code;
    string barcode;

    bool validateBarcode();
    bool validateOnes();
    int calculateCode();
    string generateBarcode();
};

PostCode::PostCode(int zip) : code(zip) {}
PostCode::PostCode(string bar) : barcode(bar) {}

int PostCode::getZip() {
    if (validateBarcode()) {
        if (validateOnes()) {
            code = calculateCode();
        }
        else {
            cout << "Error: Incorrect format.";
            exit(1);
        }
    }
    else {
        cout << "Error: Invalid barcode.";
        exit(1);
    }
    return code;
}

string PostCode::getBar() {
    barcode = generateBarcode();
    barcode = "1" + barcode + "1";
    return barcode;
}

bool PostCode::validateBarcode() {
    bool valid;
    if ((barcode.length() == 27) && ((static_cast<int>(barcode[0]) - 48) == 1)
        && ((static_cast<int>(barcode[26]) - 48) == 1)) {
        valid = true;
    }
    else { valid = false; }
    return valid;
}

bool PostCode::validateOnes() {
    bool cases[5];
    int count = 0;
    int ones;
    bool result = true;
    for (int i = 1; i <= 25; i = i + 5) {
        ones = 0;
        for (int j = i; j <= i + 4; j++) {
            if ((static_cast<int>(barcode[j]) - 48) == 1) {
                ones++;
            }
        }
        if (ones == 2) {
            cases[count] = true;
        }
        else { cases[count] = false; }
        count++;
    }
    for (int i = 0; i < 5; i++) {
        if (cases[i] == false) {
            result = false;
            break;
        }
    }
    return result;
}

int PostCode::calculateCode() {
    int result = 0;
    int sums[5];
    int counter = 0;
    int sum;
    int temp;
    for (int i = 1; i <= 25; i = i + 5) {
        sum = 0;
        temp = 1;
        for (int j = i; j <= i + 4; j++) {
            if (temp == 1) {
                sum += (static_cast<int>(barcode[j]) - 48) * 7;
                temp++;
            }
            else if (temp == 2) {
                sum += (static_cast<int>(barcode[j]) - 48) * 4;
                temp++;
            }
            else if (temp == 3) {
                sum += (static_cast<int>(barcode[j]) - 48) * 2;
                temp++;
            }
            else if (temp == 4) {
                sum += (static_cast<int>(barcode[j]) - 48) * 1;
                temp++;
            }
            else if (temp == 5) {
                sum += (static_cast<int>(barcode[j]) - 48) * 0;
                temp++;
            }

        }
        if (sum == 11) {
            sum = 0;
        }
        sums[counter] = sum;
        counter++;
    }
    int multiplier = 10000;
    for (int i = 0; i < 5; i++) {
        result += sums[i] * multiplier;
        multiplier = multiplier / 10;
    }
    return result;
}

string PostCode::generateBarcode() {
    string result = "";
    int divisor = 10000;
    int num = code;
    int digit;
    for (int i = 0; i < 5; i++) {
        digit = num / divisor;
        switch (digit) {
        case 0:
            result += "11000";
            break;
        case 1:
            result += "00011";
            break;
        case 2:
            result += "00101";
            break;
        case 3:
            result += "00110";
            break;
        case 4:
            result += "01001";
            break;
        case 5:
            result += "01010";
            break;
        case 6:
            result += "01100";
            break;
        case 7:
            result += "10001";
            break;
        case 8:
            result += "10010";
            break;
        case 9:
            result += "10100";
            break;
        default:
            result += "00000";
            cout << "Error" << endl;
        }
        num = num % divisor;
        divisor = divisor / 10;
    }
    return result;
}

int main() {
    PostCode pc("110100101000101011000010011");
    cout << "ZIP code: " << pc.getZip();
    cout << endl;
    PostCode pstl(99504);
    cout << "Barcode: " << pc.getBar();
    cout << endl;
    return 0;
}
