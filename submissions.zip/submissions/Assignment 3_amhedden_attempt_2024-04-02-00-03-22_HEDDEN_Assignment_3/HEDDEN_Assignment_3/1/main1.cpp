#include <iostream>
#include "Pair.h"

using namespace std;

int main()
{
	Pair p1(5, 10);
	Pair p2(1, 2);

	// Outputs 5 and 10
	cout << p1.get1() << " " << p1.get2() << endl;
	// Outputs 1 and 2
	cout << p2.get1() << " " << p2.get2() << endl;

	Pair p3 = p2 + p1;
	// Outputs 6 and 12
	cout << p3.get1() << " " << p3.get2() << endl;

	p3 = p3 + 2;
	// Outputs 8 and 14
	cout << p3.get1() << " " << p3.get2() << endl;

	p3 = 2 + p3;
	// Now outputs 10 and 16 because of the previous line
	cout << p3.get1() << " " << p3.get2() << endl;
}

/*
In C++, when you overload a binary operator as a member function, the left operand must be an object of the class. 
In the expression p3 = 2 + p3;, 2 is an integer literal, not an object of the Pair class, so the compiler doesn't know how to handle this operation. 
To allow this operation, you need to overload the + operator as a friend function/operator, which is not bound to any particular object and can be called with non-class types as the left operand.
*/
//done