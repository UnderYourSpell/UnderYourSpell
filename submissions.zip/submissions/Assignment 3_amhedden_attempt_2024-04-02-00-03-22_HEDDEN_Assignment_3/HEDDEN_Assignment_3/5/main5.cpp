#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

class MazeSolver {
public:
    MazeSolver();
    void generateMaze();
    void solveMaze();
    void printSolutionPath();

private:
    static const int WIDTH = 20;
    static const int HEIGHT = 20;
    char maze[HEIGHT][WIDTH];
    bool visited[HEIGHT][WIDTH];
    int solutionX[(HEIGHT - 2) * (WIDTH - 2)];
    int solutionY[(HEIGHT - 2) * (WIDTH - 2)];
    int numPoints;

    bool validMove(int newX, int newY);
    bool move(int& curX, int& curY, int newX, int newY);
    bool search(int x, int y);
    void addToSolution(int xVal, int yVal);
    void printMaze(int curX, int curY);
};

MazeSolver::MazeSolver() {
    srand(time(NULL));
}

void MazeSolver::generateMaze() {
    for (int x = 0; x < WIDTH; x++) {
        for (int y = 0; y < HEIGHT; y++) {
            maze[y][x] = ' ';
        }
    }

    for (int x = 0; x < WIDTH; x++) {
        maze[0][x] = 'X';
        maze[HEIGHT - 1][x] = 'X';
    }

    for (int y = 0; y < HEIGHT; y++) {
        maze[y][0] = 'X';
        maze[y][WIDTH - 1] = 'X';
    }

    int numCells = static_cast<int>((HEIGHT - 2) * (WIDTH - 2) * 0.25);
    int count = 0;
    while (count < numCells) {
        int x = (rand() % (WIDTH - 2)) + 1;
        int y = (rand() % (HEIGHT - 2)) + 1;
        if (maze[y][x] == ' ') {
            maze[y][x] = 'X';
            count++;
        }
    }

    int x = (rand() % (WIDTH - 2)) + 1;
    int y = (rand() % (HEIGHT - 2)) + 1;
    while (maze[y][x] == 'X') {
        x = (rand() % (WIDTH - 2)) + 1;
        y = (rand() % (HEIGHT - 2)) + 1;
    }

    int exitX = (rand() % (WIDTH - 2)) + 1;
    int exitY = (rand() % (HEIGHT - 2)) + 1;
    while (maze[exitY][exitX] == 'X') {
        exitX = (rand() % (WIDTH - 2)) + 1;
        exitY = (rand() % (HEIGHT - 2)) + 1;
    }
    maze[exitY][exitX] = 'E';

    for (int x = 0; x < WIDTH; x++) {
        for (int y = 0; y < HEIGHT; y++) {
            visited[y][x] = false;
        }
    }
    visited[y][x] = true;
}

void MazeSolver::solveMaze() {
    numPoints = 0;
    bool found = search(1, 1);
    if (!found) {
        cout << "No solution found.";
    }
}

void MazeSolver::printSolutionPath() {
    cout << "Solution found! Here is the path from the start." << endl;
    for (int i = numPoints - 1; i >= 0; i--) {
        printMaze(solutionX[i], solutionY[i]);
        cout << endl;
    }
}

bool MazeSolver::validMove(int newX, int newY) {
    if (newX < 0 || newX >= WIDTH) return false;
    if (newY < 0 || newY >= HEIGHT) return false;
    if (maze[newY][newX] == 'X') return false;
    if (visited[newY][newX]) return false;
    return true;
}

bool MazeSolver::move(int& curX, int& curY, int newX, int newY) {
    bool foundExit = false;
    if (maze[newY][newX] == 'E') foundExit = true;
    curX = newX;
    curY = newY;
    visited[curY][curX] = true;
    return foundExit;
}

bool MazeSolver::search(int x, int y) {
    bool foundExit = false;
    if (maze[y][x] == 'E') return true;
    visited[y][x] = true;

    if (validMove(x, y - 1)) foundExit = search(x, y - 1);
    if (!foundExit && validMove(x, y + 1)) foundExit = search(x, y + 1);
    if (!foundExit && validMove(x - 1, y)) foundExit = search(x - 1, y);
    if (!foundExit && validMove(x + 1, y)) foundExit = search(x + 1, y);

    if (foundExit) addToSolution(x, y);
    return foundExit;
}

void MazeSolver::addToSolution(int xVal, int yVal) {
    solutionX[numPoints] = xVal;
    solutionY[numPoints] = yVal;
    numPoints++;
}

void MazeSolver::printMaze(int curX, int curY) {
    for (int y = 0; y < HEIGHT; y++) {
        for (int x = 0; x < WIDTH; x++) {
            if (x == curX && y == curY) cout << "@";
            else cout << maze[y][x];
        }
        cout << endl;
    }
}

int main() {
    MazeSolver solver;
    solver.generateMaze();
    solver.solveMaze();
    solver.printSolutionPath();
    return 0;
}
