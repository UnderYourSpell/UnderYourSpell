// maze-solver.cpp
//
// This program fills in a maze with random positions and then runs the solver to solve it.
// The moves are saved in two arrays, which store the X/Y coordinates we are moving to.
// They are output in main in forward order.
//
#include <iostream>
#include "Maze.hpp"

using namespace std;

int main()
{
    Maze maze;

    if (!maze.solveMaze())
        cout << "No solution found.";
    else
        cout << "Solution found! Here is the path from the start." << endl;

    return 0;
}
