//
//  Maze.cpp
//  Assignment_3.5
//
//  Created by Angel Cesar Amora on 4/3/24.
//

#include "Maze.hpp"
#include <ctime>
#include <cstdlib>
#include <iostream>

using namespace std;

Maze::Maze()
{
    srand(int(time(NULL)));
    
    for (int x = 0; x < WIDTH; x++)
    {
        for (int y = 0; y < HEIGHT; y++)
        {
            maze[y][x] = ' ';
        }
    }
     
    // Borders with X
    for (int x = 0; x < WIDTH; x++)
    {
       maze[0][x] = 'X';
       maze[HEIGHT - 1][x] = 'X';
    }
    
    for (int y = 0; y < HEIGHT; y++)
    {
       maze[y][0] = 'X';
       maze[y][WIDTH - 1] = 'X';
    }

    // ***** Randomly fill in 25% of the middle
    int numCells = static_cast<int>((HEIGHT - 2) * (WIDTH - 2) * 0.25);
    int count = 0;
    while (count < numCells)
    {
       int x = (rand() % (WIDTH - 2)) + 1;
       int y = (rand() % (HEIGHT - 2)) + 1;
       if (maze[y][x]==' ')
       {
           maze[y][x]='X';
           count++;
       }
    }

    // ***** Pick a random start and end that is not a wall *****
    int x = (rand() % (WIDTH - 2)) + 1;
    int y = (rand() % (HEIGHT - 2)) + 1;
    
    while (maze[y][x] == 'X')
    {
      x = (rand() % (WIDTH - 2)) + 1;
      y = (rand() % (HEIGHT - 2)) + 1;
    }
    
    // At this point, (x,y) contains our start position
    // ***** Pick a random end position that is not a wall *******
    int exitX = (rand() % (WIDTH - 2)) + 1;
    int exitY = (rand() % (HEIGHT - 2)) + 1;
    
    while (maze[exitY][exitX] == 'X')
    {
      exitX = (rand() % (WIDTH - 2)) + 1;
      exitY = (rand() % (HEIGHT - 2)) + 1;
    }
    maze[exitY][exitX] = 'E';

}

Maze::~Maze() {}

bool Maze::validMove(int newX, int newY)
{
    if (newX < 0 || newX >= WIDTH) // Check for going off the maze edges
       return false;
    if (newY < 0 || newY >= HEIGHT)
       return false;
    if (maze[newY][newX] == 'X') // Check if target is a wall
       return false;
    if (visited[newY][newX]) // Check if visited
       return false;
    return true;
}

bool Maze::move(int &curX, int &curY, int newX, int newY)
{
    bool foundExit = false;
    
    if (maze[newY][newX] == 'E') // Check for exit
    {
        foundExit = true;
    }
    
    // Update location
    curX = newX;
    curY = newY;
    visited[curY][curX] = true;
   
    return foundExit;
}

bool Maze::search(int x, int y, int solutionX[], int solutionY[], int &numEntries)
{
    bool foundExit = false;

    if (maze[y][x] == 'E')
    {
        return true;
    }
    
    visited[y][x]=true;
    
    if (validMove(x, y - 1))
     foundExit = search(x, y - 1, solutionX, solutionY, numEntries);
    if (!foundExit && (validMove(x, y + 1)))
     foundExit = search(x, y + 1, solutionX, solutionY, numEntries);
    if (!foundExit && (validMove(x - 1, y)))
     foundExit = search(x - 1, y, solutionX, solutionY, numEntries);
    if (!foundExit && (validMove(x + 1, y)))
     foundExit = search(x + 1, y, solutionX, solutionY, numEntries);

    if (foundExit)
    {
     // Remember coordinates we found the exit in the solution arrays
     addToArrays(solutionX, solutionY, numEntries, x, y);
     return true;
    }
    return false;
}

void Maze::addToArrays(int x[], int y[], int &numEntries, int xVal, int yVal)
{
    x[numEntries] = xVal;
    y[numEntries] = yVal;
    numEntries++;
}

void Maze::printMaze(int curx, int cury)
{
    for (int y = 0; y < HEIGHT; y++)
    {
      for (int x = 0; x < WIDTH; x++)
      {
      if ((x == curx) && (y == cury))
          cout << "@";
      else
          cout << maze[y][x];
      }
      cout << endl;
    }

}

bool Maze::solveMaze()
{
    int x = (rand() % (WIDTH - 2)) + 1;
    int y = (rand() % (HEIGHT - 2)) + 1;
    
    // Initialize visited locations to false
    for (int x = 0; x < WIDTH; x++)
    {
        for (int y = 0; y < HEIGHT; y++)
        {
            this->visited[y][x] = false;
        }
    }
    
    this->visited[y][x] = true;
    
    // Initialize solution arrays
    int solutionX[(HEIGHT - 2) * (WIDTH - 2)], solutionY[(HEIGHT - 2) * (WIDTH - 2)];
    int numPoints = 0;

    bool found = this->search(x, y, solutionX, solutionY, numPoints);
    
    if (!found)
    {
        cout << "No solution found.";
    }
    else
    {
        cout << "Solution found!  Here is the path from the start." << endl;
        for (int i = numPoints - 1; i >= 0; i--)
        {
            this->printMaze(solutionX[i], solutionY[i]);
            cout << endl;
        }
    }

    return found;
}
