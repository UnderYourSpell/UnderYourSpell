//
//  Maze.hpp
//  Assignment_3.5
//
//  Created by Angel Cesar Amora on 4/3/24.
//

#ifndef Maze_hpp
#define Maze_hpp
#pragma once
#include <stdio.h>

class Maze
{
    private:
        static const int WIDTH = 20;
        static const int HEIGHT = 20;
    
        char maze[HEIGHT][WIDTH];
        bool visited[HEIGHT][WIDTH];
    
        bool validMove(int newX, int newY);
        bool move(int &curX, int &curY, int newX, int newY);
        bool search(int x, int y, int solutionX[], int solutionY[], int &numEntries);
        void addToArrays(int x[], int y[], int &numEntries, int xVal, int yVal);
    
    public:
        Maze();
        ~Maze();
    
        bool solveMaze();
        void printMaze(int curx, int cury);
    
};

#endif /* Maze_hpp */
