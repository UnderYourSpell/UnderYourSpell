//
//  main.cpp
//  Assignment_3.1
//
//  Created by Angel Cesar Amora on 4/3/24.
//

#include <iostream>
#include "Pair.hpp"

using namespace std;

int main()
{
    Pair p1(5, 10);
    Pair p2(1, 2);

    // Outputs 5 and 10
    cout << p1.get1() << " " << p1.get2() << endl;
    // Outputs 1 and 2
    cout << p2.get1() << " " << p2.get2() << endl;

    Pair p3 = p2 + p1;
    // Outputs 6 and 12
    cout << p3.get1() << " " << p3.get2() << endl;

    p3 = p3 + 2;
    //p3 = 2 + p3;  this line in the original code does not work because there is no
    //              operator+ function in the Pair class where the left operand is an
    //              integer and the right operand is an instance of Pair.
    
    // Outputs 8 and 14
    cout << p3.get1() << " " << p3.get2() << endl;
    
    // Now we can use this line of code b/c we have a new friend :)
    p3 = 2 + p3;
    // Outputs 10 and 16
    cout << p3.get1() << " " << p3.get2() << endl;
}


