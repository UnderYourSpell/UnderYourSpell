Problem 1:

	Program works as expected.

Problem 2: 

	Program works as expected.

Problem 3:

	Program works as expected.

Problem 4: 

	Program works as expected.

Problem 5:

	Program works as expected.