//
//  main.cpp
//  Assignment_3.4
//
//  Created by Angel Cesar Amora on 4/3/24.
//

#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    int digitCounts[9] = {0};

    // Open the file
    ifstream inputFile("/Users/angelcesaramora/Documents/Comp Sci Tingz/CSCE211-SPR2024/Assignment 3 Tingz/Assignment_3.4/Assignment_3.4/enrollments.txt");
    if (!inputFile)
    {
        cerr << "Error opening file." << endl;
        return 1;
    }

    int number;
    while (inputFile >> number)
    {
        int leadingDigit = abs(number);
        
        while (leadingDigit >= 10)
        {
            leadingDigit /= 10;
        }

        if (leadingDigit >= 1 && leadingDigit <= 9)
        {
            digitCounts[leadingDigit - 1]++;
        }
    }

    // Close the file
    inputFile.close();

    for (int i = 0; i < 9; i++)
    {
        cout << "Count of numbers starting with " << (i + 1) << ": " << digitCounts[i] << endl;
    }

    return 0;
}

