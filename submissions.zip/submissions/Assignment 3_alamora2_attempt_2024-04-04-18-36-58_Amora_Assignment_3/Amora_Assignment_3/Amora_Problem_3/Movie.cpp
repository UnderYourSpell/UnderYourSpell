//
//  Movie.cpp
//  Assignment_3.3
//
//  Created by Angel Cesar Amora on 4/2/24.
//

#include "Movie.hpp"
using std::string;

Movie::Movie() : title("Movie"), rating("Rating") {}

Movie::Movie(string title, string rating) : title(title), rating(rating) {}

Movie::~Movie() {}

string Movie::getTitle()
{
    return title;
}

string Movie::getRating()
{
    return rating;
}

void Movie::setTitle()
{
    this->title = title;
}

void Movie::setRating()
{
    this->rating = rating;
}
