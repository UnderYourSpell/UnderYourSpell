//
//  Movie.hpp
//  Assignment_3.3
//
//  Created by Angel Cesar Amora on 4/2/24.
//

#ifndef Movie_hpp
#define Movie_hpp

#pragma once

#include <string>
#include <stdio.h>

using std::string;

class Movie
{
    private:
    std::string title;
    std::string rating;
    
    public:
    Movie();
    Movie(string title, string rating);
    ~Movie();
    
    string getTitle();
    string getRating();
    
    void setTitle();
    void setRating();
    
};

#endif
