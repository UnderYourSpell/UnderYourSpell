//
//  main.cpp
//  Assignment_3.3
//
//  Created by Angel Cesar Amora on 4/2/24.
//

#include <iostream>
#include "Movie.hpp"
using namespace std;

void swap(int &a, int &b)
{
    int temp = a;
    a = b;
    b = temp;
}

void bubbleSort(Movie movies[], int size)
{
    for (int i = 0; i < size - 1; i++)
    {
        for (int j = 0; j < size - i - 1; j++)
        {
            if (movies[j].getTitle() > movies[j + 1].getTitle())
            {
                swap(movies[j], movies[j + 1]);
            }
        }
    }
}

int main()
{
    const int numMovies = 6;
    
    Movie movies[numMovies] =
    {
        {"Black Panther", "PG-13"},
        {"Avengers: Infinity War", "PG-13"},
        {"A Wrinkle In Time", "PG"},
        {"Ready Player One", "PG-13"},
        {"Red Sparrow", "R"},
        {"The Incredibles 2", "G"}
    };
    
    bubbleSort(movies, numMovies);
    
    for (int i = 0; i < numMovies; i++)
    {
        cout << movies[i].getTitle() << " - " << movies[i].getRating() << endl;
    }
    
    cout << endl;
    
    return 0;
}
