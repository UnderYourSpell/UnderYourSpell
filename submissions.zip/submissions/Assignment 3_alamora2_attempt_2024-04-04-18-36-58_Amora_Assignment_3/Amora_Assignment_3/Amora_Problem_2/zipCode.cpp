//
//  zipCode.cpp
//  Assignment_3.2
//
//  Created by Angel Cesar Amora on 4/4/24.
//

#include "zipCode.hpp"
#include <iostream>
#include <string>

using namespace std;

string assignmentTable[10] = 
{
    "11000", "00011", "00101", "00110", "01001",
    "01010", "01100", "10001", "10010", "10100"
};

int ZipCode::decodeDigit(const string &digits)
{
    for (int i = 0; i < 10; i++)
    {
        if (assignmentTable[i] == digits)
        {
            return i;
        }
    }
    return -1;
}

ZipCode::ZipCode(int input)
{
    zip_int = input;
    zip_barcode = outputBarcode(input);
}

ZipCode::ZipCode(const string &input)
{
    zip_barcode = input;
    zip_int = outputZipCode(input);
}

string ZipCode::outputBarcode(int zipCode)
{
    string zipcodeStr = to_string(zipCode);
    string barcode = "1";

    for (char digit : zipcodeStr)
    {
        int num = digit - '0';
        barcode += assignmentTable[num];
    }

    return barcode + "1";
}

int ZipCode::outputZipCode(const string &barcode)
{
    string decodedZipCode = "";
    for (size_t i = 1; i < barcode.length() - 1; i += 5)
    {
        int digit = decodeDigit(barcode.substr(i, 5));
        
        if (digit == -1)
        {
            return -1;
        }
        decodedZipCode += to_string(digit);
    }
    return stoi(decodedZipCode);
}

int ZipCode::getZipInt()
{
    return zip_int;
}

string ZipCode::getZipBarcode()
{
    return zip_barcode;
}
