//
//  zipCode.hpp
//  Assignment_3.2
//
//  Created by Angel Cesar Amora on 4/4/24.
//

#ifndef ZIPCODE_H
#define ZIPCODE_H
#include <string>

using namespace std;

class ZipCode
{
    private:
        int zip_int;
        string zip_barcode;

        int decodeDigit(const string &digits);
    
    public:
        ZipCode();
    
        ZipCode(int input);
        ZipCode(const string &input);
    
        string outputBarcode(int zipCode);
        int outputZipCode(const string &barcode);
    
        int getZipInt();
        string getZipBarcode();
};

#endif
