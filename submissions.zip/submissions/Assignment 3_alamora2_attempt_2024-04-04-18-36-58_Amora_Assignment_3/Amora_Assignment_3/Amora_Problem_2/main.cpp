//
//  main.cpp
//  Assignment_3.2
//
//  Created by Angel Cesar Amora on 4/4/24.
//

#include <iostream>
#include "zipCode.hpp"

using namespace std;

int main()
{
    char choice;
    cout << "Enter 'z' for zip code or 'b' for barcode: ";
    cin >> choice;

    if (choice == 'z')
    {
        int zipcode;
        cout << "Enter a zip code: ";
        cin >> zipcode;

        ZipCode zip(zipcode);
        cout << "Barcode: " << zip.getZipBarcode() << endl;
    }
    else if (choice == 'b')
    {
        string barcode;
        cout << "Enter a barcode: ";
        cin >> barcode;

        ZipCode zip(barcode);
        cout << "Zip Code: " << zip.getZipInt() << endl;
    }
    else
    {
        cout << "Invalid choice. Please enter 'z' or 'b'." << endl;
    }
    
    return 0;
}
