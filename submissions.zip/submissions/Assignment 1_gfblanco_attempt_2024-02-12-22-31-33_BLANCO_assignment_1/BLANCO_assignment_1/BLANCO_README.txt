1. There is something wrong with my function to extract the first digit of each input passed into temp,
everything comes out as 0.

2. Does not limit bet entries.

4. Works as expected