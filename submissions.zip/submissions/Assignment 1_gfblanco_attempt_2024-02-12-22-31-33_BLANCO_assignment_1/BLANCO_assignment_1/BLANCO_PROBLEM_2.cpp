using namespace std;
#include <iostream>
#include <time.h>


void roll3(int balance, int wager){
    srand(time(NULL));
    int winnings = 0;
    int shadow = 0;
    int roll[3] = {};
    balance = balance - wager;
    char off;
    for(int i = 0; i < 3; i++) {
        int dice = rand() % 6 + 1;
        roll[i] = dice;
        if (roll[i] == wager){
            winnings = winnings + 1;
            balance = balance + wager;
            cout << "matches: " << winnings << endl;
        }
        else{
            shadow = shadow + 1;
        }
        if (shadow == 3) {
            cout << "Lose" << endl;
    }
    }
cout << "Current balance: " << balance << " Play again (y/n)?" << endl;
cin >> off;
if (off == 'y' && balance != 0) {
    cout << "enter new wager" << endl;
    cin >> wager;
    roll3(balance, wager);
}
else {
    exit;
}
}




int main(){

    int bet;
    cout << "Enter a number 1 - 6" << endl;
    cin >> bet;
    //if (0 < bet > 7) {
        //cout << "Invalid entry, try again" << endl;
        //cin >> bet;
    //}
    int money = 100;

    roll3(money, bet);
}

// This  is as best as I could get it to work, was having trouble
// Getting it to not accept invalid bets entries.