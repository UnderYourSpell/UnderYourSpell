#include <iostream>
using namespace std;

int leading_digit(int& id_num){
    while (id_num >= 10){
        id_num /= 10;
    }
    return 0;
}
int main() {
    int count[9];
    int arr[3265];
    int temp;
    int n, l, p;
    //leading_digit(n);
    //cout << "Input char" << endl;

    for(int i = 0; i < 3295; i++)
    {
        cin >> temp;
        arr[i] = temp;
        n = leading_digit(temp);
        //cout << n  << endl;
        count[n] += 1;
    }
    cout <<
    "Number of times 1 appears" << count[0] << " times " << endl;
   return 0;
}
