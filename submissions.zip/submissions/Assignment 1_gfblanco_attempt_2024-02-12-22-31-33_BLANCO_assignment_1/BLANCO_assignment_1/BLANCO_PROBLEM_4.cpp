#include <iostream>
using namespace std;

void
change_due (int total, int &Q, int &D, int &N, int &P)
{

  int count;
  int temp;
  temp = total;

  for (int i = 0; temp - 1 >= 0; i++)
	{							// temp - 1 corrects my for loop  from iterating 1 extra
	  if (temp >= 25)
		{
		  Q++;
		  temp = temp - 25;
		  count = count + 25;
		  //cout << total << endl;
		  //cout << Q << endl;
		}
	  if ((11 < temp) && (temp < 25))
		{
		  D++;
		  temp = temp - 10;
		  count = count + 10;
		}
	  if ((6 < temp) && (temp < 10))
		{
		  N++;
		  temp = temp - 5;
		  count = count + 5;
		}
	  if (temp < 5)
		{
		  P++;
		  temp--;
		  count++;
		}

	}
  cout << Q << " Quarters" << endl;
  Q = 0;
  cout << D << " Dimes" << endl;
  D = 0;
  cout << N << " Nickles" << endl;
  N = 0;
  cout << P << " Pennies\n" << endl;
  P = 0;
  return;
}

int
main ()
{
  // Write C++ code here
  int quarters, dimes, nickles, pennies = 0;
  int coins1 = 67;
  int coins2 = 44;
  change_due (coins1, quarters, dimes, nickles, pennies);

  change_due (coins2, quarters, dimes, nickles, pennies);
  return 0;
}