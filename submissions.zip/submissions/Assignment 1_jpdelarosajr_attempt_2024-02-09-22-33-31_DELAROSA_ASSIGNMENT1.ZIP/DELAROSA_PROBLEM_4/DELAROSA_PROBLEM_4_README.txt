
// im unsure if my cpp code provided in this folder was opening correctly so here is my code just in case

#include <iostream>
using namespace std;

void calculate(int amountOfChange, int& quarters, int& dimes, int& nickels, int& pennies);

int main() {
    int userChange;
    int quarters, dimes, nickels, pennies;

    for (int i = 0; i < 2; ++i) {
        cout << "Please enter the amount of change in cents between 1 and 99: ";
        cin >> userChange;

        while (userChange < 1 || userChange > 99) {
            cout << "Invalid amount. Please enter a change amount between 1 and 99: ";
            cin >> userChange;
        }
        calculate(userChange, quarters, dimes, nickels, pennies);
        cout << "Amount of each coin needed to make up " << userChange << " cents:" << endl;
        cout << "Quarters: " << quarters << endl;
        cout << "Dimes: " << dimes << endl;
        cout << "Nickels: " << nickels << endl;
        cout << "Pennies: " << pennies << endl;
    }

    return 0;
}

void calculate(int amountOfChange, int& quarters, int& dimes, int& nickels, int& pennies) {
    quarters = amountOfChange / 25;
    amountOfChange %= 25;
    dimes = amountOfChange / 10;
    amountOfChange %= 10;
    nickels = amountOfChange / 5;
    pennies = amountOfChange % 5;
}
