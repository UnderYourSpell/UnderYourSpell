For running problem 1 for Assignment 1:

Compile the given c++ code in Linux by using g++ -o /home/students/jpdelarosajr/assignment1.1.output /home/students/jpdelarosajr/a1.1.cpp my file name for the code on putty was a1.1.cpp. 

After compiling, find your way to the CSCE_A211 Directory, if you were not already in this directory, by using cd. 
-if you are at the home directory do cd sjneumayer/CSCE_A211
-this directory already has the enrollments.txt file that you need in order to complete this problem.
-execute the code you compiled while including the input file needed- enrollments.txt
do this by: /home/students/jpdelarosajr/assignment1.1.output < enrollments.txt

