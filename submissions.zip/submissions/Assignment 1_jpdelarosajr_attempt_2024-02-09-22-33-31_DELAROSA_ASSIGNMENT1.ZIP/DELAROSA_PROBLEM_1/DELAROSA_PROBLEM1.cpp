#include <iostream>
using namespace std;

int main() {
	int leadingcount[9] = { 0 };
	int num;
	while (cin >> num) {
		if (num <= 0) continue;
		while (num >= 10) {
			num /= 10; // divides until theres only 1 digit left
		}
		leadingcount[num - 1]++;

	}
	for (int i = 0; i < 9; ++i) {
		cout << "Leading Digit" << i + 1 << ": " << leadingcount[i] << "occurences." << endl;

	}
	return 0;
}