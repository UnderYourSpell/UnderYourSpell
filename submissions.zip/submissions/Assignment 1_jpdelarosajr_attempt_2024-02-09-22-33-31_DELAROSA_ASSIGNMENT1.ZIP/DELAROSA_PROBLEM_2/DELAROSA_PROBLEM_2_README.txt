// im unsure if my cpp code provided in this folder was opening correctly so here is my code just in case

#include <iostream>
#include <cstdlib>
using namespace std;

int ChuckALuck(int bet, int playernumber) {
    int earnings = 0;
    for (int i = 0; i < 3; ++i) {
        int roll = rand() % 6 + 1; //generates random number between 6 - 1
        cout << "You rolled a: " << roll << endl;
        if (roll == playernumber) {
            earnings += bet;
        }
    }
    return earnings;
}

int main() {
    int money = 100, bet;
    while (money > 0) {
        cout << "Balance: " << money << endl;
        cout << "Enter your bet: " << endl;
        cin >> bet;
        if (bet <= 0 || bet > money) {
            cout << "Invalid Bet. Try Again!" << endl;
            continue;
        }
        cout << "Pick A Number From 1-6: " << endl;
        int playernumber;
        cin >> playernumber;
        if (playernumber < 1 || playernumber > 6) {
            cout << "Invalid Choice. Try Again!" << endl;
            continue;
        }
        int earnings = ChuckALuck(bet, playernumber);
        if (earnings > 0) {
            cout << "You Won $" << earnings << endl;
            money += earnings - bet;
        }
        else {
            cout << "You Lost $" << bet << endl;
            money -= bet;
        }
        char playagain;
        cout << "Do you want to play again? (Y/N)" << endl;
        cin >> playagain;
        if (playagain == 'N' || playagain == 'n') {
            break;
        }
    }
    cout << " Thanks for playing! Your end balance is $" << money << endl;

    return 0;
}