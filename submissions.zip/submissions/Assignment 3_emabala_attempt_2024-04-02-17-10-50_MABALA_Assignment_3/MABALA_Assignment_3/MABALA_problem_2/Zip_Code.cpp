#include "Zip_Code.h"
#include <iostream>

using namespace std;

Zip_Code::Zip_Code(int code)
{
	zip = "0";
	int remain = code / 10; // Variable used to store zipcode after removal of the last number
	int x = code % 10; // Variable to pull each number of the zipcode starting with the last number
	
	// Assigns string to zip variable based on code number value and concatenates for each code number value
	for (int i = 0; i < 5; i++)
	{
		if (i == 0 && x == 0)
		{
			zip = "11000";
			x = remain % 10;
			remain /= 10;
		}
		else if (x == 0)
		{
			zip = "11000" + zip;
			x = remain % 10;
			remain /= 10;
		}
		else if (x > 8)
		{
			if (i == 0)
			{
				zip = "10100";
			}
			else
			{
				zip = "10100" + zip;
			}
			x = remain % 10;
			remain /= 10;
		}
		else if (x > 7)
		{
			if (i == 0)
			{
				zip = "10010";
			}
			else
			{
				zip = "10010" + zip;
			}
			x = remain % 10;
			remain /= 10;
		}
		else if (x > 6)
		{
			if (i == 0)
			{
				zip = "10001";
			}
			else
			{
				zip = "10001" + zip;
			}
			x = remain % 10;
			remain /= 10;
		}
		else if (x > 5)
		{
			if (i == 0)
			{
				zip = "01100";
			}
			else
			{
				zip = "01100" + zip;
			}
			x = remain % 10;
			remain /= 10;
		}
		else if (x > 4)
		{
			if (i == 0)
			{
				zip = "01010";
			}
			else
			{
				zip = "01010" + zip;
			}
			x = remain % 10;
			remain /= 10;
		}
		else if (x > 3)
		{
			if (i == 0)
			{
				zip = "01001";
			}
			else
			{
				zip = "01001" + zip;
			}
			x = remain % 10;
			remain /= 10;
		}
		else if (x > 2)
		{
			if (i == 0)
			{
				zip = "00110";
			}
			else
			{
				zip = "00110" + zip;
			}
			x = remain % 10;
			remain /= 10;
		}
		else
		{
			zip = "00101" + zip;
		}
	}
	zip = "1" + zip + "1";
	cout << "The entered zip code has now been changed to " << zip << endl;
}

Zip_Code::Zip_Code(string zip)
{
	int j = 0; // Variable to number of barcode zeros or ones
	string temp = ""; // Temp variable to store up to five barcode zeros or ones
	int num = 0; // Temp variable to add up barcode values
	int leadZero = 0; // Variable to track leading zeros for zipcodes beginning with zeros
	code = 0;
	
	// Loops through the zip string starting with the first character
	for (int i = 0; i < zip.length(); i++)
	{
		// Concatenates characters, between first and last, into temp variable
		if (i != 0 && i != (zip.length() - 1))
		{
			temp += zip[i];
			j++; // Counts each iteration upto five
		}
		if (j == 5)
		{
			// Updates num variable based on if character is a 1 or 0
			for (int k = 0; k < 5; k++)
			{
				if (k == 0)
				{
					if (temp[k] == '1')
						num = 7;
					else
						num = 0;
				}
				else if (k == 1)
				{
					if (temp[k] == '1')
						num += 4;
					else
						num += 0;
				}
				else if (k == 2)
				{
					if (temp[k] == '1')
						num += 2;
					else
						num += 0;
				}
				else if (k == 3)
				{
					if (temp[k] == '1')
						num += 1;
					else
						num += 0;
				}
			}
			// Tracks for zip codes beginning in zero for num equal to zero and code showing zero
			if (num == 11 && code == 0)
			{
				leadZero++;

			}
			// Adds zero onto zip code if num equal to 11 (replaced with zero) and code is not zero
			else if (num == 11 && code != 0)
			{
				code *= 10;
			}
			// Adds zero onto zip code and adds num value
			else
			{
				code = (code * 10) + num;
			}
			j = 0; // Resets j for main loop
			num = 0; // Resets num for main loop
			temp = ""; // Resets temp for main loop
		}
	}
	
	cout << "The entered bar code has now been changed to zip code ";
	// Prints zeros if any leadZeros were counted
	if (leadZero > 0)
	{
		for (int i = 0; i < leadZero; i++)
		{
			cout << "0";
		}
		cout << code << endl;
	}
	// If no leadZero found, just prints the finished zipcode value
	else
	{
		cout << code << endl;
	}
}
