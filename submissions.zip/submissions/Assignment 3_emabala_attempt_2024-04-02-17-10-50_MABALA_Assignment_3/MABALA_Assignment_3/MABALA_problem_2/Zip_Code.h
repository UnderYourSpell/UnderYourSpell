#pragma once
#include <string>

using std::string;

class Zip_Code
{
public:
	Zip_Code(int code);
	Zip_Code(string zip);

private:
	int code;
	string zip;

};

