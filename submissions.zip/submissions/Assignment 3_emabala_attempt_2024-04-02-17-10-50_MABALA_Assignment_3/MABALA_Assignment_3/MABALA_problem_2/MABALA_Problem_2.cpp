#include <iostream>
#include "Zip_Code.h"

using namespace std;

int main()
{
	Zip_Code Zip(99504);
	Zip_Code Bar("110100101000101011000010011");
};