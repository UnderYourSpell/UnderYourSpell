#pragma once
#include <string>

using std::string;

class Movie
{
private:
	string name;
	string rating;

public:
	Movie();
	Movie(string n, string r);
	void setName(string name);
	void setRate(string rating);
	string getName();
	string getRate();

};

