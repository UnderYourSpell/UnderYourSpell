#include <iostream>
#include <string>
#include "Movie.h"

using namespace std;

void swap(int& x, int& y)
{
	// Swaps the two locations variables
	int temp = y;
	y = x;
	x = temp;
}

void Sort(Movie a[], int start, int end)
{
	if (start == end)
		return;

	int begin = start;

	// Uses get name to compare string values
	for (int i = start + 1; i <= end; i++)
	{
		if (a[i].getName() < a[begin].getName())
		{
			begin = i;
		}
	}
	swap(a[begin], a[start]);

	// Recusively calls the function again while incrementing start, until start and end are the same
	Sort(a, (start + 1), end);
}

int main()
{
	Movie arr[7];
	arr[0].setName("Black Panther"); arr[0].setRate("PG-13");
	arr[1].setName("Avengers: Infinity War"); arr[1].setRate("PG-13");
	arr[2].setName("A Wrinkle In Time"); arr[2].setRate("PG");
	arr[3].setName("Ready Player One"); arr[3].setRate("PG-13");
	arr[4].setName("Red Sparrow"); arr[4].setRate("R");
	arr[5].setName("The Incredibles 2"); arr[5].setRate("G");

	cout << "The starting Movie array contains the following sequence of unsorted movies:" << endl;
	
	// Prints out Movie array before sort is called
	for (int i = 0; i < 6; i++)
	{
		cout << arr[i].getName() << ", " << arr[i].getRate() << endl;
	}

	Sort(arr, 0, 5);

	cout << "The sorted Movie array contains the following sequence of sorted movies:" << endl;
	
	// Prints out Movie array after sort is called
	for (int i = 0; i < 6; i++)
	{
		cout << arr[i].getName() << ", " << arr[i].getRate() << endl;
	}

};