#include "Movie.h"

Movie::Movie()
{
	name = "Unknown";
	rating = "U";
}

Movie::Movie(string n, string r)
{
	n = name;
	r = rating;
}

void Movie::setName(string name)
{
	this->name = name;
}

void Movie::setRate(string rating)
{
	this->rating = rating;
}

string Movie::getName()
{
	return name;
}

string Movie::getRate()
{
	return rating;
}
