#include <iostream>
#include <fstream>

using namespace std;

int main()
{
	ifstream inData;
	const int ARSIZE = 3296;
	int numbers[ARSIZE];
	int count = 0;

	cout << "Enter numbers to be looked at using Benford's Law: " << endl << endl;

	inData.open("enrollments.txt");

	cout << "Opening enrollments text file to retrieve numbers..." << endl << endl;
	
	if (!inData)
	{
		cout << "File failed to open" << endl;
		return 1;
	}

	for (int i = 0; i < ARSIZE; i++)
	{
		inData >> numbers[i];
	}
	cout << endl;

	inData.close();

	cout << "Closing enrollments text file..." << endl << endl;

	for (int i = 1; i < 10; i++)
	{
		for (int j = 0; j < ARSIZE; j++)
		{
			int temp = numbers[j];
			while (temp >= 10)
			{
				temp /= 10;
			}

			if (temp == i)
			{
				count++;
			}
		}
		cout << i << " is the leading digit " << count << " times." << endl;
		count = 0;
	}

	return 0;
}
