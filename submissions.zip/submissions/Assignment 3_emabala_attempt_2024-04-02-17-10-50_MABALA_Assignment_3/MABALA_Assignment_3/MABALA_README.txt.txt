Problem 1) Files created and ran through Visual Studio with no issues
Problem 2) Files created and ran through Visual Studio with no issues
Problem 3) Files created and ran through Visual Studio with no issues
Problem 4) Files modified and ran with Visual Studio without issue
Problem 5) File was modified and ran with Visual Studio and was a major pain.
I had to replace a lot of the global variables with actual numbers to get it to work.