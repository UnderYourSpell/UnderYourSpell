#pragma once
#include <cstdlib>
class Maze
{
public:
	Maze(int w, int h);
	void setMaze(char ar[][20]);
	void printMaze(char ar[][20], int curx, int cury);
	bool validMove(char ar[][20], bool visited[][20],
		int newX, int newY);
	bool move(char ar[][20], bool visited[][20],
		int& curX, int& curY, int newX, int newY);
	bool search(char ar[][20], bool visited[][20], int x, int y,
		int solutionX[], int solutionY[], int& numEntries);
	void addToArrays(int x[], int y[], int& numEntries, int xVal, int yVal);

private:
	int WIDTH;
	int HEIGHT;
	bool visited[20][20];
	int solutionX[(18) * (18)], solutionY[(18) * (18)];
	int x;
	int y;
};

